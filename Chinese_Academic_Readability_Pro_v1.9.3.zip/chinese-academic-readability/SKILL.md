---
name: chinese-academic-readability
description: 用于中文体育科学及其他学术文稿的论证、可读性、学术思想深度、有效论证增益、必要科学限定与写作层级控制；区分解释深度和实施细节，强化核心命题、证据、竞争性解释与科学问题优先级，制止完美主义式无关扩写和没有信息贡献的提前辩解。保留 FACT/COMPARISON LOCK、DOCX/PDF 视觉与字体 QA；原创学术示意图图内只保留必要标签（说明和免责声明放图注），对有来源的可行示例优先采用具体情境图，防止抽象文字框，优先以可编辑 PPT 原生图元绘制并导出 SVG；按论文类型决定图结构，真实数据图用可复现 Python 制作，查验科学证据与图像真实性。
license: MIT
compatibility: Python 3.10+ 运行辅助检查。artifact-qa 需 PyMuPDF、python-docx、Pillow、numpy、lxml 及实有 LibreOffice；Windows Word 导出需 pywin32；macOS Word 可手工导出 PDF 后通过 --existing-pdf 核查。缺少目标字体或未逐页签核应返回 UNVERIFIED/FAIL。
metadata:
  version: "1.9.3"
  language: "zh-CN"
---

# 中文学术论文论证与可读性优化｜Chinese Academic Readability Pro v1.9.3

## 一句话目标

让目标读者能**找到并准确说出论文的主张、依据、推理和适用边界**，而不是仅让文本看起来学术。先检查能否成立，再看是否解释得**足够深入但不过度**，然后改善能否读懂，以证据校准判断力度，最后才修饰语言。**真实证据与原稿权威版本始终高于流畅度。**

## 触发与非目标

- 用于：中文学术稿的“可读性差、逻辑断裂、AI 味重、段落过碎、段落跳跃、讨论不自然、审稿前修改、深度重构”；适配体育科学、体育社会学、运动干预、健康心理学、行为科学，其他领域按原学科要求处理。
- 不用于：规避 AI 检测、伪装作者身份、虚构研究或文献、凭修辞补齐缺失的分析结果、仅靠简化句子追求指标分数。**v1.4 对 DOCX/PDF 成稿新增独立 `artifact-qa`；它与语言编辑严格隔离，不授权为了修复布局而改写科研论点。**
- 作者给出已核实文献/真实发表论文时才能提取期刊风格；**没有参考样本不可声称已模仿某期刊的真实风格**。

## 0. 根据指令选择工作强度，不强制复杂流程

| 用户指令 | 模式 | 允许的编辑 |
| --- | --- | --- |
| “看看、评价、审稿、哪里不好” | `diagnose` | **只读**，只给问题锚点和修改建议 |
| “润色、精修” | `polish` | 优先最小改动，原文可零修改；不擅自重排大段 |
| “重写、重新组织、深度优化” | `rebuild` | 可合并/调整段落，但保留可验证结论与引用位置 |
| “开题适度简化、正文像实施协议、方法太细、内容深度不当” | `depth-control` | **先确认用途和读者**，对最小命题分 A/B/C；受科学设计双锁约束，允许有依据的简述或删减非核心实施细则 |
| “文章浮于表面、思想浅、只会罗列文献、解释不充分、担心没考虑周全、越写越复杂” | `intellectual-depth` | **深入最重要的1—3个核心命题**，查问题—证据—推理—竞争性解释—可检验性；执行优先级/停止规则，不新增无来源理论或无关实施细节 |
| “段落太多、太碎、一两句话一段、段落合并、机械小标题、叙述不够连续” | `paragraph-flow` | 按相邻段落论证任务做 `KEEP/MERGE/REFRAME/SPLIT`，不追求段数；综合章节优先连贯自然段，必要时才加二级标题；保护 RQ/H、研究阶段与科学限定 |
| “视觉抓手、段落太密、问题假设藏在正文、适当配图、读者快速浏览” | `reader-navigation` | 优先结构化已存在的科研信息，仅在图有独立认知价值时选择性加图；保留正文与数据；有文件交付则运行 `artifact-qa` |
| “ICML方法图、科研绘图、论文插图、训练曲线、消融、PPTX/SVG” | `scientific-figures` | **先分类与冻结图义/数据来源**：有可靠情境时优先画具体决策过程，无可核实情境就画抽象关系或不画；示意图用可编辑 PPTX→SVG，真实数值图用 Python→SVG/PDF |
| “比较效果、盲评、测试 Skill” | `evaluate` | 使用隐藏标签的同稿 A/B/C 与独立评审；不得把自评分当实测 |
| “最终 Word、PDF、排版检查、缺字、表格、公式、目录、提交/交付” | `artifact-qa` | **独立结构与视觉 QA**；对照 DOCX 和 PDF，不修改科研正文；未核实则不予 PASS |

用户未提供原文时，不伪造文章，输出适用的工作流或请求原文。已给信息足够时直接开始。涉及敏感/未公开文稿，先依用户允许的环境与保密要求处理。

**兼容性**：v1.8.0 在 v1.7.0 基础上升级；保留 v1.3.0 的科研语义检查，并保留 v1.4.2 的 115 项工程与语义回归测试；v1.5 新增学术写作深度控制；v1.6 新增 `intellectual-depth` 和 `priority-stop`；v1.6.1 新增必要推理的篇幅复核与“优先替换而不追加”，不改变原有 `polish`、`rebuild`、`evaluate`、`artifact-qa` 的权限边界。

## 0A. DOCX / PDF 交付时额外强制执行 `artifact-qa`（v1.4 新增）

**与学术润色严格分离**：`polish`/`rebuild` 负责事实锁、论证和自然中文；`artifact-qa` 负责成稿结构、输出文件与视觉忠实度。需要 `.docx`/`.pdf` 成稿时，不可只运行 `audit_text.py` 或文字比较脚本就认定交付合格。

1. 冻结并哈希当前审定 DOCX；检查 TOC、Word 表格、原生数学公式、字体与分页。若用户仅给散文文字，不运行文件渲染。
2. 用实际可用的引擎从 DOCX 导出 **新的 PDF**，将 **全部页面** 渲染成 PNG，记录 LibreOffice/Word 名称与版本以及 DOCX/PDF SHA-256。原生 Word 导出：Windows 可用 Word+pywin32；macOS 提供可选 AppleScript（需在本机验证）或使用 Word 手工导出。对已导出的 Word PDF，必须使用 `--existing-pdf` 核查原件，不可另由 LibreOffice 重导。
3. 同时运行三条线路：① DOCX↔PDF 文字/表格单元格与来源锚点对照；② 目录实际页码、页面边界、字体替换与疑似不可见文字初筛；③ PDF 全页面人工/明确审查者视觉核查，逐页确认汉字、表格、数学公式上下标、图文和页码。
4. 对可核查的缺字/错页/表格漏字，直接 `FAIL`。只有 PDF 文本或脚本通过，不等于视觉 PASS。任何未完成的全页视觉签核、数学对象审查、可疑差异裁决，标 `UNVERIFIED`。**唯一交付门禁是 `PASS / FAIL / UNVERIFIED`**，优先级 FAIL > UNVERIFIED > PASS。
5. 若修版面（字体、公式、表格列宽、标题样式），先保持研究文本不动，再完整重新导出/重渲染/回归审计。修复后检查原文内容及 FACT LOCK / COMPARISON LOCK 未被意外改变；页面图像旧签核因哈希变化自动失效。

典型命令：

```bash
python scripts/submission_gate.py /path/to/report.docx --out-dir /path/to/report_qa --engine libreoffice
# 若测试已知缺字：再加 --anchors-json examples/real-report-anchors-v14.json
# 未逐页填写 visual_review_template.json 前，不能对没有硬错误的文件宣布 PASS。
```

完整操作见 [references/document-rendering-qa.md](references/document-rendering-qa.md) 和 [references/formulas-tables-toc-qa.md](references/formulas-tables-toc-qa.md)；命令示例 [examples/document-artifact-qa.md](examples/document-artifact-qa.md)；28 页真实报告回归协议见 [evals/ARTIFACT_QA_PROTOCOL.md](evals/ARTIFACT_QA_PROTOCOL.md)。辅助脚本 `scripts/render_document.py`、`scripts/artifact_fidelity.py`、`scripts/visual_audit.py`、`scripts/submission_gate.py` 属于文件核查而非学术语言编辑。

## 0B. 中文宋体 + 英文 Times New Roman 严格字体门禁（v1.4.1）

对于用户要求的中文学术稿，默认字体政策为：**可编辑中文使用宋体（`SimSun`），英文和阿拉伯数字使用 `Times New Roman`**；斜体/粗体沿用各自样式，数学排版引擎使用的公式专用字体可单独说明；不可更改研究文本以迁就排版。图中已栅格化的文字必须逐图视觉核实，不能由 DOCX 样式检查证明。只有用户或目标期刊明确采用其他字体时才按其要求调整。

严格检查分为两层，不能互相替代：

1. **源 DOCX 声明**：遍历实际使用的段落/字符样式与直接字体覆盖，检查 `w:rFonts` 的 eastAsia、ascii、hAnsi、cs（`SimSun`、`Times New Roman`），排除只存在于 fontTable.xml 的未使用字体表项。
2. **实际 PDF 嵌入字体**：按提取的 PDF 字符/字体映射检查中文与英文字形是否使用所要求的字体。**宋体指定成功但 PDF 使用 Noto Serif CJK，或者 Times New Roman 被 Liberation Serif 替代，均是严格字体要求的 `FAIL`**，即使文字全部完整、视觉正常。没有 PDF、无法检查图内文字或未完成整页视觉审查时不得声称最终交付 PASS。字体文件不能随 Skill 分发。

示例：

```bash
python scripts/font_audit.py report.docx --pdf report.pdf --out-json font_audit.json
python scripts/submission_gate.py report.docx --out-dir qa --engine libreoffice --strict-simsun-times
```

**跨系统注意**：Mac 的 `Songti SC` 不是 Windows 的 `SimSun`；二者不能因为中文外观相近就视为同一字体。缺少字库时只能生成注明替代字体的预览 PDF，需在具有合法 SimSun / Times New Roman 字库的环境重新导出并复核。参见 [references/font-compliance.md](references/font-compliance.md)。

## 0C. 原生字体导出与外部 PDF 验收（v1.4.2）

如果要求最终 PDF **实际嵌入** `SimSun` 和 `Times New Roman`，必须区别四个独立状态：① DOCX 声明；② 本机真实字体文件存在且许可允许嵌入；③ Microsoft Word 用该字体输出 PDF；④ PDF 内实际 FontFile 字体数据与全页视觉、目录、公式和表格验证。**仅改 DOCX 字体名称、开启 Word 的字体嵌入开关、或者以类似宋体的开源字体替换，都不能自动满足第③④项。**

先执行：

```bash
python scripts/font_environment.py --out-json font_environment.json
python scripts/prepare_word_fonts.py input.docx --out prepared.docx
```

`prepare_word_fonts.py` 只添加 `embedTrueTypeFonts/saveSubsetFonts` 两个 Word 保存意图标记；不改正文、表格、公式，也不附带字体文件。此标记不代表字体已经嵌入，Word 是否能嵌入仍取决于可用字体、字体许可证与导出实现。

在 **已合法安装** 两套字体的 Microsoft Word 环境：Windows 可试用 `scripts/native_word_export.py`（需要 pywin32）；macOS 可尝试本地 Word AppleScript 自动化，失败时手工用 Word“另存为 PDF”（优先选择适合打印的 PDF 导出模式）。当前 Linux 开发环境不拥有 Word 和目标字库，严禁报告本机已导出原生字体 PDF。

**对真正要提交的 Word PDF**，使用外部文件验收入口，不得用 LibreOffice 重新导出来代替：

```bash
python scripts/font_audit.py prepared.docx --pdf word_export.pdf --out-json font_audit.json
python scripts/submission_gate.py prepared.docx --existing-pdf word_export.pdf \
  --external-engine-label 'Microsoft Word (user-reported)' \
  --out-dir qa_word_pdf --strict-simsun-times
```

`--existing-pdf` 以该 PDF 的 SHA-256 为准生成全页 PNG；显式标注“导出引擎由用户提供，未独立核实”。既检查 PDF 字体**名称**，也检查实际嵌入的 FontFile 数据。**PDF 文件能打开/有字不等于通过**：内容缺失、字体替换、错页为 FAIL；未核查完图表公式或未逐页签核为 UNVERIFIED。仅真正完成所有检查才允许 PASS。

如果目标字库缺失，可交付明确标记为“替代字体预览”的 PDF 和正确指定字体的 DOCX，不能将预览 PDF 宣称为最终合规版本。不能将字体文件放入 Skill 或输出给用户。详见 [references/font-compliance.md](references/font-compliance.md)。

## 0D. 学术写作深度控制 `depth-control`（v1.5 新增；先决定写到什么程度）

**核心问题不是“这一句能不能写”，而是“是否需要在当前类型的正文中写到这个程度”。** 对博士课程初步开题，避免把正式实施协议照搬进正文；对已注册试验方案、伦理审批及实证论文方法，不能反向删除其可复现、安全或统计解释所需内容。

在内容重构开始前执行：

1. **确定读者与文体（DEPTH LOCK）**：由用户当前任务判定 `course-preproposal`、`grant-proposal`、`formal-protocol`、`empirical-manuscript`、`theory-paper`、`review-paper`；用户未授权改变写作类型时，不擅自换成课程开题。参见 [references/writing-depth-profiles.md](references/writing-depth-profiles.md)。
2. **分离科学决定与执行参数**：FACT LOCK 和 COMPARISON LOCK 继续生效。对已经确定的研究问题、对象、阶段、随机比较、主要结局、关键时间窗和策略冻结顺序维持科学设计锁；对预测试才能完善的技术参数可简述原则并写明何时固定。参见 [references/design-lock-v15.md](references/design-lock-v15.md)。
3. **将“命题”而非整段分成三类**：`A｜科学骨架：必须清楚保留`；`B｜研究原则：准确简述`；`C｜在当前正文过细的执行规则：可缩写或删除`。一段同时包含 A+C 时，只删减 C，不能把主要比较或必要限定一起删掉。**C 不意味着科学上不重要，只意味着不宜在当前文体正文详述。** 分类与变更记录见 [references/content-tier-decision.md](references/content-tier-decision.md)。
4. **对课程开题先做“研究主线”检查**：为什么研究、现有证据支持什么、拟回答什么、研究一/二怎样衔接、两组具体比较什么、结局如何测量、可行性及伦理如何保证。第四/五章重实质方法解释，不穷举日志、每个阈值和异常处理。参见 [references/course-preproposal-editing.md](references/course-preproposal-editing.md)。
5. **编辑权限与负面门槛**：用户只要求润色时不可随意删除数字和操作规则。若用户明确授权“从实施协议深度调整为初步开题”，可删减非核心参数，但必须交付核心设计保持清单。不得把样本规模、选时核心规则、主要结局、组间共同条件写成“后续根据效果再定”。也不能为追求页数少缩小字号/行距；不要求把全部 C 类内容移到附件。
6. **审查层次有区别**：课程教师审读问题与文献、设计、结局、价值是否一目了然；方法审查者核对是否损坏随机、比较、缺失/测量质量和因果边界。若实际上只有同一模型自审，写“模拟双视角审读”，**不可声称真人或隔离代理独立审查已完成**。只对真问题定点修复，避免把旧协议整个加回来。
7. **先做文字，后做文件 QA**：若交付 DOCX/PDF，完成 `depth-control`、语义保真和正文版本冻结后，单独运行 `artifact-qa`。交付门禁的 PASS/FAIL/UNVERIFIED 指向文件质量，不等于“论证在真人读者中已验证更好”。

只读辅助诊断（**不会自动重写、不能自动给内容等级的最终裁决、不会评价真实可读性效果**）：

```bash
python scripts/depth_control_audit.py draft.docx --profile course-preproposal \
  --core-lock evals/example_core_lock_v15.json --baseline original.docx --out-json depth_audit.json
```

脚本按文档目标提示可能过细的技术段落和字面锁缺失；命中只是“人工审查候选”，非错误判决。字面锁存在也不能证明科学语义保真，应再执行 `compare_versions.py` 与作者/方法审查。

**参考真实课程稿件的回归经验**：在保证研究问题、两阶段设计、比较条件和结果层级的情况下，将技术化研究方案转为较短的课程开题，不一定要保留全部模型自由度、通知组合和逐分钟编码；但也不能用“以后确定”替代已决定的比较、结局或样本。这是单案例经验，**不是 v1.5 已经通过独立读者 A/B/C 效果验证**。见 [evals/WRITING_DEPTH_EVALUATION_PROTOCOL.md](evals/WRITING_DEPTH_EVALUATION_PROTOCOL.md) 与 [examples/08_preproposal_depth_control.md](examples/08_preproposal_depth_control.md)。

## 0E. 学术思想深度与“不过度思考”门禁（v1.6 新增）

**`DEPTH LOCK` 决定写到多细；`INTELLECTUAL DEPTH GATE` 决定是否真正解释了问题；`SCIENTIFIC PRIORITY & STOP RULE` 决定哪些推理值得继续深入、何时停止。** 学术深度不等于信息量、技术术语密度或限制条件数量。

在 `intellectual-depth` 模式，或用户明确要求“开题更有深度但不要完美主义式扩写”时：

1. **先圈定最多 1—3 条核心学术命题**，例如“为什么比较实际建议步行时段而不只是提示发送时间”。不要对每段套用同一理论—证据—机制模板。使用已有 `ARGUMENT MAP` 找出真正影响科学判断的段落。
2. **依次核查六个支点**：研究问题是什么、证据确实支持什么、从证据推到主张的桥梁是什么、最相关的竞争解释是什么、本设计能够区分/检验什么、结论必须停在哪个边界。缺关键证据时标明 `NEEDS_SOURCE`，不自行补造文献或“首次”“已证实”。并非每段都必须有替代解释；只针对核心机制/因果/比较主张要求。
3. **优先补一条真正有解释力的区别**，而不是增加文献、统计量、抽象术语或无来源机制。例如分清“提醒送达时间”与“建议实际步行时间”，解释日程机会、习惯和执行可能的关系，但不能把试点的过程记录写成已经证明的中介机制。
4. **对新增内容实施三级优先级**：`CRITICAL`（决定研究问题、比较、结果解释或伦理安全）必须处理；`IMPORTANT`（影响主要论证理解）简洁解释；`OPTIONAL`（只是穷举异常、重复信息或装饰性严谨）一般不进当前正文。正式试验/伦理协议中，实施与安全条件可能转为 `CRITICAL`，不能套用课程开题的省略标准。
5. **STOP RULE**：当核心命题的研究价值、证据、推理和边界已清楚，科学设计锁未受损，且没有未处理的 `CRITICAL` 问题，停止扩写。以后只有新证据、实质读者误解或重要方法风险才继续修改；“也许还可以考虑……”不是无限增加段落的理由。
6. **最小必要改写**：`KEEP / DEEPEN / SHORTEN / NEEDS_SOURCE / STOP & REVIEW`。已有足够解释力就 `KEEP`；真正浅薄则在关键处增加推理，不要恢复被删的全部技术细则。修改后继续执行 FACT LOCK、COMPARISON LOCK、语义保真与读者理解检查。

详细规则：[references/intellectual-depth-gate.md](references/intellectual-depth-gate.md) 与 [references/scientific-priority-stop-rule.md](references/scientific-priority-stop-rule.md)；体育科学示例：[examples/09_intellectual_depth_without_perfectionism.md](examples/09_intellectual_depth_without_perfectionism.md)。

只读辅助（须先由人/Agent 根据原稿填写论证账本；**不能自动判断论文深不深**）：

```bash
python scripts/intellectual_depth_audit.py evals/example_intellectual_depth_v16.json \
  --out-json depth_review.json
```

脚本核对标注中是否缺来源锚点/推理桥梁/关键竞争解释，是否把 `CRITICAL` 问题略掉，是否存在 `OPTIONAL` 扩写；`SCOPED_STOP_READY_FOR_HUMAN_REVIEW` 只代表这张**人工注释表**暂不见阻断项，绝不代表论文深度已获独立评分。见 [evals/INTELLECTUAL_DEPTH_EVALUATION_PROTOCOL.md](evals/INTELLECTUAL_DEPTH_EVALUATION_PROTOCOL.md)。

## 0F. Reasoning Gain per Word｜单位篇幅的有效论证增益（v1.6.1 新增）

**严禁以更长的段落冒充更深的学术判断。** 在 `intellectual-depth`、`depth-control` 或明确要求“不要完美主义式扩写”的任务中，新增内容必须指向可核查的关键推理缺口、研究比较或设计理由；**优先替换重复文本，再考虑追加新句**。方法/伦理/通知负担段落本来清楚时，用 `KEEP / SHORTEN`，不强行再增加“取舍”“机制”“完整闭环”等解释。

1. **标明唯一必要增益**：对最重要的1—3个关键命题，记录原文锚点、问题、必要的新推理、证据状态。若不能说出“读者原来不懂什么，改后懂什么”，原则上不增加句子。
2. **不同段落不同标准**：引言与研究切入点可在真实缺口处深化；已经解释清楚的研究方法、通知负担、伦理和操作安排不套用解释模板。初步开题只需讲清测量负担的核心原则、预设规模、如何试运行；不要穷举全部通知冲突和极端上限。
3. **15% 仅是人工复核触发线**：已有清楚的基准版本时，候选文本增加超过约15%汉字，应核查新增句是否补上不可缺少的推理、是否可以替换而非追加；**不是自动裁切上限，不是可读性指标**。重要的确有来源的论证可以更长，但须说明理由。
4. **核查科学归属**：新增可能解释必须标为假设，不得借“深化”改变 FACT LOCK、COMPARISON LOCK、DESIGN LOCK；新增技术极端情景仅为覆盖完美主义而存在时，直接 STOP。
5. **收尾决策**：可使用 `KEEP / REPLACE / SHORTEN / NEEDS_SOURCE / STOP & REVIEW`。只有关键问题获得足够解释且没有重要事实风险后停止，不再继续追求最大覆盖。

详见 [references/reasoning-gain-per-word.md](references/reasoning-gain-per-word.md)，示例 [examples/10_reasoning_gain_without_bloat.md](examples/10_reasoning_gain_without_bloat.md)。辅助审查：

```bash
python scripts/reasoning_gain_audit.py evals/example_reasoning_gain_v161.json \
  --out-json reasoning_gain_review.json
```

脚本仅计算篇幅变化，并核对**人工或 Agent 事先填写**的论证增益账本；即使返回 `SCREEN_CLEAR_NOT_QUALITY_PROOF`，也**不是独立读者评价、事实核验或推理真伪证明**。见 [evals/REASONING_GAIN_EVALUATION_PROTOCOL.md](evals/REASONING_GAIN_EVALUATION_PROTOCOL.md)。

## 0G. Calibrated Academic Assertiveness｜有证据支撑的明确判断（v1.7 新增）

**不要把“没有防御性写作”理解为“尽量不用否定词”。** 论文应首先明确陈述证据允许的判断、研究比较和设计理由，再为真实的推断风险保留必要边界。区分：① `ESSENTIAL_SCOPE`（影响因果、样本、统计、比较、时间、估计对象、伦理安全）必须保留或语义等价改写；② `REAL_MISREADING_CLARIFICATION`（当前文本确实可能误读）就近简明澄清一次；③ `UNNECESSARY_DEFENSE`（主动否认正文从未声称的“首次/机制/所有研究”，或重复已经说明的限制）删除或改成具体正面判断。

执行时**最多处理本节最影响主线的 1—3 处**；已有清楚而审慎的表达可以 `KEEP`。不得把“差异”改成“优于”，把关联改成因果，把拟开展研究写成已证实结果，或删掉决定科学推断的必要否定句。对于局限性、成功完成者子样本、非显著和缺失等保护估计对象的限定，**不能用去防御性写作为理由删除**。只有存在实际误读风险时才追加澄清；正文没提出的机制或效果不逐项否认。一个明确的学术判断胜过三句自我辩解。

按 [references/calibrated-academic-assertiveness.md](references/calibrated-academic-assertiveness.md) 对有争议的句子做 `KEEP / REFRAME / REMOVE / STOP & REVIEW` 决策；比较示例见 [examples/11_assertiveness_without_overclaim.md](examples/11_assertiveness_without_overclaim.md)。可选 `scripts/defensive_writing_audit.py` **只审查人工标注账本的自洽性**，不会从关键词判定防御性写作，更不代表论文可读性已经独立验证。评测见 [evals/CALIBRATED_ASSERTIVENESS_EVALUATION_PROTOCOL.md](evals/CALIBRATED_ASSERTIVENESS_EVALUATION_PROTOCOL.md)。

## 0H. Reader Navigation & Selective Figures｜读者导航与必要配图（v1.8）

**核心原则：可读性同时包括「能准确理解」与「能快速找到」。但标题、加粗、表格、配图都只是手段，不是数量越多越好。** 先依据读者任务做信息显著性检查，再选择**最小有效视觉手段**，不能为了显得生动或减少所谓 AI 味而引入无实证依据的图。

1. **确定评审的三个扫描任务**：能否在短时间定位研究问题与假设、两个阶段/两组比较、关键方法与结局的有效性标准？不同体裁自适配：课程开题可用独立 RQ/H 行和简洁阶段图；期刊论文优先遵从目标期刊结构，不能机械加小标题。
2. **先只调结构，再考虑加图**：长段可在真实主题转折处增设少量小标题；RQ/H 可用短段及加粗标签；需要复核的固定阈值宜在**原句中局部加粗**，避免重复制作大量表格。段首粗体短语可替代过密的七级标题。
3. **配图必须回答额外问题**：只有当图能揭示「两类比较对象的区别」「研究阶段与分组关系」「变量与评价层级」等文字/现有表格难以快速获得的关系时才插入。优先用**学术关系示意图/真实来源图（具备适当使用权限）**；缺少数据时禁止制作伪实证图或没有标注的模拟曲线。装饰图、与现有图表完全重复的图默认不加。
4. **图内的事实等级和引用**：区分既有研究实际报告、作者拟开展研究及假设。示意图需标明性质，不得暗示已证明优效。图与图注、正文交叉引用必须对应；序号及表号按最终排序同步更新。
5. **表达与版面同时保真**：`S*`、上下标、中文、英文、数据质量门槛、结局窗口和比较条件不得因为字体或换行被隐藏或改义。新图的图片/文本应保证足够尺寸、对比度及辅助说明；在 DOCX 中优先嵌入清晰分辨率或可编辑元素。**固定行距可能裁切行内图，必须实际渲染确认**。
6. **独立产物验收**：先冻结文字，更新目录与引用，再将 DOCX 通过实际引擎导出 PDF，检查**全部页面**中的图文、目录页码、表格折行、标题孤立、字体替换。缺少真正宋体/Times New Roman 时严格字体门禁仍然 `FAIL/UNVERIFIED`，不能靠像素正常显示宣称达标。
7. **最小必要停止规则**：最多补最有价值的1—2张非重复图；如果只有少量段落可通过结构/加粗解决，不强行加图。视觉修改后必须重新执行 FACT、COMPARISON、DESIGN LOCK；不能为图表整齐改变研究结论。

具体决策树见 [references/reader-navigation-and-figures.md](references/reader-navigation-and-figures.md)，体育科学示例见 [examples/12_reader_navigation_in_preproposal.md](examples/12_reader_navigation_in_preproposal.md)，评估边界见 [evals/READER_NAVIGATION_PROTOCOL.md](evals/READER_NAVIGATION_PROTOCOL.md)。辅助 `scripts/navigation_audit.py` 只会报告标题、RQ/H、图号与文字锚点的**疑点**，没有页面像素输入，不可声称视觉审核通过，也不应被用于自动插图。

### v1.8.1 默认制图源工作流：可编辑 PPT → 矢量 SVG

- **适用范围**：对研究框架、流程、概念关系、方法对照、研究阶段与测量层级等**原创学术示意图**，优先且原则上使大多数采用 **PowerPoint 原生形状、连接线与文本绘制**（可由代码程序化生成 PPTX）。**先构建能在 PowerPoint 中逐对象编辑的图，保留 `.pptx` 源文件，再从该图导出 `.svg`，用于论文或报告。** 若可行，所有简单原创示意图都走此流程；不为凑数量强制增加图片。
- **拒绝假矢量**：不将 AI 生成的 PNG/JPG 截图插进 PPT 再以 SVG 包裹、不把栅格图改名 `.svg`；图中框、箭头、文字应为可编辑对象，SVG 中应有真实矢量对象。保留图内文字的中英文可读性与字体映射，必要时提交版可转路径，但始终交付可编辑 PPTX。
- **例外类型**：原论文真实配图须保留来源与许可；带数值的科研数据图优先由真实数据与作图程序生成矢量图（SVG/PDF）；照片、设备图、显微图等真实栅格素材不强行用形状描摹；复杂图若不适合 PPT 绘制，说明为何改用专业矢量工具。不可重新绘制证据图并冒充原论文真实图。
- **交付/验收**：每张适用图尽量交付 `figure_##.pptx`（源文件）与 `figure_##.svg`（论文用），可附 `figure_##.png` 作为兼容预览；记录图类型、来源/数据、导出引擎及版本。执行 `python scripts/figure_source_audit.py figure_01.pptx figure_01.svg` 初筛是否具有 PPT 原生形状以及真实 SVG 元素。结构检查 PASS **不代表图中文字、箭头、尺寸和 PDF 嵌入已经视觉合格**，仍须实际打开 SVG、PPTX，并在最终 PDF 全页检查。

完整原则见 [references/ppt-native-svg-workflow.md](references/ppt-native-svg-workflow.md)，简例见 [examples/13_ppt_native_svg_requirement.md](examples/13_ppt_native_svg_requirement.md)，验收边界见 [evals/PPT_NATIVE_SVG_FIGURES_PROTOCOL.md](evals/PPT_NATIVE_SVG_FIGURES_PROTOCOL.md)。


## 0I. Scientific Figure Intelligence｜科研图形智能路由（v1.9）

需要**科研图或ICML方法图**时，先阅读 [references/scientific-figure-intelligence.md](references/scientific-figure-intelligence.md) 与 [references/figure-evidence-qa.md](references/figure-evidence-qa.md)，再按论文类型、具体科学主张及原始证据选择图形结构，而不是套用固定三栏画法。图先回答什么问题，再决定是否需要图：**已有文本足以清楚表达且图形没有独立价值时，允许不画。**

- **原创方法、理论、流程、干预阶段图** → 优先 PowerPoint 原生形状/可编辑文本，保留 `.pptx` 并经实际引擎导出 `.svg`（延续 v1.8.1 要求）。
- **真实训练曲线、消融、组间比较、统计结果** → 用可核验的 CSV/JSON/分析输出和 Python 绘制 SVG/PDF；必须保留数据、代码、单位、独立单位、误差与缺失处理来源，不能凭摘要想象出结果。
- **混合图、真实设备照片、原论文图** → 按面板分别保持来源、版权及合成标注性质；不能用AI画一张虚假的“真实”图。
- **论文类型分流**：AI/ML方法、机制/消融、benchmark、规律发现、Agent/机器人、体育科学EMA/JITAI/RCT与综述，应选择方法总览、局部机制、评测管线、数据面板、闭环、时间线或分类结构；任何图形因其内容而选择，不因目标期刊名称机械套布局。
- 先制作 `figure_contract.json`，至少写清唯一读者问题、科学主张、证据层级、来源、关键变量/比较、图号图注和目标格式。可运行 `python scripts/scientific_figure_plan.py evals/figure_contract_schematic_example.json --out /tmp/figure_plan.json` 做**路由与来源初筛**；实际文件生成后用 `scripts/figure_provenance_audit.py`、`scripts/plot_verified_csv.py` 与 `scripts/figure_source_audit.py` 核查来源和可编辑结构。此类工具不能给科学/视觉质量自动打 PASS。
- 示例与验收：[examples/14_figure_selection_preproposal_icml.md](examples/14_figure_selection_preproposal_icml.md)、[evals/SCIENTIFIC_FIGURE_INTELLIGENCE_PROTOCOL.md](evals/SCIENTIFIC_FIGURE_INTELLIGENCE_PROTOCOL.md)、[tests/test_v19.py](tests/test_v19.py)。只阅读和学习第三方项目的功能分工，不自动安装外部仓库/调用付费模型，也不声称通过了未经执行的图像生成。


## 0J. Paragraph Cohesion & Narrative Flow｜段落整合与自然论述（v1.9.1）

**针对段落过多、碎片化与机械分段，而非要求整篇减少若干段。** 段落应承担一个相对完整的论证任务；同一问题的“事实—解释—本研究理由”若被拆成连续微段，可尝试合并，但研究问题、假设、实证来源、观察与随机比较、方法阶段、主要与探索性结果之间的实质界限应保持清楚。

1. 先按 ARGUMENT MAP 识别相邻段落的**具体任务**，逐对判断是否共享一个问题、后段是否只是前段必要解释；仅对明确候选执行 `KEEP / MERGE / REFRAME / SPLIT / STOP & REVIEW`。不同对象或估计任务即使都很短，也不强行合并。
2. 避免“介绍一段—解释一段—意义一段”的机械三段式，优先使用自然承接并删除重复句；不要用“此外”“值得注意的是”掩盖逻辑缺口。反过来，也禁止把多项不同论证压入巨段，导致读者回读。
3. 保护 RQ/H 独立行、章节真实转折、策略 A/B/C、日常与事件 EMA、不同研究阶段、图表标题，以及必要的样本/时间/因果/统计限定；合并时执行 FACT LOCK、COMPARISON LOCK 和 DESIGN LOCK，不为段落减少而调整科学事实。
4. 与 `reader-navigation` 协同：**已经加了小标题不代表还需把每段切碎**；没有导航价值的段首标签可以自然融入正文，确有定位价值的 RQ/H 和主要结局则保持醒目。若不需合并，允许零修改。
5. 段落数量和长度**仅描述，不设10%—20%之类硬性减少目标**；是否更好读由正文连贯性和实际读者理解决定。文件输出仍走独立 `artifact-qa`，检查分页与图文、表格文字。

详见 [references/paragraph-cohesion-and-narrative-flow.md](references/paragraph-cohesion-and-narrative-flow.md)、[examples/15_paragraph_cohesion_and_narrative_flow.md](examples/15_paragraph_cohesion_and_narrative_flow.md)、[evals/PARAGRAPH_FLOW_EVALUATION_PROTOCOL.md](evals/PARAGRAPH_FLOW_EVALUATION_PROTOCOL.md)。

只读初筛 `python scripts/paragraph_flow_audit.py draft.docx --out-json flow_candidates.json`：提示相邻短段、重复开头和微标签，**不会合并正文或自动判定可读性**；独立 RQ/H、标题和结构化内容不作自动合并候选。最终必须由编辑核对证据、比较和读者理解。


## 0K. Figure Text Economy｜图内信息最小化（v1.9.2）

**科研图不承担作者的自我解释与免责段落。** 图面只保留读懂结构、比较、变量、单位和数据所必需的标签；“核心区别”“研究切入点示意”“不代表试验结果”“本图仅……”等元话语优先从画面移到论文图注、方法正文或图源记录。不要把图注焊成图内横幅，也不要给每个面板额外堆一个结论性小标题。

- **原创概念/机制/流程图**：优先空间布局、连线、色块及简短精确的节点标签，而不是长句文本框；图名与结果身份优先写在正式图注中。研究尚未完成时，不得删除必要的信息身份说明，须由**随图出现的图注**明确其为设计示意、非实测结果。
- **数据图例外**：坐标轴、单位、组别、误差定义、比例基数及必要限定不得为了“极简”而去掉。真实数据图、示意机制与混合面板需要使读者明确区分证据类型。
- **发表与无图停止**：图如果离开长段文字便无法成立，先改善构图；若图只重复两句话且没有独立认知价值，直接不画。允许原稿图文都保持不变。
- **源文件一致**：修改原生可编辑 PPTX，再重新导出 SVG 并逐图检查。将来源、非结果性质和图注移出图面，不等于删掉科学限制。只读初筛：`python scripts/figure_text_economy_audit.py figure.pptx --out-json figure_text_review.json`，输出 REVIEW_ONLY，不替代图义或视觉审查。

详见 [references/figure-text-economy.md](references/figure-text-economy.md)、[examples/16_minimal_text_in_figures.md](examples/16_minimal_text_in_figures.md)，示例可编辑 PPTX 与 SVG 位于 `assets/figure_demo/`。

## 0L. Editorial Calibration｜自然段落与具体机制图的联合校准（v1.9.3）

这是**对既有 `paragraph-flow`、`reader-navigation`、`scientific-figures` 的优先级校准，不是再增加一套强制重写流程**。

- **段落**：先辨认一个完整论证任务。证据、解释与本研究理由若属于同一问题，可合并并删重复；不同研究阶段、估计对象、关键对照与 RQ/H 不为段落少而合并。若合并后读者需在一段中记住多个独立问题，撤销合并。课程初步开题的综合章（如可行性—伦理—局限—进度），优先保持自然段；**不默认增设 7.1/7.2/7.3，也不默认删已有有效标题**。
- **学术表达**：以“研究对象—证据—关系—可回答的问题”明确判断。先用正面表述解释为何选择某设计，再仅在真正有统计或因果误读风险时保留必要限定；不得用抽象名词、机械过渡或反复“并不意味着……”代替学术判断。保留设计锁、因果边界和引文归属。
- **配图**：图应展示正文难以一眼理解的**真实结构、对照或可核查的具体决策过程**。对存在来源的选时实例，可用同一发送时点、两个可行时窗以及 A/B/C 可能不同的选择画时间线；必须在图注说明选择成立的条件，标注这是演示而非结果，**不能暗示未冻结的 S* 已确定为 B/C，或 B 永远优于 A**。没有可靠实例条件时宁可使用明确的抽象结构或不画，严禁编造“看起来具体”的数据。
- **图内文字及源文件**：只保留时间、窗口、策略/组别、变量、单位等读图必需标签。解释、示例身份、来源与限定写到随图图注。原创示意图优先交付可编辑 `.pptx` 与真矢量 `.svg`，再做 PDF 全页视觉审查；科学图像与程序结构测试互不替代。
- **停机条件**：只改确有问题的 1—3 个重要位置即可；若已有论证连续、图示清楚或改动将产生巨段、冗余图注与分页问题，`KEEP`。描述性段落数变化不是质量分数。

决策矩阵见 [references/editorial-calibration-and-concrete-figures.md](references/editorial-calibration-and-concrete-figures.md)；真实研究设计的条件性示例见 [examples/17_narrative_and_timing_figure.md](examples/17_narrative_and_timing_figure.md)，对应 [assets/figure_case_timing/](assets/figure_case_timing/) 的可编辑图源。`scripts/timing_figure_case_check.py` 仅检查该类型演示案例的明显时间矛盾，不能替代研究方案及图像人工审查。

## 1. 事实锁 FACT LOCK（所有改写必须执行）

建立精简的事实表，按原稿逐项记录：研究问题、设计（横断面/纵向/RCT/理论/方案）、样本及时间、变量/测量和单位、统计量与方向、显著性及区间、组别比较、否定/限定、引文标识、作者已确认观点。**必须额外设 COMPARISON LOCK：比较仅看差异、检验优效/劣效、还是等效/非劣？是计划还是已经证实？比较的是谁和哪个时间窗？**每条标 `已核实 / 原文声称未核实 / 待证据`，附原文锚点。必要时记录前后段落与表格、引文位置。

- 不虚构引文/数字/方法/机制；不得将观察性相关写成干预因果、把非显著写成等效、把计划研究写成已完成结果。
- **必须检查数值保持但语义反转**（正负、增加减少、高于低于、显著/不显著、不能/能够）。原文若自身推断越界，先标注问题并**以有根据的弱化纠正**，在变更说明中标为推断纠错，不要偷偷保留错误或声称是忠实复制。
- 细则：[references/evidence-fidelity.md](references/evidence-fidelity.md)、[references/semantic-fidelity.md](references/semantic-fidelity.md)、[references/comparison-claims.md](references/comparison-claims.md)。

## 2. 论证关系图 ARGUMENT MAP（持续执行的核心流程）

**先分析文章，再编辑句子。** 对需要改动的段落建立 `P编号 → 段落功能 → 核心命题 → 原稿证据位置 → 推理桥梁 → 与相邻段关系 → 状态`。段间关系只能根据内容选 `延伸/解释/比较/限定/反驳/推出问题/回答问题/无合理连接`，不能靠“此外、因此”掩盖断裂。将主张标成 `观察事实/作者解释/假设/建议`。

- 找出真正需要读者自行补猜的前提；**若已有证据充足但只是缺乏推理桥梁，可依据现有材料补足解释，并标明假设身份；若缺的是事实证据，则用 `【待补证据：具体问题】`**，不由模型补造。
- 如果段落已经清晰、有证据、能自然衔接，允许 `KEEP/零修改`；不能为使表格完整而强加五段式或小标题。
- 需要最简输出时只报告最高风险的 1–3 处；长文深入重构时保留全图。
- 细则与格式：[references/argument-mapping.md](references/argument-mapping.md)、[references/diagnosis-rubric.md](references/diagnosis-rubric.md)。

## 3. 分层修订（严格先后，按问题选择，不做无意义改写）

A. **论证层**：先修命题—证据—桥梁、重复段落、错误段间关系；对最关键的论证增加必要的比较与解释深度，避免只罗列研究或工程细节；证据不足就标注，绝不引文补白。
B. **信息层**：调整定义出现顺序、已知→新信息、比较基准、主语与限定位置；同时按 `paragraph-flow` 检查同一论证任务被机械拆成多段、或不同任务被强行合为巨段；保留适当长句及专业术语。
C. **中文表达层**：去掉没有信息贡献的“重要意义”“多维协同”等空泛表达；**不是词汇黑名单**，真实术语有定义和证据则保留。删除重复的模糊限定，但保留方法决定的审慎表达；按 `Calibrated Academic Assertiveness` 区分必要科学限定、真实澄清与无效预设反驳。
D. **一致性层**：全文术语、图表指代、变量方向、引文位置和期刊格式分别检查。

**修改幅度控制（v1.3）**：先做 `KEEP/POLISH/REORDER/MERGE/NEED_SOURCE/STOP & REVIEW` 决策；仅语言笨重时不要重新编写整段，只需局部修改。原文无具体研究缺口时不能新造“尚未有人研究”的缺口；有真实信息缺口则直接标记。修改后检查是否扩写出无来源的概念与效果承诺。操作参考 [references/minimal-edit-policy.md](references/minimal-edit-policy.md)。

对中文体育论文先按文体和研究阶段选择合适的信息深度，再调整表达：[references/writing-depth-profiles.md](references/writing-depth-profiles.md) · [references/content-tier-decision.md](references/content-tier-decision.md) · [references/article-types.md](references/article-types.md)、[references/reader-centric-writing.md](references/reader-centric-writing.md)、[references/sports-academic-style-card.md](references/sports-academic-style-card.md)；有真实期刊样本再用 [references/journal-style-adaptation.md](references/journal-style-adaptation.md)。

## 4. 双重验证：陌生读者测试 + 事实保真（必须）

**陌生读者**：只把**修订后的正文与固定问题**给隔离子代理或外部读者，不能传原稿、修改过程、预设中心论点和版本标签。提问：主要命题？依据在何处？哪句是观察、解释或假设？如何接上段？是否误读因果/比较/限定？见 [references/reader-test-protocol.md](references/reader-test-protocol.md)。没有隔离条件时标 `单模型模拟冷读（非独立）`，不可声称“盲读通过”。

**语义保真审计**：在修改前后逐条核对 FACT LOCK、命题状态及统计限定。标 `通过 / 发现冲突 / 未核实`；任何高风险语义冲突需回退或征得作者基于证据的确认。自动辅助：

```bash
python scripts/audit_text.py draft.md --format markdown
python scripts/compare_versions.py before.md after.md --format markdown
python scripts/edit_footprint.py before.md after.md --format markdown
```

这些脚本只给出**规则命中的待核查风险或描述性修改幅度**；未命中不代表无错误，命中也不代表一定有错，不能替代人工或研究设计评议。特别是事实保持但句义反转，务必人工逐句复核。

**v1.3 科研事实核查门槛（强制）**：
1. 自动检查分开阅读 `numbers_changed`（数值集合变化）、`number_binding_changed`（同组别/指标数值归属变化）、`unit_binding_changed`（数字相同单位变化）、`stat_comparator_changed`（P等符号变化）、`direction_binding_changed`（关系方向变化）、`comparison_hypothesis_shift`（差异/优效/等效等假设漂移）、`essential_qualifier_removed`（必要限定丢失），以及引用、计划时态、因果候选风险。数字未变不代表其他维度安全。
2. 对每个受影响的“研究设计×人群×变量×时间点×组别×统计量×解释”都应在 FACT LOCK 手工交叉核查原文表格和权威资料。脚本只做初筛；任何风险未核实则不得输出“事实保真通过”。
3. 同一稿件可能同时描述**本研究、前人研究与拟开展研究**，禁止把这些主体的研究设计、结果和因果强度混为一谈。自动检查依赖近邻中文提示，仍可能漏检跨段与隐含归属错误。
4. 面对风险提示：若原文确有不当因果断言，应依据研究设计标注“推断纠错”并合理弱化；对于新证据无法核查的新增判断，保留【待作者核查】，不要自动编造证明。精简原句时，还须检查限制对象、阶段、量词（“仅”“全部”“部分”）及事前固定要求是否被无意缩窄。
5. 对已清楚的原段落优先 `KEEP`；不得为了达到更高字数或减少“AI 味”做无价值修改。全文改写幅度与句长指标只作描述，**不是可读性改进证据**。
6. 原稿的**差异**假设不可被悄悄写成**优效、等效或非劣**；既往研究的结论不可转成当前研究成果。出现这种变更时必须 `STOP & REVIEW`，先核对已批准/预设的研究目标；若没有依据，恢复中性表述。

对自动检查范围、误报原因与补救流程，参见 [references/automatic-check-boundaries.md](references/automatic-check-boundaries.md)。

## 5. 修改完成和停止条件

- 审读者能复述关键论断与证据/推论边界；如果缺证据，明确留给作者，不把缺口隐入流畅段落。
- 事实锁的每个关键项处理完毕：`核对通过 / 需作者确认 / 未外部核实`，不得用一个总分掩盖硬错误。
- 已清楚的段落保持不变；反复改写只有在新证据或明确读者误解时才继续。**没有未处理的关键科学风险且继续添加只会穷举边缘问题时，执行 PRIORITY & STOP RULE。**
- **诊断**：最多 3–7 个最影响理解的锚点问题；**精修**：修订正文 + 关键修改 + 待核点；**深度重构**：简短事实锁 + 论证图（必要范围）+ 完整修订稿 + 读者测试状态 + 语义核查；**写作深度控制**：读者与文体定位 + A/B/C 命题分层 + 科学设计锁 + 调整后全文 + 简短删改说明 + 双视角审读状态；**思想深度**：1—3条核心命题的解释性缺口、最高优先级修改、必要的竞争解释/边界、停止理由 + 修改后正文；**评测**：原始对照文本/盲评资料/限制。
- 不承诺“达到核心期刊水平”“消除 AI 率”“分数必然提升”，不把内部评分当实证效果。

## 6. 有真实评测需求时使用独立 A/B/C 协议

`A = 普通 AI 润色`、`B = 同模型强化 Prompt`、`C = 加载本 Skill`。保持原始文本与模型/推理设置一致，随机遮盖来源，优先至少两位不参与改写的领域读者，根据事实保真硬门槛和读者理解结果评判。使用 [evals/EVALUATION_PROTOCOL.md](evals/EVALUATION_PROTOCOL.md) 和**单版本轮换工具** `scripts/prepare_reader_study.py`：每位读者每段仅看一版，跨读者 A/B/C 均衡，私有映射单独保存。旧 `prepare_blind_eval.py` 同一案例展示三版本，仅适用于**成对偏好/并列比较**，**不适合**宣称严格的独立理解测试。必须遮盖原稿、版本身份和修改指令，评审者只收到自身编号那份，不能收到私钥目录。**不能**拿 `unittest`、自动线索命中率或同一模型自评分冒充真实论文的可读性效果。

## 模块索引

- 思想深度与优先级：[references/intellectual-depth-gate.md](references/intellectual-depth-gate.md) · [references/scientific-priority-stop-rule.md](references/scientific-priority-stop-rule.md) · `scripts/intellectual_depth_audit.py` · [evals/INTELLECTUAL_DEPTH_EVALUATION_PROTOCOL.md](evals/INTELLECTUAL_DEPTH_EVALUATION_PROTOCOL.md)
- 写作深度：[references/writing-depth-profiles.md](references/writing-depth-profiles.md) · [references/content-tier-decision.md](references/content-tier-decision.md) · [references/design-lock-v15.md](references/design-lock-v15.md) · [references/course-preproposal-editing.md](references/course-preproposal-editing.md) · `scripts/depth_control_audit.py`
- 论证诊断：[references/argument-mapping.md](references/argument-mapping.md) · [references/diagnosis-rubric.md](references/diagnosis-rubric.md)
- 事实边界：[references/evidence-fidelity.md](references/evidence-fidelity.md) · [references/semantic-fidelity.md](references/semantic-fidelity.md) · [references/comparison-claims.md](references/comparison-claims.md)
- 导航与图示：[references/reader-navigation-and-figures.md](references/reader-navigation-and-figures.md) · [references/ppt-native-svg-workflow.md](references/ppt-native-svg-workflow.md) · [examples/12_reader_navigation_in_preproposal.md](examples/12_reader_navigation_in_preproposal.md) · `scripts/navigation_audit.py` · `scripts/figure_source_audit.py`
- 读者路径与段落节奏：[references/reader-centric-writing.md](references/reader-centric-writing.md) · [references/paragraph-cohesion-and-narrative-flow.md](references/paragraph-cohesion-and-narrative-flow.md) · [references/reader-test-protocol.md](references/reader-test-protocol.md) · [references/minimal-edit-policy.md](references/minimal-edit-policy.md) · `scripts/paragraph_flow_audit.py`
- 自然叙述与情境配图：[references/editorial-calibration-and-concrete-figures.md](references/editorial-calibration-and-concrete-figures.md) · [examples/17_narrative_and_timing_figure.md](examples/17_narrative_and_timing_figure.md) · [evals/EDITORIAL_CALIBRATION_PROTOCOL.md](evals/EDITORIAL_CALIBRATION_PROTOCOL.md) · `scripts/timing_figure_case_check.py`
- 领域写作：[references/article-types.md](references/article-types.md) · [references/sports-academic-style-card.md](references/sports-academic-style-card.md) · [references/journal-style-adaptation.md](references/journal-style-adaptation.md)
- 自动审核边界：[references/automatic-check-boundaries.md](references/automatic-check-boundaries.md)
- 成稿视觉交付 QA：[references/document-rendering-qa.md](references/document-rendering-qa.md) · [references/formulas-tables-toc-qa.md](references/formulas-tables-toc-qa.md) · `scripts/submission_gate.py` · `scripts/font_audit.py` · `scripts/font_environment.py` · `scripts/native_word_export.py` · `scripts/prepare_word_fonts.py` · `tests/test_v14.py` · `tests/test_v141.py` · `tests/test_v142.py`
- 行为评测与测试：[evals/EVALUATION_PROTOCOL.md](evals/EVALUATION_PROTOCOL.md) · `evals/` · `tests/`
