# Document Rendering & Visual QA｜独立交付核查流程（v1.4）

## 与学术润色的严格隔离

- `polish`、`rebuild`、`diagnose`：保持 v1.3 规则，先 FACT LOCK / COMPARISON LOCK / 论证图，不碰版面。
- `artifact-qa`：只检查 DOCX/PDF 字体、内容、图表、公式、目录、页码及视觉呈现；**默认不改研究正文**。任何改文字必须返回写作流程重新签核。
- 用户只给一段文字、没有文件交付意图时，不启动渲染。用户要求交付 `.docx`/`.pdf` 或核对最终文件时，必须经过本模块。

## 工作流（严格顺序）

1. 保存并哈希锁定权威 DOCX；先看未接受的修订、字体、标题样式、表格、公式 OMML、目录与人工分页。旧 PDF 不可作为已修复证据。
2. 指定实际导出引擎并记录版本：`libreoffice` 或 `word`。`auto` 只意味着记录并选取当前可用引擎；**不能声称两者均已检验**。
3. 从 DOCX 导出新 PDF，再渲染**每页** PNG（默认 150 dpi，可提高到 200）。记录 DOCX/PDF 的 SHA-256 与 PDF 页数；有已生成旧文件时先清理，防止误用旧 PDF。
4. 执行文本保真：DOCX 正文及表格单元格与 PDF 提取文字交叉比较，重点审查中文片段、数字—单位、变量、表题、公式前后文；对已知故障配置原文锚点及预期页码。**PDF 文本一致并不等于肉眼可见**。
5. 执行页面/字体/目录核查：记录源 DOCX 字体声明与 PDF 嵌入字体；自动检查页边界、疑似不可见汉字、页码与目录标题位置。字体别名/替换属于人工核验线索，不能仅凭 PDF 字体名称判断安全。
6. 审核全部页面（不是只看首页），特别查看：正文缺字、段间空白异常、表格单元格截断、公式上下标、标题悬空/分裂、页眉页脚、脚注、图注、目录和页码。重要数学对象须对照 DOCX 实际版面检查。
7. 发现问题只修改版面/字体/样式或公式对象；修复后重新导出并重新生成所有页图。核查新旧 DOCX 文字是否意外变化，更新 QA 证据的哈希绑定。
8. 使用 `submission_gate.py` 汇总，**只允许 `PASS`、`FAIL`、`UNVERIFIED`**。若没有 PDF 或缺任何页面图像，不能 PASS；没有逐页签核，也不能 PASS。

## 命令（在 Skill 根目录执行）

```bash
python scripts/submission_gate.py /path/to/report.docx --out-dir /path/to/qa-out \
  --engine libreoffice --anchors-json /path/to/anchors.json
# 在 qa-out/pages/page-001.png ... 检查全部页面；填写 qa-out/visual_review_template.json
python scripts/submission_gate.py /path/to/report.docx --out-dir /path/to/qa-out \
  --engine libreoffice --anchors-json /path/to/anchors.json \
  --reuse-render --review-json /path/to/completed_review.json \
  --adjudications-json /path/to/content_adjudications.json
```

**注意**：重新渲染会产生新 PDF/PNG；**提交已签核的文件时使用 `--reuse-render`** 复核已记录的 PDF/PNG 与哈希，而不是再次导出。签核文件必须使用与本次页面图像一致的哈希，不得在渲染前预签核；若哈希不一致则自动失效。初次验收不应强行填写 `PASS`。

## 可用引擎与限制

- LibreOffice：需要 `libreoffice` 或 `soffice` 命令行；本模块建立隔离用户配置执行转换，记录引擎版本。
- Microsoft Word：Windows 下可使用 `pywin32` COM（需实际安装 Word），`--engine word`；macOS/不支持平台**返回 `UNVERIFIED`**，不能暗中用 LibreOffice 代替。
- 若用户需要双引擎一致性：两次独立导出、独立验收；一个通过不能代替另一个。
- `artifact_fidelity.py` 的文本抽取不识别 PDF 中隐藏图层、被遮盖/白色文字及所有公式排列问题。`visual_audit.py` 的像素暗度分析只能筛查候选，有误报/漏报可能。
- 复杂 DOCX：特殊页码格式、文本框/图形、嵌入对象、脚注、内嵌公式与图表必须人工复核；若无法准确检查则标 `UNVERIFIED`。

## 三态交付门禁

| 状态 | 适用情况 |
|---|---|
| `PASS` | 指定引擎成功导出；文本/目录缺陷已排除；全页 PNG 和各类检查均完成；有与最终文件哈希一致的逐页人工/明确审查者签核；无未裁决高风险提示 |
| `FAIL` | 已证实内容丢失、错误页码、审查者明确发现错字/截断/公式错误，或渲染/页图失败 |
| `UNVERIFIED` | 引擎不可用、缺视觉签核、某些疑点/公式/文本框未裁决、只有文本层检验等 |

`FAIL` 优先于 `UNVERIFIED`，任何一项硬错误都阻断正式交付。自动脚本不能代表独立人类读者。遇到不支持的情况准确说明，不得伪造 Word 引擎可用、人工审查已完成或最终 PDF 已通过。

## 内容疑点裁决证据

自动比对可能把正常数学排版、断行和表格列阅读顺序判为疑点。允许由审查者提供 `adjudications.json`，必须含 `reviewer`, `docx_sha256`, `pdf_sha256`, `resolved_suspect_locations`，且若存在原生公式/文本框需分别确认 `native_math_visual_reviewed` / `text_boxes_visual_reviewed`。哈希必须匹配本次源文件与 PDF。裁决不覆盖已由来源锚点证实的 `FAIL`。

审查者使用 `visual_review_template.json`，每页按 `chinese_glyphs`, `table_cells`, `formula_subscripts`, `toc_and_page_numbers`, `layout_and_overlap` 分别填 `PASS` 或 `N/A`，并在 `status` 填 `PASS`，必要时提供 notes。被自动标记的异常页必须书面解释；无法核实仍应保持 `UNVERIFIED`。
