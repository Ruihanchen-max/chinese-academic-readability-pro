# 中文学术文档严格字体要求 — Font Compliance

- **允许的可编辑正文**：中文 `SimSun`（宋体）；英文、数字 `Times New Roman`（新罗马）。标题可使用加粗，但不要擅自换黑体；正文混排必须设置 OOXML 的 `ascii/hAnsi/eastAsia/cs`，仅在 Word 界面看到一个字体名称不充分。
- **禁止混淆**：`Songti SC`、`Heiti SC`、`Noto Serif CJK SC`、`Liberation Serif`、`Tinos` 是不同字体；它们可能近似但不能冒充用户指定字体。
- **PDF 必须单独审计**：Word 正确声明字体不代表 PDF 真正使用或嵌入；`pdffonts`、PyMuPDF 检测真实使用字形后，未知替代字体/字体未嵌入应分别处理。系统缺失字体时 `FAIL` 或 `UNVERIFIED`，不能改报 `PASS`。
- **数学公式**：需要保留可编辑的 OMML 公式，不要为了字体检查把公式拍平为图片。公式变量与特殊数学符号可能由 Cambria Math 或专用数学字体排版，逐项注明并视觉验证上下标、分式、求和号及正负号，不能只根据普通英文字体规则判错。
- **表格 / TOC / 图注**：字体变化会改变字宽、行高和分页，必须重新生成 PDF，核对全部目录页码以及表格单元格。旧签核失效，不能沿用。
- **嵌入图**：图片里的中文字符无法通过 OOXML 字体声明检查，若要求连图内文字都严格使用宋体，必须取得可编辑图源并重新绘制，或列为未验证。
- **验证工具**：`scripts/font_audit.py` 检测 docx 声明和 PDF 字符映射；`scripts/submission_gate.py --strict-simsun-times` 将字体结果纳入最终 FAIL/UNVERIFIED/PASS 门禁。
- **交付状态**：只有 DOCX 字体声明、PDF 真正字形、表格/公式、目录、视觉核查和事实保真均通过才能标 `PASS`。不向用户传播任何第三方字体文件。


## v1.4.2 原生字体必备检查

- **预检**：运行 `font_environment.py` 读取本地字体的真实字体家族元数据，`fc-match SimSun` 解析成 Noto 等替代字体时不能算安装成功。安装/使用/嵌入字体必须符合提供者授权，不绕开授权限制。
- **Word准备**：`prepare_word_fonts.py` 设置 `w:embedTrueTypeFonts` 与 `w:saveSubsetFonts`；这只是 Word 保存提示，并不是在 DOCX 中插入字体，不保证 Word 实际遵循或 PDF 自动合规。
- **原生导出**：优先在已安装字体的 Microsoft Word 中导出。没有真正字体时应停止或输出标明字体替代的预览版本；不可修改 PDF font dictionary 把 Noto/ Liberation 冒充 SimSun/Times New Roman。
- **严格校验**：`font_audit.py` 不仅审查 PDF 文字段的字体名称，还检查 PDF 的嵌入字体数据。即使 PDF 自报 SimSun/Times，但未实际嵌入真实 FontFile，必须 FAIL/UNVERIFIED。
- **已有 PDF**：运行 `submission_gate.py ... --existing-pdf original_word.pdf`，它直接渲染目标 PDF 的所有页面并核对 SHA；再人工核对表格、公式、目录、缺字。不要用无正版字体的 Linux LibreOffice 再次输出；那是另一份结果。
- **局限**：原生字库名称确认不等于每个字形、公式或图内文字都已证明合规。数学对象及栅格图要进行独立视觉核查。Mac 上 Word AppleScript 为未在此 Linux 环境运行的可选工具。
