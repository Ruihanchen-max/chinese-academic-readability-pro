#!/usr/bin/env python3
"""Build a minimal-text, editable PPTX example of *two distinct timing decisions*.

The figure contains ONLY labels needed to read the relationship. Study phase,
assumptions, non-results disclaimers and provenance belong in the external caption.
The graphic is an illustrative layout, NOT observed times or a trial result.
"""
from __future__ import annotations
import argparse
from pathlib import Path


def build(out_path: Path) -> Path:
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
    from pptx.enum.text import PP_ALIGN
    from pptx.dml.color import RGBColor
    from pptx.oxml.ns import qn

    prs=Presentation()
    prs.slide_width=Inches(12.0)
    prs.slide_height=Inches(4.7)
    slide=prs.slides.add_slide(prs.slide_layouts[6])
    ink=RGBColor(30,47,61)
    blue=RGBColor(41,89,142)
    teal=RGBColor(16,116,113)
    light=RGBColor(244,247,249)
    rule=RGBColor(193,205,213)

    def shape(kind,x,y,w,h,fill=None,stroke=None,thickness=1):
        o=slide.shapes.add_shape(kind, Inches(x),Inches(y),Inches(w),Inches(h))
        if fill is not None:
            o.fill.solid();o.fill.fore_color.rgb=fill
        else: o.fill.background()
        if stroke is not None:
            o.line.color.rgb=stroke;o.line.width=Pt(thickness)
        else:o.line.fill.background()
        style=o._element.find(qn("p:style"))
        if style is not None:
            effect=style.find(qn("a:effectRef"))
            if effect is not None: effect.set("idx","0")
        return o

    def label(s,x,y,w,h,size=16,bold=False,color=ink,align=PP_ALIGN.LEFT):
        o=slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
        tf=o.text_frame;tf.clear();tf.word_wrap=False
        tf.margin_left=tf.margin_right=Inches(0.02)
        tf.margin_top=tf.margin_bottom=Inches(0.01)
        p=tf.paragraphs[0];p.alignment=align
        r=p.add_run();r.text=s;r.font.name='SimSun';r.font.size=Pt(size);r.font.bold=bold;r.font.color.rgb=color
        return o

    def hline(x1,x2,y,color,weight=1.7):
        sh=slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(x1),Inches(y),Inches(x2),Inches(y))
        sh.line.color.rgb=color;sh.line.width=Pt(weight)
        return sh

    # Two clean panels. No generic 'key difference', methodology, or non-results notice inside.
    shape(MSO_SHAPE.ROUNDED_RECTANGLE,0.65,0.55,4.95,3.55,RGBColor(251,252,254),rule)
    shape(MSO_SHAPE.ROUNDED_RECTANGLE,6.40,0.55,4.95,3.55,RGBColor(250,253,252),rule)
    label('提示发送时点',1.05,0.88,4.1,0.5,20,True,blue)
    label('建议步行时段',6.82,0.88,4.1,0.5,20,True,teal)

    # A timing event. The time line is deliberately not numeric: no invented timestamps.
    hline(1.20,5.04,2.45,rule,2.3)
    shape(MSO_SHAPE.OVAL,3.02,2.33,0.25,0.25,blue)
    label('发送',2.83,2.76,0.65,0.32,13,False,blue,PP_ALIGN.CENTER)

    # Two timing recommendations, not actual behavior/effectiveness results.
    label('策略 A',6.82,2.00,0.98,0.4,14,True,ink)
    label('策略 S*',6.82,2.96,1.02,0.4,14,True,ink)
    hline(8.05,10.95,2.22,rule,2.0)
    hline(8.05,10.95,3.18,rule,2.0)
    # Minimal shapes indicate selectable time blocks, NOT observed interventions.
    shape(MSO_SHAPE.ROUNDED_RECTANGLE,8.45,2.08,0.72,0.28,blue)
    shape(MSO_SHAPE.ROUNDED_RECTANGLE,9.65,3.04,0.72,0.28,teal)

    out_path.parent.mkdir(parents=True,exist_ok=True)
    prs.save(out_path)
    return out_path


def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('out',type=Path)
    args=ap.parse_args()
    try:
        print(build(args.out));return 0
    except (OSError,ImportError,ValueError) as exc:
        print(f'Failed to create PPTX: {exc}');return 1

if __name__=='__main__':
    raise SystemExit(main())
