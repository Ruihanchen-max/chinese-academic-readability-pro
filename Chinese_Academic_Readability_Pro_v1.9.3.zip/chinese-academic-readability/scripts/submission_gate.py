#!/usr/bin/env python3
"""Academic DOCX→PDF artifact QA: PASS/FAIL/UNVERIFIED, no text editing.

Returns FAIL if verifiable content/TOC defects exist; otherwise UNVERIFIED until
all pages have been visually reviewed and all substantive differences resolved.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

from render_document import convert_docx, inspect_existing_pdf, sha256
from artifact_fidelity import check_fidelity
from visual_audit import inspect_visual
from font_audit import audit as check_fonts


def combine(statuses: list[str]) -> str:
    if 'FAIL' in statuses:
        return 'FAIL'
    if any(s != 'PASS' for s in statuses):
        return 'UNVERIFIED'
    return 'PASS'


def run_gate(docx: Path, out_dir: Path, engine: str = 'auto',
             anchors: list[dict] | None = None, review_json: Path | None = None,
             dpi: int = 150, scan_ink: bool = True, adjudications: dict | None = None,
             reuse_render: bool = False, strict_simsun_times: bool = False,
             existing_pdf: Path | None = None, external_engine_label: str = "external-export-unverified") -> dict:
    docx = Path(docx).resolve()
    out_dir = Path(out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    starting_hash = sha256(docx) if docx.is_file() else None
    manifest = out_dir / 'render_manifest.json'
    if reuse_render and existing_pdf is not None:
        raise ValueError('--reuse-render and --existing-pdf cannot be used together')
    if reuse_render:
        if not manifest.is_file():
            render = {'status': 'UNVERIFIED', 'reason': 'No prior render manifest to reuse',
                      'engine_used': None, 'pages': 0, 'page_images': []}
        else:
            render = json.loads(manifest.read_text(encoding='utf-8'))
            if render.get('status') != 'PASS' or render.get('docx_sha256') != starting_hash:
                render['status'] = 'FAIL'
                render['reason'] = 'Source DOCX differs from recorded render or original run did not pass'
            else:
                pdf_old = Path(render.get('pdf_path') or '')
                image_hashes = render.get('page_image_sha256', {})
                if (not pdf_old.is_file() or sha256(pdf_old) != render.get('pdf_sha256')
                        or len(image_hashes) != render.get('pages', 0)
                        or any(not (out_dir/'pages'/f'page-{i:03}.png').is_file() or
                               sha256(out_dir/'pages'/f'page-{i:03}.png') != image_hashes.get(str(i))
                               for i in range(1, render['pages']+1))):
                    render['status'] = 'FAIL'
                    render['reason'] = 'Prior PDF/images missing or differ from render manifest'
    elif existing_pdf is not None:
        render=inspect_existing_pdf(docx, existing_pdf, out_dir, dpi=dpi, engine_label=external_engine_label)
        manifest.write_text(json.dumps(render, indent=2, ensure_ascii=False), encoding='utf-8')
    else:
        render = convert_docx(docx, out_dir, engine=engine, dpi=dpi, png=True)
        manifest.write_text(json.dumps(render, indent=2, ensure_ascii=False), encoding='utf-8')
    if render['status'] != 'PASS':
        result = {'status': render['status'], 'engine_used': render.get('engine_used'),
                  'render_status': render['status'], 'fidelity_status': 'UNVERIFIED',
                  'visual_status': 'UNVERIFIED', 'font_status': 'UNVERIFIED' if strict_simsun_times else 'NOT_REQUESTED', 'reason': render['reason'],
                  'input_sha256': starting_hash}
    else:
        pdf = Path(render['pdf_path'])
        fidelity = check_fidelity(docx, pdf, anchors, adjudications=adjudications)
        visual = inspect_visual(docx, pdf, out_dir / 'pages', review_json,
                                out_dir / 'visual_review_template.json', scan_ink=scan_ink)
        (out_dir / 'artifact_fidelity.json').write_text(json.dumps(fidelity, indent=2, ensure_ascii=False), encoding='utf-8')
        (out_dir / 'visual_audit.json').write_text(json.dumps(visual, indent=2, ensure_ascii=False), encoding='utf-8')
        font_report = check_fonts(docx, pdf) if strict_simsun_times else {'status': 'NOT_REQUESTED'}
        if strict_simsun_times:
            (out_dir / 'font_audit.json').write_text(json.dumps(font_report, indent=2, ensure_ascii=False), encoding='utf-8')
        combined_statuses = [render['status'], fidelity['status'], visual['status']] + ([font_report['status']] if strict_simsun_times else [])
        result = {'status': combine(combined_statuses),
                  'input_sha256': starting_hash,
                  'engine_requested': engine, 'engine_used': render.get('engine_used'),
                  'engine_version': render.get('engine_version'),
                  'pdf_sha256': render.get('pdf_sha256'),
                  'page_count': render['pages'],
                  'page_images_generated': len(render['page_images']),
                  'render_status': render['status'], 'fidelity_status': fidelity['status'],
                  'visual_status': visual['status'], 'font_status': font_report['status'],
                  'anchor_failures': [f for f in fidelity['anchors'] if f['status'] == 'FAIL'],
                  'content_suspects': fidelity['suspected_count'],
                  'toc_failures': [f for f in visual['toc_results'] if f['status'] == 'FAIL'],
                  'toc_entries_checked': visual['toc_checked'],
                  'native_omath_nodes': fidelity['source_inventory']['native_omath_nodes'],
                  'inkless_glyph_candidate_pages': visual['suspected_inkless_glyph_page_count'],
                  'manual_review_status': visual['review_status'],
                  'reason': 'Passed all checks, including signed full-page review' if
                            combine(combined_statuses) == 'PASS'
                            else 'Not all artifact submission criteria satisfied'}
    if starting_hash and docx.is_file() and sha256(docx) != starting_hash:
        result['status'] = 'FAIL'
        result['reason'] = 'Source DOCX changed during rendering/checks'
    result['checked_at_utc'] = datetime.now(timezone.utc).isoformat()
    (out_dir / 'submission_gate.json').write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding='utf-8')
    failure = '\n'.join(f'- {x.get("id")}: {x.get("source_text")} (expected page {x.get("pdf_expected_page")})'
                        for x in result.get('anchor_failures', [])) or '- None at supplied anchor checks'
    report = f'''# Document Rendering & Visual QA — Submission Gate

**Result: {result['status']}**  
Date UTC: {result['checked_at_utc']}  
DOCX SHA-256: `{starting_hash}`  
Engine requested: `{engine}`; actually used: `{result.get('engine_used')}`  
Engine version: `{result.get('engine_version', 'unavailable')}`  
PDF pages: {result.get('page_count', 'not rendered')}  
Full-page PNGs: {result.get('page_images_generated', 0)}  

| Gate | Status |
|---|---|
| DOCX → PDF → every-page images | {result['render_status']} |
| DOCX/PDF semantic text and anchors | {result['fidelity_status']} |
| TOC/layout/page-image review | {result['visual_status']} |
| Strict SimSun / Times New Roman PDF font compliance | {result.get('font_status', 'NOT_REQUESTED')} |
| Reviewer visual sign-off | {result.get('manual_review_status', 'UNVERIFIED')} |

## High-confidence content regressions
{failure}

Other possible differences: {result.get('content_suspects', 'unavailable')}; native OMML equation nodes: {result.get('native_omath_nodes', 'unavailable')}; TOC entries checked: {result.get('toc_entries_checked', 'unavailable')}. See the JSON files for locations and candidate evidence.

## Rule
An exported PDF is **not** a deliverable PASS unless every page image was actually reviewed and signed off, all missing-text risks were adjudicated, every formula/table was visually checked, and text comparison has no unresolved problems. The scripts never modify research prose. A Word export on another operating system/engine must be verified separately.
'''
    (out_dir / 'submission_report.md').write_text(report, encoding='utf-8')
    return result


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('docx', type=Path)
    p.add_argument('--out-dir', type=Path, required=True)
    p.add_argument('--engine', choices=['auto', 'libreoffice', 'word'], default='auto')
    p.add_argument('--anchors-json', type=Path)
    p.add_argument('--review-json', type=Path)
    p.add_argument('--adjudications-json', type=Path)
    p.add_argument('--dpi', type=int, default=150)
    p.add_argument('--reuse-render', action='store_true', help='Verify existing PDF/PNGs against prior hashes; do not re-export')
    p.add_argument('--no-ink-scan', action='store_true')
    p.add_argument('--existing-pdf', type=Path, help='Audit the exact PDF exported in Microsoft Word or another tool, without re-exporting it')
    p.add_argument('--external-engine-label',default='external-export-unverified',help='User-declared PDF export provenance; not independently verified')
    p.add_argument('--strict-simsun-times', action='store_true', help='Fail when DOCX declared fonts or actual PDF embedded fonts are not genuine SimSun / Times New Roman')
    args = p.parse_args()
    anchors = json.loads(args.anchors_json.read_text(encoding='utf-8')) if args.anchors_json else []
    adjudications = json.loads(args.adjudications_json.read_text(encoding='utf-8')) if args.adjudications_json else None
    result = run_gate(args.docx, args.out_dir, args.engine, anchors, args.review_json,
                      args.dpi, not args.no_ink_scan, adjudications, args.reuse_render, args.strict_simsun_times, args.existing_pdf, args.external_engine_label)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['status'] == 'PASS' else 1 if result['status'] == 'FAIL' else 2


if __name__ == '__main__':
    raise SystemExit(main())
