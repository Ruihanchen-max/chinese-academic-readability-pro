#!/usr/bin/env python3
"""Offline structural validation for this Agent Skill package; stdlib only."""
from __future__ import annotations

import argparse
import re
from pathlib import Path
from typing import Iterable

LINK_PATTERN = re.compile(r"(?<!!)\[[^\]]+\]\(([^)]+)\)")
NAME_PATTERN = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")


def validate(root: Path) -> list[str]:
    root = root.resolve()
    problems: list[str] = []
    main = root / "SKILL.md"
    if not main.is_file():
        return ["Missing SKILL.md"]
    data = main.read_text(encoding="utf-8")
    if not data.startswith("---\n"):
        return ["SKILL.md must start with YAML frontmatter"]
    parts = data.split("\n---\n", 1)
    if len(parts) != 2:
        return ["Missing closing YAML frontmatter marker"]
    fm, body = parts
    name = re.search(r"(?m)^name:\s*([^\n]+)$", fm)
    descr = re.search(r"(?m)^description:\s*([^\n]+)$", fm)
    if not name:
        problems.append("Missing name frontmatter")
    else:
        value = name.group(1).strip().strip("\"'")
        if not NAME_PATTERN.fullmatch(value) or len(value) > 64:
            problems.append("Invalid name frontmatter")
        if value != root.name:
            problems.append(f"name {value!r} must match folder {root.name!r}")
    if not descr or not descr.group(1).strip():
        problems.append("Missing description frontmatter")
    elif len(descr.group(1).strip()) > 1024:
        problems.append("Description exceeds 1024 characters")
    if not body.strip():
        problems.append("SKILL.md has no instructions")
    required = [
        "references/paragraph-cohesion-and-narrative-flow.md",
        "examples/15_paragraph_cohesion_and_narrative_flow.md",
        "evals/PARAGRAPH_FLOW_EVALUATION_PROTOCOL.md",
        "scripts/paragraph_flow_audit.py",
        "tests/test_v191.py",
        "references/ppt-native-svg-workflow.md",
        "examples/13_ppt_native_svg_requirement.md",
        "evals/PPT_NATIVE_SVG_FIGURES_PROTOCOL.md",
        "scripts/figure_source_audit.py",
        "tests/test_v181.py",
        "references/calibrated-academic-assertiveness.md",
        "examples/11_assertiveness_without_overclaim.md",
        "evals/CALIBRATED_ASSERTIVENESS_EVALUATION_PROTOCOL.md",
        "evals/example_assertiveness_v17.json",
        "scripts/defensive_writing_audit.py",
        "tests/test_v17.py",
        "references/reasoning-gain-per-word.md",
        "scripts/reasoning_gain_audit.py",
        "tests/test_v161.py",
        "examples/10_reasoning_gain_without_bloat.md",
        "evals/REASONING_GAIN_EVALUATION_PROTOCOL.md",
        "evals/example_reasoning_gain_v161.json",
        "references/intellectual-depth-gate.md",
        "references/scientific-priority-stop-rule.md",
        "scripts/intellectual_depth_audit.py",
        "tests/test_v16.py",
        "evals/INTELLECTUAL_DEPTH_EVALUATION_PROTOCOL.md",
        "evals/example_intellectual_depth_v16.json",
        "examples/09_intellectual_depth_without_perfectionism.md",
        "references/writing-depth-profiles.md",
        "references/content-tier-decision.md",
        "references/design-lock-v15.md",
        "references/course-preproposal-editing.md",
        "scripts/depth_control_audit.py",
        "tests/test_v15.py",
        "evals/WRITING_DEPTH_EVALUATION_PROTOCOL.md",
        "examples/08_preproposal_depth_control.md",
        "evals/example_core_lock_v15.json",
        "references/diagnosis-rubric.md",
        "references/reader-centric-writing.md",
        "references/evidence-fidelity.md",
        "references/article-types.md",
        "references/journal-style-adaptation.md",
        "references/reader-test-protocol.md",
        "references/argument-mapping.md",
        "references/semantic-fidelity.md",
        "references/sports-academic-style-card.md",
        "references/comparison-claims.md",
        "references/minimal-edit-policy.md",
        "references/automatic-check-boundaries.md",
        "scripts/compare_versions.py",
        "scripts/edit_footprint.py",
        "scripts/prepare_reader_study.py",
        "scripts/prepare_blind_eval.py",
        "scripts/verify_release.py",
        "tests/test_v12.py",
        "tests/test_v13.py",
        "tests/test_v14.py",
        "scripts/render_document.py",
        "scripts/artifact_fidelity.py",
        "scripts/visual_audit.py",
        "scripts/submission_gate.py",
        "references/document-rendering-qa.md",
        "references/formulas-tables-toc-qa.md",
        "evals/ARTIFACT_QA_PROTOCOL.md",
        "examples/real-report-anchors-v14.json",
        "evals/risk_regression_cases.json",
        "evals/READER_SCORECARD.md",
        "evals/EVALUATION_PROTOCOL.md",
        "evals/v13_comparison_regression.json",
        "evals/example_reader_study_v13.json",
        "USAGE_GUIDE_CN.md",
    ]
    for file in required:
        if not (root / file).is_file():
            problems.append(f"Missing package file: {file}")
    for md in root.rglob("*.md"):
        if md.is_symlink():
            problems.append(f"Symlink not allowed: {md}")
            continue
        source = md.read_text(encoding="utf-8")
        for match in LINK_PATTERN.finditer(source):
            target = match.group(1).split("#")[0].strip().strip('"')
            if not target or "://" in target or target.startswith("mailto:"):
                continue
            if target.startswith("/"):
                problems.append(f"Absolute local link {md.relative_to(root)}: {target}")
                continue
            path = (md.parent / target).resolve()
            if root != path and root not in path.parents:
                problems.append(f"Escaping local link {md.relative_to(root)}: {target}")
            elif not path.exists():
                problems.append(f"Broken local link {md.relative_to(root)}: {target}")
    return problems


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", nargs="?", default=".", type=Path)
    args = parser.parse_args()
    problems = validate(args.root)
    for problem in problems:
        print("ERROR:", problem)
    if problems:
        print(f"FAILED: {len(problems)} structural problem(s)")
        return 1
    print("PASS: SKILL.md format, required files and local Markdown links (structural only)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
