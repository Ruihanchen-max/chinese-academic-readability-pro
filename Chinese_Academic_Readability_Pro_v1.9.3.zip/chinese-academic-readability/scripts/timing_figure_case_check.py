#!/usr/bin/env python3
"""Check obvious temporal contradictions in a *hypothetical* walking-timing diagram.

This narrow checker is intentionally NOT a scientific-figure validator. It does not
infer strategies B/C from raw observational data; their choices are conditional
on the explicitly supplied assumptions and still require author review.
"""
from __future__ import annotations

import argparse
import json
from datetime import timedelta
from pathlib import Path


def _minute(day: int, time: str) -> int:
    if not isinstance(day, int) or isinstance(day, bool) or day < 0:
        raise ValueError('day_offset must be a non-negative integer')
    if not isinstance(time, str) or len(time) != 5 or time[2] != ':':
        raise ValueError('expected HH:MM')
    h, m = int(time[:2]), int(time[3:])
    if not (0 <= h < 24 and 0 <= m < 60):
        raise ValueError('invalid clock time')
    return day * 1440 + h * 60 + m


def audit(data: dict, folder: Path | None = None) -> dict:
    errors = []
    warnings = []
    if data.get('scenario_type') != 'illustrative_walking_schedule':
        errors.append('SCENARIO_TYPE: expected illustrative_walking_schedule')
    if data.get('evidence_status') != 'hypothetical_protocol_example':
        errors.append('EVIDENCE_KIND: an explanatory diagram must not masquerade as actual results')
    if data.get('study_phase') != 'preproposal':
        errors.append('STUDY_PHASE: this fixture is only for a preproposal demonstration')
    if data.get('S_star_status') != 'not_frozen':
        errors.append('S_STAR: study strategy has not been chosen or independently verified')
    try:
        n = data['notification']
        notice = _minute(n['day_offset'], n['time'])
        windows = data['feasible_windows']
        if not isinstance(windows, list) or len(windows) < 2:
            raise ValueError('at least two feasible windows required')
        ids = set()
        timestamps = {}
        for w in windows:
            key = w['id']
            if not isinstance(key, str) or not key or key in ids:
                raise ValueError('duplicate or empty window id')
            ids.add(key)
            start = _minute(w['day_offset'], w['start'])
            end = _minute(w['day_offset'], w['end'])
            if not (notice < start < end):
                raise ValueError('windows must begin after notification and have positive duration')
            timestamps[key] = start
        choices = data['strategy_choices']
        if not {'A','B','C'} <= set(choices):
            raise ValueError('missing A/B/C choice')
        for strategy in ('A', 'B', 'C'):
            if choices[strategy] not in ids:
                raise ValueError(f'{strategy} selection references unknown window')
        if timestamps[choices['A']] != min(timestamps.values()):
            errors.append('A_NOT_EARLIEST: baseline A must choose earliest feasible window')
        assumptions = data.get('conditional_assumptions', {})
        for rule in ('B','C'):
            if not isinstance(assumptions.get(rule),str) or len(assumptions[rule].strip()) < 8:
                errors.append(f'{rule}_ASSUMPTION_MISSING: explain why this candidate is selected')
    except (KeyError, IndexError, TypeError, ValueError) as exc:
        errors.append('MALFORMED_CASE: ' + str(exc))

    caption = data.get('caption_file')
    if not isinstance(caption,str) or not caption or '/' in caption or '\\' in caption or caption.startswith('.'):
        errors.append('CAPTION_PATH: supply a simple local caption filename')
    elif folder is not None:
        fp = folder / caption
        if not fp.is_file():
            errors.append('CAPTION_MISSING: figure must have a separate explanatory caption')
        else:
            t = fp.read_text(encoding='utf-8')
            if not any(x in t for x in ('示例','概念','示意')):
                warnings.append('CAPTION_IDENTITY: confirm caption describes its illustrative nature')
            if 'S*' not in t and 'S∗' not in t:
                warnings.append('CAPTION_STRATEGY: confirm uncertain S* is explained')

    return {'status': 'FAIL' if errors else 'REVIEW_ONLY',
            'errors': errors, 'warnings': warnings,
            'scientific_content_fidelity': 'UNVERIFIED',
            'visual_fidelity': 'UNVERIFIED',
            'note':'Only obvious timing and identity contradictions are screened; B/C rules require domain review.'}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('case_json', type=Path)
    parser.add_argument('--out-json',type=Path)
    args = parser.parse_args()
    try:
        obj = json.loads(args.case_json.read_text(encoding='utf-8'))
        result = audit(obj, args.case_json.parent)
    except (OSError,ValueError,json.JSONDecodeError) as exc:
        result = {'status':'FAIL','errors':[str(exc)],'scientific_content_fidelity':'UNVERIFIED'}
    out=json.dumps(result,ensure_ascii=False,indent=2)
    print(out)
    if args.out_json:
        args.out_json.parent.mkdir(parents=True,exist_ok=True)
        args.out_json.write_text(out+'\n',encoding='utf-8')
    return 1 if result['status']=='FAIL' else 0

if __name__ == '__main__':
    raise SystemExit(main())
