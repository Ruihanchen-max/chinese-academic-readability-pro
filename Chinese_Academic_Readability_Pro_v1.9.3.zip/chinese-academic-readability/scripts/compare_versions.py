#!/usr/bin/env python3
"""Read-only Chinese scientific manuscript change cues, NOT factual verification.

Chinese-adjacent values, percentages, digit grouping, anchored group/metric values,
and direction changes are checked. This is deliberately a conservative *review queue*:
false positives are preferable to silent numeric changes, but zero flags is not proof.
No third-party dependencies.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation
import json
import re
from pathlib import Path

# IMPORTANT: Python \w includes Han characters; never use \w as a numeric boundary.
# Thousands separators and scientific notation are recognized for reproducible review.
NUMBER = re.compile(
    r"(?<![0-9.])(?P<value>[+\-−]?(?:(?:\d{1,3}(?:[,，]\d{3})+|\d+)(?:\.\d*)?|\.\d+)(?:[eE][+\-]?\d+)?)(?P<percent>[%％]?)(?![0-9.])"
)
CITATION = re.compile(r"\[(?:\s*\d+\s*(?:[-,，]\s*\d+\s*)*)\]|[（(][^（）()\n]{1,65}(?:19|20)\d{2}[a-z]?[^（）()\n]{0,24}[）)]")
DOI = re.compile(r"(?<![\w])10\.\d{4,9}/[^\s,，；;）)]+", re.I)
SIGNS = ("正相关", "负相关", "正向关联", "负向关联", "呈正向", "呈负向", "高于", "低于", "增加", "减少", "降低", "升高", "改善", "恶化", "显著", "未达到显著", "未达显著", "无显著")
EVIDENCE = ("证明", "证实", "导致", "因果", "相关", "关联", "可能", "不能", "无法", "未", "拟", "计划", "预期", "已经")
GROUP = re.compile(
    r"(?:干预|实验|试验|对照|控制|安慰剂|观察|治疗|高剂量|低剂量|暴露|未暴露|男性|女性|男生|女生)(?:组|人群)?|"
    r"(?:干预|治疗|随访|基线|测试)(?:前|后|时)|第\d+周|[A-Za-z]组"
)
METRIC = re.compile(
    r"(?:平均)?(?:每日)?步数|(?:抑郁症状|抑郁|焦虑|压力|睡眠质量|心理健康)?评分|"
    r"收缩压|舒张压|血压|心率|样本量|人数|体质指数|BMI|风险比|比值比|发生率|比例|均值|"
    r"变化量|回归系数|效应量|置信区间|随访时间|年龄|剂量"
)
CLAUSE_SPLITTER = re.compile(r"[，。；;！？\n]+|(?<!\d),(?!\d)")
ASSOCIATION = re.compile(
    r"(?P<label>[\u3400-\u9fffA-Za-z]{1,20}与[\u3400-\u9fffA-Za-z]{1,20})"
    r"(?:之间)?(?:呈|存在|为|显示|表现为|具有)?(?P<sign>正相关|负相关|正向关联|负向关联)"
)


def _clean(text: str) -> str:
    return DOI.sub("", CITATION.sub("", text)).replace("−", "-")


def _norm_number(match: re.Match) -> str | None:
    raw = match.group("value").replace("−", "-").replace(",", "").replace("，", "")
    try:
        num = Decimal(raw)
    except InvalidOperation:
        return None
    return f"{format(num.normalize(), "f")}{'%' if match.group('percent') else ''}"


def numbers(text: str) -> Counter[str]:
    """Multiset of values, including `125人`, `30mg`, `7天`, `12.4分`."""
    found: Counter[str] = Counter()
    for match in NUMBER.finditer(_clean(text)):
        value = _norm_number(match)
        if value is not None:
            found[value] += 1
    return found


def citations(text: str) -> Counter[str]:
    found = [re.sub(r"\s+", "", m.group()) for m in CITATION.finditer(text)]
    found += [m.group().rstrip(".") for m in DOI.finditer(text)]
    return Counter(found)


def _changed(a: Counter, b: Counter) -> tuple[list[str], list[str]]:
    return list((a - b).elements()), list((b - a).elements())


def _value_bindings(text: str) -> dict[str, Counter[str]]:
    """Extract obvious value->group/metric matches, independent of clause order.

    Deliberately does NOT guess links spanning multiple clauses or infer unseen
    variables. A binding is a *candidate* and must be human-checked.
    """
    bindings: dict[str, Counter[str]] = defaultdict(Counter)
    for clause in CLAUSE_SPLITTER.split(_clean(text)):
        for value in NUMBER.finditer(clause):
            prefix = clause[max(0, value.start() - 70):value.start()]
            # Ignore a value without a reasonably local noun anchor.
            groups = list(GROUP.finditer(prefix))
            metrics = list(METRIC.finditer(prefix))
            if not groups and not metrics:
                continue
            # A sample value with two groups in the same clause is ambiguous;
            # avoid pretending the extraction proved which group it belongs to.
            group = groups[-1].group() if groups else ""
            metric = metrics[-1].group() if metrics else ""
            if not group and metric in {"均值", "比例", "变化量", "评分"}:
                continue
            anchor = f"{group}|{metric}"
            v = _norm_number(value)
            if v is not None:
                bindings[anchor][v] += 1
    return bindings


def _direction_bindings(text: str) -> dict[str, Counter[str]]:
    pairs: dict[str, Counter[str]] = defaultdict(Counter)
    for clause in CLAUSE_SPLITTER.split(text):
        for hit in ASSOCIATION.finditer(clause):
            pairs[hit.group("label")][hit.group("sign")] += 1
    return pairs


# Comparison hypotheses are not interchangeable. A difference/contrast hypothesis is
# NOT evidence for superiority, inferiority, equivalence or non-inferiority.
# These are *review cues*, not a Chinese natural-language inference engine.
COMPARATIVE_DIRECTION = re.compile(
    r"(?:优于|胜过|劣于|不劣于|非劣(?:效)?|等效(?:性)?|优效(?:性)?|"
    r"(?:比|较).{0,24}(?:更(?:好|优|有效)|效果更(?:强|高|好))|"
    r"(?:效果|效益|收益).{0,5}(?:更(?:好|优|大|高)|较(?:好|高|强))|"
    r"(?:更(?:好|优|有效)).{0,12}(?:基础策略|对照组|策略[A-C]|策略S\*|方案[A-C]))"
)
COMPARISON_UNCERTAIN = re.compile(r"(?:是否|能否|可否|可能|拟|计划|旨在|假设|尚待|有待|不确定|未证实|不能确定|尚不能断言)")
COMPARISON_NEGATED = re.compile(r"(?:不能|无法|尚不能|不支持|不能据此|无法证实|未证明|未显示|未见|否定|不应|不宜|(?:不|未能|没有|并非)\s*(?:优于|劣于|等效|不劣于))")
DIFFERENCE_HYPOTHESIS = re.compile(r"区别于|不同于|是否(?:存在|具有)?差异|是否不同|有无差异|比较.{0,24}(?:差异|不同)|差异比较|区别")
SCOPE_LOCK = ("仅在本样本", "在本样本中", "仅针对", "尚不能", "不能据此", "不意味着", "未达到统计学显著", "预期", "拟开展")
PRIOR_COMPARATIVE_SOURCE = re.compile(r"既往研究|此前研究|前人|现有研究|已有研究|文献报道|文献显示|其他研究")
CURRENT_COMPARATIVE_SOURCE = re.compile(r"本研究|本试验|本项目|本调查|我们的研究|本文")
UNIT_TOKENS = sorted(("分钟", "小时", "毫克", "微克", "毫升", "千克", "公里", "千米", "个月", "mg", "μg", "mcg", "mL", "ml", "kg", "cm", "mm", "km", "天", "日", "周", "月", "年", "秒", "步", "分", "人", "名", "例", "次", "项"), key=len, reverse=True)
UNIT_EQUIV = {"名": "人", "例": "人", "日": "天", "毫克": "mg", "微克": "μg", "mcg": "μg", "毫升": "ml", "mL": "ml", "千克": "kg", "千米": "km", "公里": "km"}
STAT_COMPARATOR = re.compile(r"(?<![A-Za-z0-9_])(?P<stat>[Pp]|n|N)\s*(?P<op>[<>≤≥=＝≠])\s*(?P<value>[+\-−]?(?:\d*\.\d+|\d+(?:\.\d+)?))")


def _unit_bindings(text: str) -> dict[str, Counter[str]]:
    bindings: dict[str, Counter[str]] = defaultdict(Counter)
    t = _clean(text)
    for number in NUMBER.finditer(t):
        value = _norm_number(number)
        if value is None:
            continue
        unit = "%" if number.group("percent") else None
        if unit is None:
            suffix = t[number.end():number.end()+6]
            for choice in UNIT_TOKENS:
                if suffix.startswith(choice):
                    unit = UNIT_EQUIV.get(choice, choice)
                    break
        if unit:
            bindings[value][unit] += 1
    return bindings


def _stat_comparators(text: str) -> dict[tuple[str, str], Counter[str]]:
    found: dict[tuple[str, str], Counter[str]] = defaultdict(Counter)
    for match in STAT_COMPARATOR.finditer(_clean(text)):
        # Keep number text stable, compare the relationship operator only.
        try:
            value = format(Decimal(match.group("value").replace("−", "-")).normalize(), "f")
        except InvalidOperation:
            continue
        found[(match.group("stat").lower(), value)][match.group("op").replace("＝", "=")] += 1
    return found



def _comparisons(text: str) -> list[dict]:
    """Extract comparisons and uncertainty. Review may still be a false positive."""
    found: list[dict] = []
    for match in COMPARATIVE_DIRECTION.finditer(text):
        lo, hi = match.span()
        # Only a nearby window: don't ascribe "拟" from another study/paragraph.
        left = text[max(0, lo - 45):lo]
        # Restrict scope to same clause, with a longer lookback for "拟比较".
        left = re.split(r"[。；!?！？\n]", left)[-1]
        right = text[hi:min(len(text), hi + 18)]
        vicinity = left + match.group() + right
        kind = "qualified" if COMPARISON_UNCERTAIN.search(vicinity) or COMPARISON_NEGATED.search(vicinity) else "asserted"
        prior = list(PRIOR_COMPARATIVE_SOURCE.finditer(left))
        current = list(CURRENT_COMPARATIVE_SOURCE.finditer(left))
        if prior or current:
            source = "prior" if (prior[-1].start() if prior else -1) > (current[-1].start() if current else -1) else "current"
        else:
            source = "unspecified"
        found.append({"term": match.group(), "kind": kind, "source": source,
                      "excerpt": text[max(0, lo - 32):min(len(text), hi + 32)]})
    return found


def _comparison_shift(before: str, after: str) -> dict | None:
    old, new = _comparisons(before), _comparisons(after)
    if not new:
        return None
    # Compare type/quantity, not only presence. Unchanged propositions moved
    # across paragraphs do not automatically trigger a superiority alarm.
    old_lex = Counter((x["term"], x["kind"], x["source"]) for x in old)
    new_lex = Counter((x["term"], x["kind"], x["source"]) for x in new)
    if new_lex == old_lex:
        return None
    new_items = []
    leftovers = old_lex.copy()
    for hit in new:
        key = (hit["term"], hit["kind"], hit["source"])
        if leftovers[key]:
            leftovers[key] -= 1
        else:
            new_items.append(hit)
    if not new_items:
        return None
    # Do not pretend to resolve the research question. Expose the possible
    # superiority/equivalence upgrade for human approval.
    return {
        "type": "comparison_hypothesis_shift", "severity": "critical-review",
        "before_difference_cue": bool(DIFFERENCE_HYPOTHESIS.search(before)),
        "before_comparisons": old, "introduced_comparisons": new_items,
        "hint": "比较目标或结果强度可能从‘有差异/区别于’升级为‘优于/劣于/等效/非劣’；需核对作者假设、预注册与证据，不可自行改写",
    }


def _scope_changes(before: str, after: str) -> list[dict]:
    """Critical qualifiers lost: report exact cue and context, not a verdict."""
    flagged = []
    for cue in SCOPE_LOCK:
        if cue == "在本样本中" and "仅在本样本中" in before:
            continue  # avoid double counting an overlapping, longer qualifier
        if before.count(cue) > after.count(cue):
            flagged.append({"type": "essential_qualifier_removed", "severity": "high-review",
                            "cue": cue, "before_count": before.count(cue), "after_count": after.count(cue),
                            "hint": "原稿含研究范围/证据/不确定性限定，修订后减少；检查是否属于同义替换或不当删除"})
    return flagged


def compare_versions(before: str, after: str) -> list[dict]:
    flags: list[dict] = []
    if before == after:
        return flags
    old_numbers, new_numbers = _changed(numbers(before), numbers(after))
    if old_numbers or new_numbers:
        flags.append({
            "type": "numbers_changed", "severity": "critical-review",
            "removed": old_numbers, "added": new_numbers,
            "hint": "有数字增加/减少，检查样本量、方向、百分数、单位和统计值；格式差异也可能是候选误报",
        })
    old_units, new_units = _unit_bindings(before), _unit_bindings(after)
    for value in sorted(old_units.keys() & new_units.keys()):
        if old_units[value] != new_units[value]:
            flags.append({"type": "unit_binding_changed", "severity": "critical-review",
                          "value": value, "old_units": list(old_units[value].elements()),
                          "new_units": list(new_units[value].elements()),
                          "hint": "相同数字附近的单位发生变化；检查分/分钟、天/周、mg/μg等，不要因为数字相同就当成保真"})
    old_stats, new_stats = _stat_comparators(before), _stat_comparators(after)
    for anchor in sorted(old_stats.keys() & new_stats.keys()):
        if old_stats[anchor] != new_stats[anchor]:
            flags.append({"type": "stat_comparator_changed", "severity": "critical-review",
                          "stat": anchor[0], "value": anchor[1],
                          "before_operators": list(old_stats[anchor].elements()),
                          "after_operators": list(new_stats[anchor].elements()),
                          "hint": "统计比较符改变（例如 P<0.05→P>0.05），必须对照原始统计输出"})
    before_bind, after_bind = _value_bindings(before), _value_bindings(after)
    for anchor in sorted(before_bind.keys() & after_bind.keys()):
        if before_bind[anchor] != after_bind[anchor]:
            flags.append({
                "type": "number_binding_changed", "severity": "critical-review",
                "anchor": anchor, "before_values": list(before_bind[anchor].elements()),
                "after_values": list(after_bind[anchor].elements()),
                "hint": "同一组别/指标的数值归属发生变化；即使数字集合不变也需重点人工核对",
            })
    possible_shift = _comparison_shift(before, after)
    if possible_shift:
        flags.append(possible_shift)
    flags.extend(_scope_changes(before, after))
    old_cites, new_cites = _changed(citations(before), citations(after))
    if old_cites or new_cites:
        flags.append({"type": "citations_changed", "severity": "critical-review", "removed": old_cites,
                      "added": new_cites, "hint": "核查引文的遗漏/新增以及它与论断的对应关系"})
    for term in SIGNS:
        old, new = before.count(term), after.count(term)
        if old != new:
            flags.append({"type": "direction_or_significance_cue_changed", "severity": "high-review",
                          "cue": term, "before_count": old, "after_count": new,
                          "hint": "核对方向、否定、显著性及是否合理更正原文中的推断错误"})
    before_dir, after_dir = _direction_bindings(before), _direction_bindings(after)
    for anchor in sorted(before_dir.keys() & after_dir.keys()):
        if before_dir[anchor] != after_dir[anchor]:
            flags.append({"type": "direction_binding_changed", "severity": "critical-review",
                          "anchor": anchor, "before_directions": list(before_dir[anchor].elements()),
                          "after_directions": list(after_dir[anchor].elements()),
                          "hint": "同一变量关系的方向发生变化；全篇正/负词频不变也可能是语义反转"})
    changed_evidence = [term for term in EVIDENCE if (term in before) != (term in after)]
    if changed_evidence:
        flags.append({"type": "claim_strength_or_scope_cue_changed", "severity": "high-review",
                      "cues": changed_evidence,
                      "hint": "核对因果、计划/完成、否定和范围；正确纠错需给出依据而非暗改"})
    if not flags:
        flags.append({"type": "unverified_semantic_change", "severity": "manual-review",
                      "hint": "字词已改变但规则未识别具体差异；必须人工逐句核对事实锁和引用"})
    return flags


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("before", type=Path)
    p.add_argument("after", type=Path)
    p.add_argument("--format", choices=["markdown", "json"], default="markdown")
    args = p.parse_args()
    if not args.before.is_file() or not args.after.is_file():
        p.error("Before/after must be existing UTF-8 files")
    try:
        before = args.before.read_text(encoding="utf-8")
        after = args.after.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        p.error("Expected UTF-8 input")
    flags = compare_versions(before, after)
    warning = "数值/归属/引文/方向的启发式差异提示；不验证科学事实或语义等价，零提示不表示保真通过"
    if args.format == "json":
        print(json.dumps({"before": str(args.before), "after": str(args.after), "warning": warning,
                          "changed": before != after, "flags": flags}, ensure_ascii=False, indent=2))
    else:
        print("# 修改前后科研事实候选核查（只读）\n\n" + warning + "\n")
        if before == after:
            print("文本完全一致；并不表明原文事实正确。")
        else:
            for flag in flags:
                print(f"- {flag['severity']} / `{flag['type']}`：{flag['hint']}")
                for key in ("anchor", "removed", "added", "before_values", "after_values", "before_directions",
                            "after_directions", "cue", "cues", "before_count", "after_count", "before_difference_cue", "before_comparisons", "introduced_comparisons", "value", "old_units", "new_units", "stat", "before_operators", "after_operators"):
                    if key in flag:
                        print(f"  - {key}: `{flag[key]}`")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
