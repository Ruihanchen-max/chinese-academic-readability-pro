#!/usr/bin/env python3
"""Read-only screening of removable meta-copy inside native PPTX figure text.

It never mutates slides and cannot establish scientific correctness/visual quality.
Uses Python's standard library; extracts editable PowerPoint text runs only.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET
from zipfile import ZipFile, BadZipFile

NS_A='http://schemas.openxmlformats.org/drawingml/2006/main'
PHRASES=(
    ('core_difference','核心区别'),
    ('non_result_disclaimer','不代表试验结果'),
    ('non_result_disclaimer','不代表实验结果'),
    ('demonstration_preface','研究切入点示意'),
    ('meta_explanation','本图仅'),
    ('meta_explanation','本图说明'),
    ('meta_explanation','请注意'),
)

def audit_pptx(path: Path) -> dict:
    if not path.is_file() or path.suffix.lower()!='.pptx':
        raise ValueError('Expected an existing .pptx file')
    try:
        with ZipFile(path) as z:
            slides=sorted((n for n in z.namelist() if re.fullmatch(r'ppt/slides/slide\d+\.xml',n)),
                          key=lambda n:int(re.search(r'slide(\d+)',n).group(1)))
            if not slides: raise ValueError('No PPTX slide parts')
            labels=[]
            for slide_idx,name in enumerate(slides,1):
                root=ET.fromstring(z.read(name))
                for node in root.findall(f'.//{{{NS_A}}}p'):
                    words=[(n.text or '') for n in node.findall(f'.//{{{NS_A}}}t')]
                    s=''.join(words).strip()
                    if s:labels.append({'slide':slide_idx,'text':s})
    except (BadZipFile,ET.ParseError,KeyError) as e:
        raise ValueError('Corrupt PPTX or slide XML') from e
    flags=[]
    for item in labels:
        for tag,needle in PHRASES:
            if needle in item['text']:
                flags.append({'slide':item['slide'],'category':tag,'phrase':needle,
                              'label':item['text']})
    return {
        'status':'REVIEW_ONLY',
        'source':str(path),
        'slide_count':len(slides),
        'editable_text_items':len(labels),
        'total_visible_text_characters':sum(len(item['text']) for item in labels),
        'meta_copy_candidates':flags,
        'candidate_count':len(flags),
        'note':'Review cues only; scientific/visual quality and necessary disclosures are unverified. Keep essential labels and place scientific context in external caption as appropriate.',
    }

def main() -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('pptx',type=Path)
    p.add_argument('--out-json',type=Path)
    args=p.parse_args()
    try: result=audit_pptx(args.pptx)
    except ValueError as e:
        print(f'ERROR: {e}');return 2
    data=json.dumps(result,indent=2,ensure_ascii=False)
    if args.out_json:
        args.out_json.parent.mkdir(parents=True,exist_ok=True)
        args.out_json.write_text(data+'\n',encoding='utf-8')
    print(data)
    return 0

if __name__=='__main__':raise SystemExit(main())
