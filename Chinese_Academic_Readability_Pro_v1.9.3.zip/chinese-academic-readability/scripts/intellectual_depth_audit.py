#!/usr/bin/env python3
"""Advisory audit of a manually annotated scholarly argument map.

This does NOT read a paper and judge its intellectual depth. It checks whether
an Agent/human-created annotation has missing reasoning/evidence, unaddressed
high-priority considerations or likely perfectionist scope creep. The source
paper and citations must be reviewed separately. Standard library only.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import re

PROFILES = {
    "course-preproposal", "grant-proposal", "formal-protocol",
    "empirical-manuscript", "theory-paper", "review-paper",
}
CRITICAL_KINDS = {"central_comparison", "causal_explanation", "mechanism", "design_rationale"}
PRIORITIES = {"CRITICAL", "IMPORTANT", "OPTIONAL"}
ACTIONS = {"include_body", "brief_note", "defer_protocol", "omit", "needs_source"}
CLAIM_STATES = {"hypothesis", "planned", "established", "interpretation"}
EVIDENCE_STATES = {"verified", "provided_not_verified", "needs_source"}
_UNQUALIFIED = re.compile(r"(?:首次揭示|证明了|必然|彻底|均能|全部有效|已经证实|确定能够)")


def _nonempty(value: object) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _flag(code: str, location: str, why: str, level: str = "REVIEW") -> dict:
    return {"code": code, "location": location, "level": level, "reason": why}


def audit(payload: dict) -> dict:
    if not isinstance(payload, dict):
        raise ValueError("Top-level input must be an object")
    profile = payload.get("profile")
    if profile not in PROFILES:
        raise ValueError("profile must be a supported explicit writing type")
    arguments = payload.get("core_arguments")
    considerations = payload.get("considerations", [])
    locks = payload.get("study_locks", [])
    if not isinstance(arguments, list) or not isinstance(considerations, list) or not isinstance(locks, list):
        raise ValueError("core_arguments, considerations, study_locks must be arrays")

    issues: list[dict] = []
    flags: list[dict] = []
    if not arguments:
        issues.append(_flag("NO_CORE_ARGUMENT", "core_arguments", "至少标注一个核心论点", "BLOCK"))
    if len(arguments) > 3:
        flags.append(_flag("TOO_MANY_CORE_ARGUMENTS", "core_arguments",
                           "通常只选 1—3 个真正决定研究的命题；并非强制限制复杂论文"))

    seen = set()
    for i, arg in enumerate(arguments):
        where = f"core_arguments[{i}]"
        if not isinstance(arg, dict):
            raise ValueError(f"{where} must be an object")
        ident = arg.get("id")
        if not _nonempty(ident) or ident in seen:
            raise ValueError(f"{where}.id must be nonempty and unique")
        seen.add(ident)
        kind = arg.get("kind", "scientific_rationale")
        state = arg.get("state", "interpretation")
        if state not in CLAIM_STATES:
            raise ValueError(f"{where}.state not allowed: {state!r}")
        for name in ("claim", "question", "reasoning", "boundary"):
            if not _nonempty(arg.get(name)):
                issues.append(_flag("MISSING_" + name.upper(), str(ident),
                                    f"{name} 缺失；必须给出具体的可供核查的学术内容", "BLOCK"))
        evidence = arg.get("evidence", [])
        if not isinstance(evidence, list):
            raise ValueError(f"{where}.evidence must be an array")
        if not evidence:
            issues.append(_flag("MISSING_EVIDENCE_ANCHOR", str(ident),
                                "缺原始文献/原稿/理论依据的锚点，不能用修辞补齐", "BLOCK"))
        for j, src in enumerate(evidence):
            if not isinstance(src, dict):
                raise ValueError(f"{where}.evidence[{j}] must be an object")
            if not _nonempty(src.get("anchor")):
                issues.append(_flag("EMPTY_EVIDENCE_ANCHOR", str(ident), "来源锚点为空", "BLOCK"))
            if src.get("status") not in EVIDENCE_STATES:
                raise ValueError(f"{where}.evidence[{j}].status must be one of {sorted(EVIDENCE_STATES)}")
            if src.get("status") == "needs_source":
                issues.append(_flag("UNSOURCED_CLAIM", str(ident), "该论证需要补充来源或明确假设身份", "BLOCK"))
            elif src.get("status") == "provided_not_verified":
                flags.append(_flag("SOURCE_NOT_INDEPENDENTLY_VERIFIED", str(ident),
                                   "有原稿/用户来源但未独立核实，不能对外宣称已查证"))

        if kind in CRITICAL_KINDS and not (
            _nonempty(arg.get("rival_explanation")) or _nonempty(arg.get("why_rival_not_applicable"))
        ):
            issues.append(_flag("RIVAL_REVIEW_MISSING", str(ident),
                                "核心解释/比较需考虑最相关竞争解释，或明确说明不适用原因", "BLOCK"))
        if kind in {"causal_explanation", "mechanism"} and not _nonempty(arg.get("testability_limit")):
            issues.append(_flag("CAUSAL_LIMIT_MISSING", str(ident),
                                "机制/因果判断必须指出设计可以及不能识别的内容", "BLOCK"))
        if state in {"planned", "hypothesis"} and _nonempty(arg.get("claim")) and _UNQUALIFIED.search(arg["claim"]):
            issues.append(_flag("UNQUALIFIED_FUTURE_EFFECT", str(ident),
                                "尚未完成研究或假设不应声称已证明/必然有效", "BLOCK"))

    seen_considerations = set()
    for i, item in enumerate(considerations):
        where = f"considerations[{i}]"
        if not isinstance(item, dict):
            raise ValueError(f"{where} must be an object")
        ident = item.get("id")
        if not _nonempty(ident) or ident in seen_considerations:
            raise ValueError(f"{where}.id must be nonempty and unique")
        seen_considerations.add(ident)
        priority, action = item.get("priority"), item.get("action")
        if priority not in PRIORITIES or action not in ACTIONS:
            raise ValueError(f"{where} priority/action invalid")
        if not _nonempty(item.get("issue")) or not _nonempty(item.get("reason")):
            flags.append(_flag("CONSIDERATION_NEEDS_EXPLANATION", str(ident),
                               "候选问题需写清为何影响研究，不能仅列问题名称"))
        if priority == "CRITICAL" and action in {"omit", "defer_protocol"}:
            issues.append(_flag("CRITICAL_ISSUE_DEFERRED", str(ident),
                                "核心科学问题、比较、结果解释或伦理安全事项不能仅为精简而隐去", "BLOCK"))
        if priority == "CRITICAL" and action == "needs_source":
            issues.append(_flag("CRITICAL_EVIDENCE_UNRESOLVED", str(ident),
                                "关键问题尚需来源或作者确认，不可宣称修改完成", "BLOCK"))
        if priority == "OPTIONAL" and action == "include_body":
            flags.append(_flag("POSSIBLE_SCOPE_CREEP", str(ident),
                               "非关键实施/细节进入正文，复核是否为了追求完美而扩写"))
        if priority == "IMPORTANT" and action == "omit":
            flags.append(_flag("IMPORTANT_OMISSION_REVIEW", str(ident),
                               "重要解释被省略，须核对目标读者是否会误解"))

    for i, lock in enumerate(locks):
        where = f"study_locks[{i}]"
        if not isinstance(lock, dict):
            raise ValueError(f"{where} must be an object")
        if not _nonempty(lock.get("id")):
            raise ValueError(f"{where}.id required")
        if lock.get("preserved") is False:
            issues.append(_flag("CORE_DESIGN_LOCK_BROKEN", str(lock["id"]),
                                "核心设计锁发生变化，必须 STOP & REVIEW", "BLOCK"))
        elif lock.get("preserved") is not True:
            flags.append(_flag("CORE_DESIGN_LOCK_UNVERIFIED", str(lock["id"]),
                               "尚未完成对来源的设计锁核查"))
    if not locks:
        flags.append(_flag("NO_DESIGN_LOCK_EVIDENCE", "study_locks",
                           "未给出设计锁核查记录；仅凭论证表不能证明核心设计不变"))

    if issues:
        status = "STOP_AND_REVIEW"
    elif flags:
        status = "REVIEW_OPEN_ITEMS"
    else:
        status = "SCOPED_STOP_READY_FOR_HUMAN_REVIEW"
    return {
        "tool": "intellectual_depth_audit",
        "document_profile": profile,
        "result_type": "ANNOTATION_COMPLETENESS_AND_PRIORITY_REVIEW_ONLY",
        "status": status,
        "core_argument_count": len(arguments),
        "consideration_count": len(considerations),
        "blocking_items": issues,
        "review_items": flags,
        "source_claims_verified": False,
        "independent_reader_effect_tested": False,
        "interpretation": "即使无缺口也只是当前人工账本就绪；不是学术深度、可读性或事实保真的客观评分",
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("annotation_json", type=Path, help="Hand-annotated argument/priority map")
    ap.add_argument("--out-json", type=Path)
    args = ap.parse_args()
    try:
        payload = json.loads(args.annotation_json.read_text(encoding="utf-8"))
        result = audit(payload)
        encoded = json.dumps(result, ensure_ascii=False, indent=2)
        if args.out_json:
            args.out_json.parent.mkdir(parents=True, exist_ok=True)
            args.out_json.write_text(encoded + "\n", encoding="utf-8")
        print(encoded)
        return 0 if result["status"] != "STOP_AND_REVIEW" else 2
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        ap.exit(1, f"ERROR: {exc}\n")


if __name__ == "__main__":
    raise SystemExit(main())
