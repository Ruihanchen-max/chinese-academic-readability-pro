#!/usr/bin/env python3
"""Balanced, single-exposure A/B/C reading packets (stdlib only).

Each reader gets one version per source case, NEVER all A/B/C versions together.
Across every 3 consecutive readers each source case is assigned A/B/C exactly
once. This is an assignment tool, not an independent reader or score estimator.

The private assignment key is written OUTSIDE the shareable directory.
No automatic redaction or permission to disclose unpublished manuscripts.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import random
import re
import uuid

ARMS = {"A", "B", "C"}
DEFAULT_QUESTIONS = [
    "用自己的话说明本段核心论点/研究目的。",
    "指出作者真正使用的依据，以及依据不足的位置。",
    "作者已经得出了什么结论？哪些内容仍属于假设或计划？",
    "有哪些比较对象、限定条件或因果边界不应被忽略？",
]


def _validate(data: dict, reviewers: int) -> list[dict]:
    if reviewers < 3 or reviewers % 3 != 0 or reviewers > 300:
        raise ValueError("reviewers must be a multiple of 3 between 3 and 300")
    if not isinstance(data, dict) or not isinstance(data.get("cases"), list) or not data["cases"]:
        raise ValueError("Input requires a nonempty cases array")
    found = set()
    for case in data["cases"]:
        cid = case.get("id")
        if not isinstance(cid, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,60}", cid) or cid in found:
            raise ValueError("case id missing, invalid or duplicated")
        found.add(cid)
        versions = case.get("variants")
        if not isinstance(versions, dict) or set(versions) != ARMS:
            raise ValueError(f"{cid}: exact A/B/C variants required")
        if any(not isinstance(v, str) or not v.strip() for v in versions.values()):
            raise ValueError(f"{cid}: nonempty text required in all variants")
        if "questions" in case and (not isinstance(case["questions"], list) or not case["questions"]
                                    or any(not isinstance(q, str) or not q.strip() for q in case["questions"])):
            raise ValueError(f"{cid}: questions must be nonempty strings")
    return data["cases"]


def assign(data: dict, reviewers: int = 12, seed: int = 20261122) -> tuple[dict, dict]:
    """Returns (public reader-number -> pages, private assignment key)."""
    cases = _validate(data, reviewers)
    rng = random.Random(seed)
    arm_per_case: dict[str, list[str]] = {}
    for case in cases:
        arms = ["A", "B", "C"]
        rng.shuffle(arms)
        arm_per_case[case["id"]] = arms
    public: dict[str, list[dict]] = {}
    private: dict[str, dict] = {}
    for idx in range(reviewers):
        reader = f"R{idx+1:03d}"
        records = []
        mapping = {}
        for case in cases:
            cid = case["id"]
            arm = arm_per_case[cid][idx % 3]
            passage = case["variants"][arm]
            mapping[cid] = {"arm": arm, "sha256": hashlib.sha256(passage.encode("utf-8")).hexdigest()}
            records.append({"case_id": cid, "passage": passage,
                            "questions": case.get("questions", DEFAULT_QUESTIONS)})
        rng.shuffle(records)
        public[reader] = records
        private[reader] = mapping
    return public, {"design": "balanced_single_exposure", "reviewers": reviewers,
                    "seed": seed, "key": private,
                    "answers": {c["id"]: c["answer_key"] for c in cases if "answer_key" in c}}


def _render_reader(reader: str, records: list[dict]) -> str:
    parts = [f"# 匿名读者材料 · 编号 {reader}", "",
             "每段只展示一个匿名版本。请独立阅读，不查询作者原稿，不猜测使用何种工具。",
             "可在各题下作答。遇到原文没有证据的内容，请写‘文本中未提供’，不要自行补齐。",
             "随后分别对理解清晰度、中文自然度、阅读负担评分（1=差/高负担，7=好/低负担）。", ""]
    for n, item in enumerate(records, 1):
        parts += [f"## 文本 {n}（材料码 {item['case_id']}）", "", item["passage"], "", "### 理解题", ""]
        for k, q in enumerate(item["questions"], 1):
            parts += [f"{k}. {q}", "", "答：", ""]
        parts += ["清晰度（1–7）：___；中文自然度（1–7）：___；阅读负担（1–7，7=低负担）：___", "",
                  "最影响理解的原文位置（可不填）：___", ""]
    return "\n".join(parts).rstrip() + "\n"


def write_packets(public: dict, key: dict, reviewer_dir: Path, private_dir: Path) -> tuple[Path, Path]:
    reviewer_dir, private_dir = reviewer_dir.expanduser().resolve(), private_dir.expanduser().resolve()
    if reviewer_dir == private_dir or reviewer_dir in private_dir.parents or private_dir in reviewer_dir.parents:
        raise ValueError("PRIVATE directory cannot be the public directory or its child")
    if reviewer_dir.exists() and any(reviewer_dir.iterdir()):
        raise FileExistsError("public reviewer directory must be empty; refuse overwrite")
    reviewer_dir.mkdir(parents=True, exist_ok=True)
    private_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        private_dir.chmod(0o700)
    except OSError:
        pass
    private_file = private_dir / f"assignment_{uuid.uuid4().hex}.json"
    fd = os.open(private_file, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    created = []
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(key, stream, ensure_ascii=False, indent=2)
        for reader, records in public.items():
            file = reviewer_dir / f"reader_{reader}.md"
            with file.open("x", encoding="utf-8") as stream:
                stream.write(_render_reader(reader, records))
            created.append(file)
        readme = reviewer_dir / "评审者须知.md"
        with readme.open("x", encoding="utf-8") as stream:
            stream.write("# 匿名阅读使用说明\n\n每位读者仅接收与自身编号相符的一份 reader_Rxxx.md。不要将全目录同时发给一人。请按研究组织者的方式交回答卷。\n\n材料可能来自未发表科研稿，请遵循作者授权、保密和期刊政策。此目录不含版本答案映射，但不自动去除段落内自报来源。\n")
        created.append(readme)
    except BaseException:
        for file in created:
            file.unlink(missing_ok=True)
        private_file.unlink(missing_ok=True)
        raise
    return reviewer_dir, private_file


def default_private_dir() -> Path:
    xdg = os.environ.get("XDG_STATE_HOME")
    return (Path(xdg) if xdg else Path.home() / ".local" / "state") / "chinese-academic-readability" / "reader-keys"


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("input", type=Path, help="JSON cases with exact A/B/C variants and optional questions/answer_key")
    p.add_argument("reviewer_dir", type=Path, help="Folder for blinded reader packets; use an empty path")
    p.add_argument("--reviewers", type=int, default=12, help="Number of independent readers, multiple of 3 (default 12)")
    p.add_argument("--seed", type=int, default=20261122)
    p.add_argument("--private-dir", type=Path, default=None, help="PRIVATE key directory outside public folder")
    args = p.parse_args()
    try:
        data = json.loads(args.input.read_text(encoding="utf-8"))
        public, key = assign(data, args.reviewers, args.seed)
        folder, priv = write_packets(public, key, args.reviewer_dir,
                                     args.private_dir if args.private_dir else default_private_dir())
    except (OSError, ValueError, json.JSONDecodeError) as ex:
        p.error(str(ex))
    print(f"PUBLIC: {folder}; {len(public)} one-version-per-case readers")
    print(f"PRIVATE: {priv} (NEVER share, no automatic redaction)")
    print("NOT RESULTS: real independent reader answers have not been collected")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
