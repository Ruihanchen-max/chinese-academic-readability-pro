#!/usr/bin/env python3
"""Render a DOCX using a *recorded* engine, export PDF and every-page PNG.

No silent renderer substitution. Unsupported Word automation is UNVERIFIED.
Requires: PyMuPDF; LibreOffice for --engine libreoffice/auto; pywin32 on Windows for Word.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import tempfile
from typing import Any


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def convert_docx(docx: Path, out_dir: Path, engine: str = 'auto', timeout: int = 180,
                 dpi: int = 150, png: bool = True) -> dict[str, Any]:
    docx = Path(docx).resolve()
    out_dir = Path(out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    result: dict[str, Any] = {'status': 'UNVERIFIED', 'docx_sha256': None,
                              'engine_requested': engine, 'engine_used': None,
                              'pdf_path': None, 'pages': 0, 'page_images': [],
                              'reason': None}
    if not docx.is_file():
        result['reason'] = f'Input DOCX not found: {docx}'
        return result
    result['docx_sha256'] = sha256(docx)
    pdf_path = out_dir / f'{docx.stem}.pdf'
    # Never accept a stale PDF from an earlier conversion run.
    if pdf_path.exists():
        pdf_path.unlink()
    if engine == 'auto':
        engine = 'libreoffice' if shutil.which('libreoffice') or shutil.which('soffice') else 'word'
    result['engine_used'] = engine
    try:
        if engine == 'libreoffice':
            exe = shutil.which('libreoffice') or shutil.which('soffice')
            if not exe:
                result['reason'] = 'LibreOffice executable not found; cannot render'
                return result
            try:
                version = subprocess.run([exe, '--version'], capture_output=True, text=True, timeout=12)
                result['engine_version'] = (version.stdout or version.stderr).strip()[:150]
            except (OSError, subprocess.TimeoutExpired):
                result['engine_version'] = 'Unknown'
            with tempfile.TemporaryDirectory(prefix='readability-lo-') as tmp:
                src_dir = Path(tmp) / 'source'
                src_dir.mkdir()
                isolated = src_dir / docx.name
                shutil.copy2(docx, isolated)
                profile = (Path(tmp) / 'lo_profile').as_uri()
                command = [exe, f'-env:UserInstallation={profile}', '--headless', '--convert-to',
                           'pdf:writer_pdf_Export', '--outdir', str(out_dir), str(isolated)]
                completed = subprocess.run(command, capture_output=True, text=True,
                                           timeout=timeout, cwd=tmp)
                result['converter_returncode'] = completed.returncode
                result['converter_log'] = ((completed.stdout or '') + '\n' + (completed.stderr or ''))[:1200]
            if completed.returncode or not pdf_path.is_file():
                result['status'] = 'FAIL'
                result['reason'] = 'LibreOffice conversion failed / PDF not produced'
                return result
        elif engine == 'word':
            if platform.system() != 'Windows':
                result['reason'] = 'Microsoft Word COM export is supported only on Windows; no fallback to LibreOffice'
                return result
            try:
                import win32com.client  # type: ignore
            except ImportError:
                result['reason'] = 'pywin32 is unavailable; Microsoft Word export was not run'
                return result
            word = None
            document = None
            try:
                word = win32com.client.DispatchEx('Word.Application')
                word.Visible = False
                word.DisplayAlerts = 0
                document = word.Documents.Open(str(docx), ReadOnly=True)
                document.ExportAsFixedFormat(str(pdf_path), 17)
                result['engine_version'] = str(word.Version)
            finally:
                if document:
                    document.Close(False)
                if word:
                    word.Quit()
        else:
            result['status'] = 'FAIL'
            result['reason'] = f'Unknown engine: {engine}'
            return result
        if not pdf_path.is_file() or pdf_path.stat().st_size < 300:
            result['status'] = 'FAIL'
            result['reason'] = 'PDF export missing or unexpectedly small'
            return result
        import fitz
        with fitz.open(pdf_path) as pdf:
            result['pages'] = len(pdf)
            if not len(pdf):
                result['status'] = 'FAIL'
                result['reason'] = 'Empty PDF'
                return result
            if png:
                image_dir = out_dir / 'pages'
                image_dir.mkdir(exist_ok=True)
                zoom = dpi / 72.0
                paths = []
                for i, page in enumerate(pdf, 1):
                    png_path = image_dir / f'page-{i:03}.png'
                    page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False).save(png_path)
                    paths.append(str(png_path))
                result['page_images'] = paths
                result['page_image_sha256'] = {str(i): sha256(Path(path)) for i, path in enumerate(paths, 1)}
        result['pdf_path'] = str(pdf_path)
        result['pdf_sha256'] = sha256(pdf_path)
        result['status'] = 'PASS'
        return result
    except (OSError, subprocess.TimeoutExpired, RuntimeError, ValueError) as exc:
        result['status'] = 'FAIL'
        result['reason'] = f'{type(exc).__name__}: {str(exc)[:250]}'
        return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('docx', type=Path)
    parser.add_argument('--out-dir', type=Path, required=True)
    parser.add_argument('--engine', choices=['auto', 'libreoffice', 'word'], default='auto')
    parser.add_argument('--dpi', type=int, default=150)
    parser.add_argument('--timeout', type=int, default=180)
    parser.add_argument('--no-png', action='store_true')
    args = parser.parse_args()
    result = convert_docx(args.docx, args.out_dir, args.engine, args.timeout,
                          args.dpi, not args.no_png)
    (args.out_dir / 'render_manifest.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['status'] == 'PASS' else 2


if __name__ == '__main__':
    raise SystemExit(main())


def inspect_existing_pdf(docx: Path, existing_pdf: Path, out_dir: Path,
                         dpi: int = 150, engine_label: str = 'external-export-unverified') -> dict[str, Any]:
    """Render images from the exact PDF the user intends to submit; never re-export.

    The engine label is externally supplied provenance (not independent proof).
    This function's PASS proves only that the supplied file was read and every
    page rendered. Content/visual/font verification happens in submission_gate.
    """
    docx=Path(docx).resolve();existing_pdf=Path(existing_pdf).resolve();out_dir=Path(out_dir).resolve()
    out_dir.mkdir(parents=True,exist_ok=True)
    result={'status':'UNVERIFIED','docx_sha256':sha256(docx) if docx.is_file() else None,
            'engine_requested':'supplied-pdf','engine_used':engine_label,'engine_version':'user-supplied',
            'export_provenance_verified':False,'pdf_path':str(existing_pdf),'page_images':[],
            'page_image_sha256':{},'pages':0,'reason':None}
    if not docx.is_file() or not existing_pdf.is_file():
        result['reason']='DOCX or supplied PDF is missing';return result
    if docx.samefile(existing_pdf):
        result['status']='FAIL';result['reason']='DOCX and PDF cannot be the same file';return result
    try:
        import fitz
        image_dir=out_dir/'pages';image_dir.mkdir(parents=True,exist_ok=True)
        # Delete stale images so a shorter PDF cannot inherit old page signatures.
        for stale in image_dir.glob('page-*.png'):stale.unlink()
        with fitz.open(existing_pdf) as pdf:
            if len(pdf)<1:result['status']='FAIL';result['reason']='Supplied PDF has zero pages';return result
            for idx,page in enumerate(pdf,1):
                path=image_dir/f'page-{idx:03d}.png'
                page.get_pixmap(matrix=fitz.Matrix(dpi/72.0,dpi/72.0),alpha=False).save(path)
                result['page_images'].append(str(path))
                result['page_image_sha256'][str(idx)]=sha256(path)
            result['pages']=len(pdf)
    except Exception as exc:
        result['status']='FAIL';result['reason']=f'Cannot read/render supplied PDF: {exc}';return result
    result['pdf_sha256']=sha256(existing_pdf)
    result['status']='PASS'
    result['reason']='Supplied PDF and page images were generated; PDF origin is user-provided and not independently authenticated'
    return result
