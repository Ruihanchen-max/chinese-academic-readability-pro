#!/usr/bin/env python3
"""Audit a manually annotated academic-assertiveness editing ledger.

This script checks consistency of supplied labels/actions/locks; it DOES NOT
classify defensive writing from prose, determine semantic entailment, or score
readability. The human/AI editor must label each disputed clause first.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

CATEGORIES = {
    'ESSENTIAL_SCOPE', 'REAL_MISREADING_CLARIFICATION',
    'UNNECESSARY_DEFENSE', 'ALREADY_CLEAR',
}
ACTIONS = {'KEEP', 'REFRAME', 'REMOVE'}


def _nonempty(value: object) -> bool:
    return isinstance(value, str) and bool(value.strip())


def audit(data: dict) -> dict:
    if not isinstance(data, dict):
        raise ValueError('Input must be a JSON object')
    entries = data.get('entries')
    if not isinstance(entries, list) or not entries:
        raise ValueError('entries must be a nonempty list')
    locks = data.get('locks', {})
    if not isinstance(locks, dict):
        raise ValueError('locks must be an object')
    findings = []

    def flag(code: str, level: str, item_id: str, explanation: str) -> None:
        findings.append({'code': code, 'level': level, 'id': item_id, 'explanation': explanation})

    for key in ('fact', 'comparison', 'design', 'scope'):
        value = locks.get(key)
        if value is not None and type(value) is not bool:
            raise ValueError(f'locks.{key} must be true, false, or null')
        if value is False:
            flag('LOCK_BREACH_' + key.upper(), 'BLOCK', 'ALL', f'{key} lock reported broken')
        elif value is not True:
            flag('LOCK_UNVERIFIED_' + key.upper(), 'REVIEW', 'ALL', f'{key} lock is not verified')

    seen = set()
    for entry in entries:
        if not isinstance(entry, dict):
            raise ValueError('Each entry must be an object')
        item_id = entry.get('id')
        if not _nonempty(item_id) or item_id in seen:
            raise ValueError('Every entry requires a unique nonempty id')
        seen.add(item_id)
        category = entry.get('category')
        action = entry.get('action')
        if category not in CATEGORIES or action not in ACTIONS:
            raise ValueError(f'{item_id}: invalid category or action')
        if not _nonempty(entry.get('original')):
            raise ValueError(f'{item_id}: original must be nonempty')
        revision = entry.get('revision', '')
        if not isinstance(revision, str):
            raise ValueError(f'{item_id}: revision must be a string')
        is_changed = entry['original'].strip() != revision.strip()
        verified = entry.get('scope_verified')
        if verified is not None and type(verified) is not bool:
            raise ValueError(f'{item_id}: scope_verified must be true, false, or null')
        if action == 'KEEP' and is_changed:
            flag('KEEP_BUT_CHANGED', 'REVIEW', item_id, 'KEEP action contradicts changed text')
        if action in ('REMOVE', 'REFRAME') and not is_changed:
            flag('EDIT_WITHOUT_CHANGE', 'REVIEW', item_id, 'Edit action but text is unchanged')
        if action == 'REMOVE' and revision.strip():
            flag('REMOVE_WITH_TEXT', 'REVIEW', item_id, 'REMOVE should produce an empty revision for the targeted clause')
        if action != 'REMOVE' and not revision.strip():
            flag('EMPTY_REWRITE', 'BLOCK', item_id, 'Non-removal action cannot erase the clause')
        if is_changed and not _nonempty(entry.get('rationale')):
            flag('NO_EDIT_RATIONALE', 'REVIEW', item_id, 'Edit requires a text-grounded rationale')
        if category == 'ESSENTIAL_SCOPE':
            if action == 'REMOVE':
                flag('ESSENTIAL_SCOPE_REMOVED', 'BLOCK', item_id, 'Scientific scope may not be silently deleted')
            elif is_changed and verified is False:
                flag('ESSENTIAL_SCOPE_CHANGED', 'BLOCK', item_id, 'Reported scope preservation failed')
            elif is_changed and verified is not True:
                flag('ESSENTIAL_SCOPE_UNVERIFIED', 'REVIEW', item_id, 'Verify the meaning of the necessary caveat')
        elif category == 'REAL_MISREADING_CLARIFICATION':
            if action == 'REMOVE':
                flag('CLARIFICATION_REMOVED', 'REVIEW', item_id, 'Check whether a concrete misreading remains possible')
            if is_changed and verified is False:
                flag('CLARIFICATION_SCOPE_CHANGED', 'BLOCK', item_id, 'Reported scientific boundary changed')
        elif category == 'UNNECESSARY_DEFENSE':
            if action == 'KEEP' and not _nonempty(entry.get('retain_justification')):
                flag('UNNECESSARY_DEFENSE_KEPT', 'REVIEW', item_id, 'Explain the actual misreading or remove the redundant rebuttal')
            if is_changed and verified is False:
                flag('DEFENSE_EDIT_SCOPE_CHANGED', 'BLOCK', item_id, 'Redundant wording removed but scientific meaning changed')
            if is_changed and verified is not True:
                flag('DEFENSE_EDIT_SCOPE_UNVERIFIED', 'REVIEW', item_id, 'Confirm positive rewrite does not strengthen the claim')
        elif category == 'ALREADY_CLEAR' and is_changed:
            flag('UNNECESSARY_EDIT_CANDIDATE', 'REVIEW', item_id, 'Why change already-clear academic text?')

    status = ('BLOCK_AND_REVISE' if any(x['level'] == 'BLOCK' for x in findings)
              else 'REVIEW_REQUIRED' if any(x['level'] == 'REVIEW' for x in findings)
              else 'SCREEN_CLEAR_NOT_QUALITY_PROOF')
    return {
        'status': status,
        'reviewed_entries': len(entries),
        'findings': findings,
        'independent_reader_effect_tested': False,
        'semantic_fidelity_independently_verified': False,
        'scope': 'Consistency check of user/agent-provided annotations, not automatic detection of defensive writing or proof of claim strength.'
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('--out-json', type=Path)
    args = parser.parse_args()
    try:
        obj = json.loads(args.input.read_text(encoding='utf-8'))
        result = audit(obj)
        blob = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
        print(blob, end='')
        if args.out_json:
            args.out_json.parent.mkdir(parents=True, exist_ok=True)
            args.out_json.write_text(blob, encoding='utf-8')
        return 2 if result['status'] == 'BLOCK_AND_REVISE' else 0
    except (OSError, ValueError, TypeError) as exc:
        print(json.dumps({'status': 'INVALID_INPUT', 'error': str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
