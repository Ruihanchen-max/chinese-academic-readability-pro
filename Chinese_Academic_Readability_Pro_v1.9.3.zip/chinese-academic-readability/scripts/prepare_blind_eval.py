#!/usr/bin/env python3
"""Create a public A/B/C reviewer pack and a *separately stored* private key.

The private key is outside the reviewer directory by default, with restrictive
permissions. This does NOT automatically remove self-identifying model/Skill text.
Only share consented and appropriately anonymized manuscript excerpts.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import re
import uuid
from pathlib import Path

VALID_ARMS = {"A", "B", "C"}


def prepare(data: dict, seed: int = 20261122) -> tuple[list[dict], list[dict]]:
    if not isinstance(data, dict) or not isinstance(data.get("cases"), list) or not data["cases"]:
        raise ValueError('Input must have nonempty "cases" array')
    rng = random.Random(seed)
    public, key = [], []
    ids: set[str] = set()
    for case in data["cases"]:
        cid = case.get("id")
        variants = case.get("variants")
        if not isinstance(cid, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,60}", cid):
            raise ValueError("Every case requires a simple id")
        if cid in ids:
            raise ValueError(f"Duplicate case id: {cid}")
        ids.add(cid)
        if not isinstance(variants, dict) or set(variants) != VALID_ARMS:
            raise ValueError(f"Case {cid}: variants must have exact A/B/C keys")
        if any(not isinstance(v, str) or not v.strip() for v in variants.values()):
            raise ValueError(f"Case {cid}: each variant must be nonempty text")
        ordered = list(variants.items())
        rng.shuffle(ordered)
        public.append({"case_id": cid, "passages": [
            {"code": f"{cid}-V{i}", "text": text} for i, (_, text) in enumerate(ordered, 1)
        ]})
        key.append({"case_id": cid, "mapping": {
            f"{cid}-V{i}": arm for i, (arm, _) in enumerate(ordered, 1)
        }})
    rng.shuffle(public)
    return public, key


def format_reviewer_pack(public: list[dict]) -> str:
    lines = ["# 隐去来源的读者评估材料", "",
             "请独立阅读，不要猜测版本来源。每个版本按相同问题判断：",
             "1. 该段主张与研究问题是什么？",
             "2. 哪个证据支撑结论？缺证据要指出原文位置。",
             "3. 观察事实、作者解释与机制假说分别是什么？",
             "4. 哪些术语、比较基准、限定或段间关系造成理解困难？",
             "5. 中文自然度、论证可追踪性、读者负担分别用 0–3 分评分并说明理由。",
             "6. 任何科研事实错误均须记录，不得用更流畅抵消。", ""]
    for case in public:
        lines.extend([f"## 案例 {case['case_id']}", ""])
        for variant in case["passages"]:
            lines.extend([f"### {variant['code']}", "", variant["text"], ""])
    return "\n".join(lines) + "\n"


def default_private_dir() -> Path:
    env = os.environ.get("XDG_STATE_HOME")
    return (Path(env) if env else Path.home() / ".local" / "state") / "chinese-academic-readability" / "blind-keys"


def write_packs(public: list[dict], key: list[dict], reviewer_dir: Path,
                key_dir: Path, seed: int) -> tuple[Path, Path]:
    """Write without overwrite or key-in-public-dir leakage; file permissions restrict key."""
    reviewer_dir = reviewer_dir.expanduser().resolve()
    key_dir = key_dir.expanduser().resolve()
    if key_dir == reviewer_dir or reviewer_dir in key_dir.parents:
        raise ValueError("Private key directory MUST be outside the public reviewer directory")
    reviewer_dir.mkdir(parents=True, exist_ok=True)
    public_path = reviewer_dir / "reviewer_pack.md"
    if public_path.exists():
        raise FileExistsError("reviewer_pack.md already exists; choose a new reviewer directory")
    key_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        key_dir.chmod(0o700)
    except OSError:
        pass
    private_path = key_dir / f"private_key_{uuid.uuid4().hex}.json"
    payload = json.dumps({"seed": seed, "key": key}, ensure_ascii=False, indent=2)
    # Create private file first with O_EXCL and mode 0600; if public write fails,
    # delete the key (best effort) rather than leaving an orphan mapping.
    fd = os.open(private_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(payload)
        try:
            with public_path.open("x", encoding="utf-8") as handle:
                handle.write(format_reviewer_pack(public))
        except Exception:
            private_path.unlink(missing_ok=True)
            raise
    except Exception:
        private_path.unlink(missing_ok=True)
        raise
    return public_path, private_path


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("input", type=Path, help="JSON: cases[id,variants{A,B,C}]")
    p.add_argument("reviewer_dir", type=Path, help="Contains ONLY reviewer_pack.md (no answer key)")
    p.add_argument("--seed", type=int, default=20261122)
    p.add_argument("--key-dir", type=Path, default=None,
                   help="Private key directory, outside reviewer_dir; default is user's private state directory")
    args = p.parse_args()
    if not args.input.is_file():
        p.error("Input JSON not found")
    try:
        data = json.loads(args.input.read_text(encoding="utf-8"))
        public, key = prepare(data, args.seed)
        public_path, private_path = write_packs(
            public, key, args.reviewer_dir,
            args.key_dir if args.key_dir else default_private_dir(), args.seed,
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError, OSError) as err:
        p.error(str(err))
    print(f"Reviewer pack (safe folder to share AFTER manual anonymity review): {public_path}")
    print(f"PRIVATE key (store separately; NEVER share): {private_path}")
    print("Source-identifying text, manuscripts and author names are NOT automatically redacted.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
