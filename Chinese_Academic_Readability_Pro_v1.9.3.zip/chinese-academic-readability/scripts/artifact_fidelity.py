#!/usr/bin/env python3
"""Non-OCR DOCX↔PDF text/content parity with explicit high-confidence anchor checks.

This is a **candidate detector**. PDF text parity alone does not prove visual glyphs.
DOCX OMML equations, text boxes and charts require page-image inspection.
"""
from __future__ import annotations

import argparse
from difflib import SequenceMatcher
import hashlib
import json
from pathlib import Path
import re
import unicodedata
from typing import Any
from zipfile import ZipFile


def norm(text: str) -> str:
    return ''.join(ch.lower() for ch in unicodedata.normalize('NFKC', text)
                   if not ch.isspace() and unicodedata.category(ch) not in ('Cf', 'Cc'))


def docx_strings(docx: Path) -> tuple[list[dict[str, Any]], dict[str, int]]:
    from docx import Document
    doc = Document(docx)
    out = []
    for i, paragraph in enumerate(doc.paragraphs):
        value = paragraph.text.strip()
        if value:
            out.append({'location': f'paragraph:{i+1}', 'text': value,
                        'kind': 'toc' if paragraph.style.name.lower().startswith('toc') else 'paragraph'})
    for ti, table in enumerate(doc.tables, 1):
        for ri, row in enumerate(table.rows, 1):
            for ci, cell in enumerate(row.cells, 1):
                value = cell.text.strip()
                if value:
                    out.append({'location': f'table:{ti}/row:{ri}/cell:{ci}',
                                'text': value, 'kind': 'table_cell'})
    with ZipFile(docx) as archive:
        xml = archive.read('word/document.xml').decode('utf-8')
    inventory = {'docx_tables': len(doc.tables),
                 'native_omath_nodes': len(re.findall(r'<m:oMath(?:\s|/|>)', xml)),
                 'docx_toc_entries': sum(entry['kind'] == 'toc' for entry in out),
                 'possible_text_boxes': xml.count('w:txbxContent')}
    return out, inventory


def pdf_pages(pdf: Path) -> list[str]:
    import fitz
    with fitz.open(pdf) as document:
        return [page.get_text('text') for page in document]


def ngram_coverage(source: str, target: str, k: int = 7) -> float:
    if not source:
        return 1.0
    k = min(k, len(source))
    grams = [source[i:i+k] for i in range(len(source) - k + 1)]
    return sum(gram in target for gram in grams) / len(grams)


def anchor_check(source: str, pages: list[str], anchors: list[dict[str, Any]]) -> list[dict[str, Any]]:
    findings = []
    for anchor in anchors:
        phrase = norm(str(anchor.get('source_text', '')))
        if not phrase:
            findings.append({'id': anchor.get('id'), 'status': 'UNVERIFIED', 'reason': 'Empty anchor'})
            continue
        if phrase not in source:
            findings.append({'id': anchor.get('id'), 'status': 'UNVERIFIED',
                             'reason': 'Anchor is not in DOCX source; cannot claim PDF loss'})
            continue
        page = anchor.get('pdf_expected_page')
        if page is not None and (not isinstance(page, int) or page < 1 or page > len(pages)):
            findings.append({'id': anchor.get('id'), 'status': 'UNVERIFIED',
                             'reason': 'Expected page missing/outside actual PDF'})
            continue
        target_pages = [page] if page is not None else list(range(1, len(pages)+1))
        found = [p for p in target_pages if phrase in pages[p-1]]
        findings.append({'id': anchor.get('id'), 'status': 'PASS' if found else 'FAIL',
                         'pdf_expected_page': page, 'source_text': anchor.get('source_text'),
                         'reason': 'Anchor exactly reproduced' if found else 'DOCX text not present in expected PDF text',
                         'found_pages': found})
    return findings


def paragraph_gaps(source: str, target_pages: list[str], min_missing: int = 2) -> list[str]:
    """Detect a missing interior run where paragraph start/end locate one PDF span.

    Does not try to interpret text streams reordered across table columns.
    """
    if len(source) < 45:
        return []
    first, last = source[:13], source[-13:]
    for page_text in target_pages:
        start = page_text.find(first)
        if start < 0:
            continue
        end = page_text.find(last, start + len(first))
        if end < 0:
            continue
        observed = page_text[start:end+len(last)]
        if len(observed) > len(source) * 1.55 + 35:
            continue
        matcher = SequenceMatcher(None, source, observed, autojunk=False)
        missing = []
        for operation, lo, hi, a, b in matcher.get_opcodes():
            if operation in ('delete', 'replace') and hi - lo >= min_missing:
                sample = source[lo:hi]
                if sum('\u3400' <= ch <= '\u9fff' for ch in sample) < 2:
                    continue
                # Very common PDF list/table ordering and math approximations get REVIEW, never automatic proof.
                if len(sample) <= 90:
                    missing.append(sample)
        return missing[:12]
    return []


def check_fidelity(docx: Path, pdf: Path, anchors: list[dict[str, Any]] | None = None,
                   min_coverage: float = 0.80, adjudications: dict[str, Any] | None = None) -> dict[str, Any]:
    source_items, inventory = docx_strings(docx)
    raw_pages = pdf_pages(pdf)
    norm_pages = [norm(page) for page in raw_pages]
    combined = ''.join(norm_pages)
    docx_text = ''.join(norm(entry['text']) for entry in source_items)
    anchors = anchors or []
    anchors_result = anchor_check(docx_text, norm_pages, anchors)
    # Source-only vs supplied-PDF safety: an unrelated PDF must never PASS just
    # because no custom anchors were supplied, or all source paragraphs are short.
    # Uses overlap as a *wrong-file* gate, not as a proof of every glyph.
    non_toc_source=''.join(norm(entry['text']) for entry in source_items if entry['kind']!='toc')
    global_coverage=ngram_coverage(non_toc_source, combined, k=5) if non_toc_source else 0.0
    gross_mismatch=(len(non_toc_source)>=10 and (not combined or global_coverage<0.12))

    warnings: list[dict[str, Any]] = []
    inspected = 0
    for entry in source_items:
        if entry['kind'] == 'toc':
            continue
        val = norm(entry['text'])
        if len(val) < 20:
            continue
        inspected += 1
        coverage = ngram_coverage(val, combined)
        gaps = paragraph_gaps(val, norm_pages)
        if coverage < min_coverage or gaps:
            warnings.append({'location': entry['location'], 'kind': entry['kind'],
                             'ngram_coverage': round(coverage, 3),
                             'suspect_missing_segments': gaps,
                             'excerpt': entry['text'][:110],
                             'reason': 'Potential missing/reordered content; inspect page image and DOCX text'})
    failed = gross_mismatch or any(f['status'] == 'FAIL' for f in anchors_result)
    unresolved = [issue['location'] for issue in warnings]
    native_math_pending = inventory['native_omath_nodes'] > 0
    text_boxes_pending = inventory['possible_text_boxes'] > 0
    adjudication_ok = False
    if adjudications:
        doc_hash = hashlib.sha256(Path(docx).read_bytes()).hexdigest()
        pdf_hash = hashlib.sha256(Path(pdf).read_bytes()).hexdigest()
        adjudication_ok = (adjudications.get('docx_sha256') == doc_hash and
                           adjudications.get('pdf_sha256') == pdf_hash and
                           bool(str(adjudications.get('reviewer', '')).strip()))
        if adjudication_ok:
            resolved = set(adjudications.get('resolved_suspect_locations', []))
            unresolved = [where for where in unresolved if where not in resolved]
            native_math_pending &= not adjudications.get('native_math_visual_reviewed', False)
            text_boxes_pending &= not adjudications.get('text_boxes_visual_reviewed', False)
    pending = (any(f['status'] == 'UNVERIFIED' for f in anchors_result)
               or bool(unresolved) or native_math_pending or text_boxes_pending)
    return {'status': 'FAIL' if failed else ('UNVERIFIED' if pending else 'PASS'),
            'pdf_pages': len(raw_pages), 'source_inventory': inventory,
            'paragraphs_checked': inspected, 'global_5gram_coverage':round(global_coverage,4),
            'gross_docx_pdf_mismatch':gross_mismatch, 'anchors': anchors_result,
            'suspected_content_differences': warnings[:100],
            'suspected_count': len(warnings),
            'unresolved_suspect_locations': unresolved,
            'math_visual_review_pending': native_math_pending,
            'text_boxes_visual_review_pending': text_boxes_pending,
            'adjudication_matches_source_files': adjudication_ok,
            'note': 'Anchor FAIL is hard evidence of missing PDF text. Similarity warnings and formulas require actual page visual review. PASS of extraction alone cannot establish glyph visibility.'}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('docx', type=Path)
    parser.add_argument('pdf', type=Path)
    parser.add_argument('--anchors-json', type=Path)
    parser.add_argument('--out-json', type=Path)
    parser.add_argument('--adjudications-json', type=Path)
    args = parser.parse_args()
    anchors = json.loads(args.anchors_json.read_text(encoding='utf-8')) if args.anchors_json else []
    adjudications = json.loads(args.adjudications_json.read_text(encoding='utf-8')) if args.adjudications_json else None
    result = check_fidelity(args.docx, args.pdf, anchors, adjudications=adjudications)
    encoded = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out_json:
        args.out_json.parent.mkdir(parents=True, exist_ok=True)
        args.out_json.write_text(encoded, encoding='utf-8')
    print(encoded)
    return 1 if result['status'] == 'FAIL' else 0


if __name__ == '__main__':
    raise SystemExit(main())
