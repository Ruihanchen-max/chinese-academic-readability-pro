#!/usr/bin/env python3
"""Plan evidence-preserving scientific figures from an explicit figure contract.

Stdlib only. This routes work; it does NOT synthesize data or generate a figure.
Usage: python scripts/scientific_figure_plan.py contract.json --out plan.json [--source-root .]
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re

PAPER_TYPES = {"method", "mechanism", "benchmark", "analysis", "agent", "interdisciplinary", "intervention", "survey"}
EVIDENCE_TYPES = {"schematic", "quantitative", "mixed", "published", "photo"}
PHASE_TYPES = {"proposal", "planned", "observed", "review"}
TYPE_TO_LAYOUT = {
    "method": "method_overview_or_module_zoom",
    "mechanism": "mechanism_zoom_or_contrast",
    "benchmark": "data_construction_or_evaluation_pipeline",
    "analysis": "multi_panel_results",
    "agent": "feedback_loop",
    "interdisciplinary": "cross_disciplinary_contrast",
    "intervention": "study_timeline_and_arm_comparison",
    "survey": "taxonomy_or_evidence_matrix",
}


def _clean_str(value, field: str, problems: list[str], required: bool = False):
    if value is None and not required:
        return ""
    if not isinstance(value, str) or (required and not value.strip()):
        problems.append(f"{field}: required nonempty string")
        return ""
    return value.strip()


def _hash_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for piece in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(piece)
    return h.hexdigest()


def plan(contract: dict, source_root: Path) -> dict:
    if not isinstance(contract, dict):
        raise ValueError("Figure contract must be a JSON object")
    errors: list[str] = []
    warnings: list[str] = []
    fig_id = _clean_str(contract.get("figure_id", "figure_01"), "figure_id", errors, True)
    if not re.fullmatch(r"[A-Za-z0-9_\-]{1,80}", fig_id):
        errors.append("figure_id: use 1–80 letters, digits, _ or -")
    kind = _clean_str(contract.get("evidence_kind"), "evidence_kind", errors, True).lower()
    if kind not in EVIDENCE_TYPES:
        errors.append("evidence_kind: unknown type; require schematic/quantitative/mixed/published/photo")
    paper = _clean_str(contract.get("paper_type"), "paper_type", errors, True).lower()
    if paper not in PAPER_TYPES:
        errors.append("paper_type: unknown type; do not auto-infer from incomplete text")
    phase = _clean_str(contract.get("study_phase"), "study_phase", errors, True).lower()
    if phase not in PHASE_TYPES:
        errors.append("study_phase: unknown status")
    question = _clean_str(contract.get("reader_question"), "reader_question", errors, True)
    claim = _clean_str(contract.get("claim"), "claim", errors, True)
    source_description = _clean_str(contract.get("source_description"), "source_description", errors)
    is_needed = contract.get("figure_needed", True)
    if type(is_needed) is not bool:
        errors.append("figure_needed: must be JSON boolean")
        is_needed = False
    inputs = contract.get("source_files", [])
    if not isinstance(inputs, list) or not all(isinstance(p, str) and p.strip() for p in inputs):
        errors.append("source_files: must be an array of path strings")
        inputs = []
    source_records = []
    for entry in inputs:
        source = (source_root / entry).resolve()
        if source.is_file():
            try:
                source_records.append({"path": entry, "sha256": _hash_file(source), "bytes": source.stat().st_size, "status": "PRESENT"})
            except OSError as exc:
                errors.append(f"source file cannot be read: {entry}: {exc}")
        else:
            errors.append(f"source file absent: {entry}")
    if not inputs and not source_description:
        errors.append("No supporting source material or source_description provided; do not invent diagram content")
    if kind in {"quantitative", "mixed"} and not source_records:
        errors.append("Actual data source file is required for quantitative/mixed figure; no synthetic results allowed")
    if kind in {"published", "photo"} and not source_records:
        errors.append("Original licensed source/photo file is required")
    if kind == "published" and not contract.get("usage_rights"):
        warnings.append("Rights/attribution not documented: do not publish until verified")
    if phase in {"planned", "proposal"} and kind in {"quantitative", "mixed"}:
        warnings.append("Planned study: label quantitative input as existing/preliminary/external; never present as completed future results")
    if kind in {"quantitative", "mixed"}:
        for field in ("measurement", "unit", "independent_unit"):
            if not _clean_str(contract.get(field), field, errors, True):
                pass
        if not contract.get("uncertainty"):
            warnings.append("Uncertainty definition not provided; describe intervals/variation if figure supports inference")
    if kind == "schematic" and not contract.get("elements"):
        warnings.append("Elements/modules not enumerated; do not invent model architecture/steps from a title")
    if not is_needed:
        warnings.append("Figure not necessary: improve existing text/labels instead of adding a redundant picture")
    mode = {"schematic": "pptx_native_to_svg", "quantitative": "python_reproducible_svg_pdf", "mixed": "separate_pptx_and_python_panels", "published": "licensed_original_source", "photo": "preserve_authentic_image"}.get(kind, "unresolved")
    if errors:
        status = "FAIL"
    elif not is_needed:
        status = "SKIP"
    else:
        status = "READY_FOR_CREATION" if not warnings else "REVIEW_REQUIRED"
    layout = contract.get("preferred_structure") or TYPE_TO_LAYOUT.get(paper, "needs_review")
    report = {
        "planner_status": status,
        "figure_id": fig_id,
        "study_phase": phase,
        "paper_type": paper,
        "reader_question": question,
        "claim": claim,
        "evidence_kind": kind,
        "selected_route": mode,
        "suggested_layout": layout,
        "figure_needed": is_needed,
        "source_description": source_description,
        "source_records": source_records,
        "errors": errors,
        "warnings": warnings,
        "deliverables": {
            "schematic": ["source.pptx", "vector.svg", "figure_contract.json", "preview.png"],
            "quantitative": ["plot.py", "source_data.*", "vector.svg", "figure_contract.json", "transform_log.json"],
            "mixed": ["editable_concept.pptx", "data_plot.py", "composed.svg", "figure_contract.json"],
            "published": ["original_source", "rights_and_attribution.md"],
            "photo": ["original_photo", "caption_and_processing_log.md"],
        }.get(kind, []),
        "gates": {"structural": "UNVERIFIED", "scientific": "UNVERIFIED", "visual": "UNVERIFIED", "final_document": "UNVERIFIED"},
        "caveat": "Figure selection and source hashing are deterministic checks; not scientific or visual certification."
    }
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("contract", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, default=Path("."))
    args = parser.parse_args()
    try:
        contract = json.loads(args.contract.read_text(encoding="utf-8"))
        result = plan(contract, args.source_root)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"planner_status": "FAIL", "error": str(exc)}, ensure_ascii=False))
        return 1
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"planner_status": result["planner_status"], "output": str(args.out), "errors": result["errors"], "warnings": result["warnings"]}, ensure_ascii=False))
    return 1 if result["planner_status"] == "FAIL" else 0


if __name__ == "__main__":
    raise SystemExit(main())
