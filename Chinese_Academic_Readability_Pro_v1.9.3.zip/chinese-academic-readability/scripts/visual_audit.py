#!/usr/bin/env python3
"""PDF page/layout/font/TOC checks + mandatory every-page visual sign-off.

Raster page images are mandatory. Automated glyph checks are only screening.
A PASS requires all page images reviewed against the source, with reviewer
identity + matching image hashes. Merely exporting images is UNVERIFIED.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import unicodedata
from typing import Any


def h256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def n(s: str) -> str:
    return ''.join(ch.lower() for ch in unicodedata.normalize('NFKC', s)
                   if not ch.isspace() and unicodedata.category(ch) not in ('Cf', 'Cc'))


def toc_verify(docx: Path, pages_text: list[str]) -> list[dict[str, Any]]:
    from docx import Document
    doc = Document(docx)
    normalized = [n(p) for p in pages_text]
    result = []
    for para in doc.paragraphs:
        if not para.style.name.lower().startswith('toc'):
            continue
        entry = para.text.strip()
        m = re.match(r'^(.*?)\s*\t\s*(\d+)\s*$', entry)
        if not m:
            result.append({'title': entry[:80], 'status': 'UNVERIFIED', 'reason': 'TOC entry not parseable'})
            continue
        title, page_num = m.group(1).strip(), int(m.group(2))
        if not (1 <= page_num <= len(normalized)):
            result.append({'title': title, 'page': page_num, 'status': 'FAIL',
                           'reason': 'TOC page outside PDF range'})
            continue
        found = n(title) in normalized[page_num - 1]
        result.append({'title': title, 'page': page_num, 'status': 'PASS' if found else 'FAIL',
                       'reason': 'Title found on declared PDF page' if found else
                                 'Title absent from declared PDF page'})
    return result


def font_inventory(docx: Path, pdf) -> dict[str, Any]:
    """Compare declared OOXML font *names* with fonts embedded in rendered PDF.

    Font aliases and substitutions are renderer-specific: informational only.
    The PDF list cannot prove that every Chinese glyph is visibly painted.
    """
    from collections import Counter
    from lxml import etree
    from zipfile import ZipFile
    counts: Counter[str] = Counter()
    ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    for part in ('word/document.xml', 'word/styles.xml'):
        with ZipFile(docx) as z:
            if part not in z.namelist():
                continue
            tree = etree.fromstring(z.read(part))
        for node in tree.xpath('//w:rFonts', namespaces=ns):
            for suffix in ('eastAsia', 'ascii', 'hAnsi', 'cs'):
                value = node.get('{' + ns['w'] + '}' + suffix)
                if value:
                    counts[f'{suffix}:{value}'] += 1
    embedded = set()
    for page in pdf:
        for font in page.get_fonts():
            base = font[3].split('+', 1)[-1] if len(font) > 3 else ''
            if base:
                embedded.add(base)
    return {'docx_declared_font_names': [k for k, _ in counts.most_common(35)],
            'pdf_embedded_font_names': sorted(embedded),
            'interpretation': 'Inspect unexpected substitution in the actual PDF page images; names/aliases alone do not establish a defect.'}


def is_cjk(ch: str) -> bool:
    return len(ch) == 1 and (0x3400 <= ord(ch) <= 0x9FFF or 0xF900 <= ord(ch) <= 0xFAFF)


def pixel_glyph_candidates(page, image: Path, max_candidates: int = 35) -> dict[str, Any]:
    """Screen for extracted CJK glyphs that appear inkless at their glyph bbox.

    This does NOT prove absence: white-on-dark, clipping, or substitute glyphs
    must be assessed by a person against the source.
    """
    import numpy as np
    from PIL import Image
    with Image.open(image) as opened:
        a = np.asarray(opened.convert('L'))
    sx, sy = a.shape[1] / page.rect.width, a.shape[0] / page.rect.height
    raw = page.get_text('rawdict')
    total = 0
    suspicious = []
    for block in raw.get('blocks', []):
        for line in block.get('lines', []):
            for span in line.get('spans', []):
                for ch in span.get('chars', []):
                    glyph = ch.get('c', '')
                    if not is_cjk(glyph):
                        continue
                    total += 1
                    x0, y0, x1, y1 = ch['bbox']
                    l, t, r, b = int(x0*sx), int(y0*sy), int(x1*sx), int(y1*sy)
                    l, t = max(0, l), max(0, t)
                    r, b = min(a.shape[1], r), min(a.shape[0], b)
                    if r-l < 4 or b-t < 5:
                        continue
                    cell = a[t:b, l:r]
                    # If uniformly light across a Hanzi bbox, extraction can be
                    # present while ink is absent (white/transparent PDF text).
                    ink = float(np.mean(cell < 155))
                    if ink < 0.0035 and len(suspicious) < max_candidates:
                        suspicious.append({'char': glyph, 'bbox': [round(float(v), 1) for v in ch['bbox']],
                                           'dark_pixel_fraction': round(ink, 5)})
    return {'glyphs_checked': total, 'possible_inkless_cjk': suspicious,
            'truncated_at': max_candidates}


def create_review_template(image_dir: Path, pages: int, output: Path) -> dict[str, Any]:
    data = {'reviewer': '', 'method': 'Compare each page at 100% zoom against DOCX',
            'page_images': [
                {'page': i, 'image_sha256': h256(image_dir / f'page-{i:03}.png'),
                 'status': 'UNVERIFIED',
                 'checks': {name: 'UNVERIFIED' for name in ('chinese_glyphs', 'table_cells',
                             'formula_subscripts', 'toc_and_page_numbers', 'layout_and_overlap')},
                 'notes': ''}
                for i in range(1, pages + 1)]}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    return data


def apply_review(review_json: Path | None, image_dir: Path, pages: int) -> tuple[str, list[str]]:
    if not review_json or not review_json.is_file():
        return 'UNVERIFIED', ['No completed every-page visual review evidence']
    try:
        review = json.loads(review_json.read_text(encoding='utf-8'))
    except (OSError, ValueError) as exc:
        return 'UNVERIFIED', [f'Unreadable review evidence: {exc}']
    reviewer = str(review.get('reviewer', '')).strip()
    records = review.get('page_images', [])
    if not reviewer:
        return 'UNVERIFIED', ['Reviewer name/identifier missing']
    by_page = {rec.get('page'): rec for rec in records if isinstance(rec, dict)}
    concerns = []
    for i in range(1, pages + 1):
        rec = by_page.get(i)
        path = image_dir / f'page-{i:03}.png'
        if not rec or rec.get('image_sha256') != h256(path):
            concerns.append(f'Page {i} missing or image hash does not match reviewed render')
        elif rec.get('status') == 'FAIL':
            return 'FAIL', [f'Visual reviewer reported FAIL on page {i}: {rec.get("notes", "")}']
        elif rec.get('status') != 'PASS':
            concerns.append(f'Page {i} not visually signed off')
        elif any(rec.get('checks', {}).get(k) not in ('PASS', 'N/A')
                 for k in ('chinese_glyphs', 'table_cells', 'formula_subscripts',
                           'toc_and_page_numbers', 'layout_and_overlap')):
            concerns.append(f'Page {i} has incomplete page-level QA checklist')
    return ('UNVERIFIED' if concerns else 'PASS'), concerns[:35]


def inspect_visual(docx: Path, pdf: Path, image_dir: Path,
                   review_json: Path | None = None, create_template: Path | None = None,
                   scan_ink: bool = True) -> dict[str, Any]:
    import fitz
    with fitz.open(pdf) as doc:
        pages = len(doc)
        present = [i for i in range(1, pages+1) if
                   (image_dir / f'page-{i:03}.png').is_file()]
        if len(present) != pages:
            return {'status': 'FAIL', 'reason': f'Only {len(present)}/{pages} page images exist',
                    'image_pages': len(present), 'pdf_pages': pages}
        toc = toc_verify(docx, [page.get_text() for page in doc])
        fonts = font_inventory(docx, doc)
        issues = []
        glyph_sample = []
        page_stats = []
        for i, page in enumerate(doc, 1):
            text = page.get_text('text')
            words = len(text.strip())
            if words < 6:
                issues.append({'page': i, 'code': 'LOW_TEXT_CONTENT', 'level': 'REVIEW',
                               'note': 'Blank or image-heavy page; inspect whether intentional'})
            if any(char in text for char in ('\ufffd', '\u25a1', '\u25a0')):
                issues.append({'page': i, 'code': 'MISSING_GLYPH_CHARACTER', 'level': 'REVIEW'})
            outside = []
            bounds = page.rect
            for block in page.get_text('dict').get('blocks', []):
                for line in block.get('lines', []):
                    for span in line.get('spans', []):
                        box = fitz.Rect(span['bbox'])
                        if not bounds.contains(box) and not bounds.contains(box + (-1,-1,1,1)):
                            outside.append([round(v, 1) for v in span['bbox']])
            if outside:
                issues.append({'page': i, 'code': 'TEXT_OUTSIDE_PAGE', 'level': 'REVIEW',
                               'boxes': outside[:5]})
            candidates = pixel_glyph_candidates(page, image_dir / f'page-{i:03}.png') if scan_ink else {'glyphs_checked': 0, 'possible_inkless_cjk': []}
            if candidates['possible_inkless_cjk']:
                glyph_sample.append({'page': i, **candidates})
            page_stats.append({'page': i, 'pdf_text_chars': words, 'glyphs_checked': candidates['glyphs_checked']})
        if create_template:
            create_review_template(image_dir, pages, create_template)
        review_status, review_concerns = apply_review(review_json, image_dir, pages)
        toc_fail = [record for record in toc if record['status'] == 'FAIL']
        toc_unverified = [record for record in toc if record['status'] == 'UNVERIFIED']
        annotated_pages = set()
        if review_status == 'PASS' and review_json:
            signed = json.loads(review_json.read_text(encoding='utf-8'))
            annotated_pages = {v['page'] for v in signed.get('page_images', [])
                               if v.get('status') == 'PASS' and str(v.get('notes', '')).strip()}
        outstanding = [item for item in issues if item['page'] not in annotated_pages]
        outstanding += [{'page': item['page'], 'code': 'INKLESS_CJK_CANDIDATE'}
                        for item in glyph_sample if item['page'] not in annotated_pages]
        status = ('FAIL' if toc_fail or review_status == 'FAIL' else
                  'UNVERIFIED' if review_status != 'PASS' or toc_unverified or outstanding else 'PASS')
        return {'status': status, 'pdf_pages': pages, 'images_verified_present': len(present),
                'toc_checked': len(toc), 'toc_results': toc, 'font_inventory': fonts,
                'pdf_layout_candidates': issues[:100],
                'suspected_inkless_glyph_pages': glyph_sample[:20],
                'suspected_inkless_glyph_page_count': len(glyph_sample),
                'review_status': review_status, 'review_blockers': review_concerns,
                'outstanding_layout_candidates': outstanding,
                'pages': page_stats,
                'note': 'All rendered pages exist ≠ all visually reviewed. Page image review of Chinese text, equations, tables, and page breaks is mandatory.'}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('docx', type=Path)
    parser.add_argument('pdf', type=Path)
    parser.add_argument('--image-dir', required=True, type=Path)
    parser.add_argument('--review-json', type=Path)
    parser.add_argument('--review-template', type=Path)
    parser.add_argument('--out-json', type=Path)
    parser.add_argument('--no-ink-scan', action='store_true')
    args = parser.parse_args()
    result = inspect_visual(args.docx, args.pdf, args.image_dir, args.review_json,
                            args.review_template, not args.no_ink_scan)
    encoded = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out_json:
        args.out_json.write_text(encoded, encoding='utf-8')
    print(encoded)
    return 1 if result['status'] == 'FAIL' else 0


if __name__ == '__main__':
    raise SystemExit(main())
