#!/usr/bin/env python3
"""Descriptive (non-scoring) text edit footprint for Chinese manuscripts.

Shows expansion, sentence length distribution, paragraph counts and a revision
footprint. NOT an evidence check, language quality score, or readability outcome.
"""
from __future__ import annotations

import argparse
import difflib
import json
from pathlib import Path
import re

HAN = re.compile(r"[\u3400-\u9fff]")
SPLIT_SENTENCES = re.compile(r"[。！？!?；;]+")
MARKDOWN = re.compile(r"(?m)^\s*(?:#{1,6}\s+|>\s+|[-*+]\s+|\d+\.\s+)")


def _clean(s: str) -> str:
    s = re.sub(r"```.*?```", "", s, flags=re.S)
    s = re.sub(r"(?m)^\s*\|[^\n]*\|\s*$", "", s)
    s = MARKDOWN.sub("", s)
    return s.strip()


def _stats(text: str) -> dict:
    plain = _clean(text)
    han = len(HAN.findall(plain))
    sentences = [x.strip() for x in SPLIT_SENTENCES.split(plain) if HAN.search(x)]
    lens = [len(HAN.findall(x)) for x in sentences]
    lens.sort()
    paragraphs = len([x for x in re.split(r"\n\s*\n", plain) if HAN.search(x)])
    return {"han_chars": han, "sentence_count": len(lens), "paragraph_count": paragraphs,
            "sentence_han_avg": round(sum(lens) / len(lens), 2) if lens else None,
            "sentence_han_p90": lens[min(len(lens)-1, int(0.9 * (len(lens)-1)))] if lens else None}


def compare_edit_footprint(before: str, after: str) -> dict:
    original, revised = _stats(before), _stats(after)
    old = _clean(before)
    new = _clean(after)
    before_han = original["han_chars"]
    ratio = (revised["han_chars"] / before_han) if before_han else None
    # difflib estimates textual rewrite effort, not semantic distance or correctness.
    sampled = max(len(old), len(new)) > 6000
    # Cap the quadratic sequence comparison on entire manuscripts. This is only
    # a descriptive signal, never the source for scientific fidelity checking.
    if sampled:
        old_sample = old[:2200] + old[-2200:]
        new_sample = new[:2200] + new[-2200:]
    else:
        old_sample, new_sample = old, new
    similarity = difflib.SequenceMatcher(None, old_sample, new_sample, autojunk=sampled).ratio()
    reminders = []
    if ratio is not None and ratio > 1.25:
        reminders.append("篇幅增加超过25%：逐项解释新增信息是否必要、是否有证据；这不是自动错误判定")
    if ratio is not None and ratio < 0.70:
        reminders.append("篇幅减少超过30%：核对是否遗漏方法条件、比较对象、引用或不确定性")
    if sampled:
        reminders.append("长文只估算首尾文本的改写幅度；正文中段仍需人工逐项核对")
    if similarity < 0.65:
        reminders.append("文本改写幅度较大：逐项复核FACT LOCK与原始引文对应关系")
    if before == after:
        reminders.append("KEEP：文本完全未改，仍需单独核对原文事实")
    return {"before": original, "after": revised,
            "han_length_ratio": round(ratio, 3) if ratio is not None else None,
            "text_similarity_nonsemantic": round(similarity, 3),
            "similarity_sampled_first_last": sampled,
            "review_reminders": reminders,
            "warning": "仅用于描述篇幅和改写幅度；句长下降不证明可读性改善，零提示不证明事实保真"}


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("before", type=Path)
    p.add_argument("after", type=Path)
    p.add_argument("--format", choices=["markdown", "json"], default="markdown")
    args = p.parse_args()
    if not args.before.is_file() or not args.after.is_file():
        p.error("before/after must exist")
    try:
        result = compare_edit_footprint(args.before.read_text(encoding="utf-8"),
                                        args.after.read_text(encoding="utf-8"))
    except UnicodeDecodeError:
        p.error("Expect UTF-8 text")
    if args.format == "json":
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("# 修改足迹（非可读性分数）\n")
        for name in ("before", "after"):
            print(f"- {name}: {result[name]}")
        print(f"- 汉字长度比: {result['han_length_ratio']}；纯字面相似度: {result['text_similarity_nonsemantic']}")
        for note in result["review_reminders"]:
            print(f"- 待核查：{note}")
        print("\n"+result["warning"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
