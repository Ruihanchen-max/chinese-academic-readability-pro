#!/usr/bin/env python3
"""Read-only candidates for paragraph-flow review; NOT an automatic merge or readability score.

Usage:
    python scripts/paragraph_flow_audit.py manuscript.md --out-json paragraph_review.json
    python scripts/paragraph_flow_audit.py manuscript.docx

Heuristics are deliberately conservative, and all suggestions require human/scientific review.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

HEADING = re.compile(r'^(?:#{1,6}\s+|第[一二三四五六七八九十百0-9]+[章节篇][\s：:]|\d+(?:\.\d+){1,3}\s+\S)')
PROTECTED = re.compile(r'^(?:RQ\s*\d+|H\s*\d+|图\s*\d+|表\s*\d+|(?:Figure|Table)\s*\d+|参考文献|摘要|关键词[：:])', re.I)
LIST_ITEM = re.compile(r'^(?:[-*+]\s+|\d+[.)、]\s*|[（(][一二三四五六七八九十\d]+[)）])')
BRIDGE_LABEL = re.compile(r'^(?:研究准备|伦理与数据保护|研究局限与实施安排|总结与展望|本研究的意义)[。.]$')
RQ_H_PREFACE = re.compile(r'^(?:对应的研究假设与探索性预期(?:为)?|研究围绕以下.{0,12}科学问题展开)[：:]?$')
REPEATED_LEADS = ('本研究', '需要指出的是', '值得注意的是', '此外', '因此', '综上')
HANZI = re.compile(r'[\u3400-\u9fff]')
SCIENTIFIC_SCOPE = (
    ('study', re.compile(r'^(?:子研究|研究)\s*([一二三四五六七八九十\d]+)(?:[：:、\s]|$)')),
    ('measurement', re.compile(r'^(日常|事件)\s*EMA\b', re.I)),
    ('strategy', re.compile(r'^策略\s*([ABC])(?:[：:、\s]|$)', re.I)),
    ('design', re.compile(r'^(观察性|随机对照|随机试点|随机干预)')),
)


def separate_scientific_roles(a: str, b: str) -> bool:
    """Suppress heuristic merge cues for *explicitly contrasted* roles, not adjudicate meaning."""
    for _, pattern in SCIENTIFIC_SCOPE:
        ma, mb = pattern.match(a.strip()), pattern.match(b.strip())
        if ma and mb and ma.group(1) != mb.group(1):
            return True
    return False


def classify(text: str, style: str = '') -> str:
    s = text.strip()
    if not s:
        return 'blank'
    if style.lower().startswith(('heading', '标题', 'title')) or HEADING.match(s):
        return 'heading'
    if PROTECTED.match(s):
        return 'protected'
    if LIST_ITEM.match(s) or RQ_H_PREFACE.match(s) or s.startswith('|') or s.startswith('```'):
        return 'structured'
    if BRIDGE_LABEL.match(s):
        return 'bridge_label'
    return 'prose'


def read_paragraphs(path: Path) -> list[dict]:
    suffix = path.suffix.lower()
    if suffix == '.docx':
        try:
            from docx import Document
        except ImportError as e:
            raise ValueError('DOCX requires python-docx; install it or supply Markdown/TXT') from e
        doc = Document(path)
        items = [{'index': i + 1, 'text': p.text.strip(), 'kind': classify(p.text, p.style.name if p.style else '')}
                 for i, p in enumerate(doc.paragraphs) if p.text.strip()]
        # A real title/contents front section is not narrative prose. Only apply when both
        # a table of contents and the subsequent actual abstract heading can be identified.
        toc_i = next((i for i, x in enumerate(items) if re.fullmatch(r'(?:目\s*录|研究目录)', x['text'])), None)
        if toc_i is not None:
            abstract_i = next((i for i in range(toc_i + 1, len(items))
                               if re.fullmatch(r'摘\s*要', items[i]['text'])), None)
            if abstract_i is not None:
                for item in items[:abstract_i]:
                    item['kind'] = 'frontmatter'
        return items
    if suffix in {'.md', '.markdown', '.txt'}:
        source = path.read_text(encoding='utf-8')
        chunks = [x.strip() for x in re.split(r'\n\s*\n', source) if x.strip()]
        return [{'index': i + 1, 'text': x, 'kind': classify(x)} for i, x in enumerate(chunks)]
    raise ValueError('Only .docx, .md, .markdown or .txt is supported')


def _lead(s: str) -> str | None:
    t = s.strip().lstrip('“\"')
    for w in REPEATED_LEADS:
        if t.startswith(w):
            return w
    return None


def audit(paragraphs: list[dict]) -> dict:
    """Find *possible* candidates only; never infer that a pair should be merged."""
    items = [dict(p) for p in paragraphs if p.get('text', '').strip()]
    for p in items:
        if p.get('kind') not in {'heading','protected','structured','bridge_label','prose','frontmatter'}:
            p['kind'] = classify(p['text'])
    candidates: list[dict] = []
    protected_count = sum(1 for p in items if p['kind'] in {'heading','protected','structured','frontmatter'})
    for i, current in enumerate(items):
        if current['kind'] == 'bridge_label':
            candidates.append({
                'type': 'standalone_micro_label', 'position': current['index'],
                'note': 'Standalone label may interrupt narrative; first confirm it is not a real section heading.',
                'action': 'HUMAN_REVIEW_ONLY'})
        if i == 0:
            continue
        prev = items[i - 1]
        # No suggestions across real headings, numbered research questions/hypotheses or structured units.
        if prev['kind'] != 'prose' or current['kind'] != 'prose':
            continue
        a, b = prev['text'], current['text']
        if separate_scientific_roles(a, b):
            continue
        # Text length is a weak triage cue, NOT a criterion for merging or for writing quality.
        ac = len(HANZI.findall(a)); bc = len(HANZI.findall(b))
        if ac and bc and ac <= 70 and bc <= 70:
            candidates.append({
                'type': 'adjacent_short_prose', 'positions': [prev['index'], current['index']],
                'hanzi_counts': [ac, bc],
                'note': 'Check whether both paragraphs serve one argument; distinct roles must stay separate.',
                'action': 'HUMAN_REVIEW_ONLY'})
        lead_a, lead_b = _lead(a), _lead(b)
        if lead_a and lead_a == lead_b:
            candidates.append({
                'type': 'repeated_opening', 'positions': [prev['index'], current['index']],
                'opening': lead_a,
                'note': 'Repeated opening may be mechanical; it is not automatically redundant.',
                'action': 'HUMAN_REVIEW_ONLY'})
    return {
        'status': 'REVIEW_ONLY', 'paragraphs_examined': len(items),
        'protected_or_structured_count': protected_count,
        'candidate_count': len(candidates), 'candidates': candidates,
        'automatic_merges': 0, 'scientific_fidelity': 'UNVERIFIED',
        'readability_improvement': 'UNVERIFIED',
        'note': 'No paragraph-count target or pass/fail quality score. Review every candidate in context.'
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('--out-json', type=Path, default=None)
    args = parser.parse_args()
    try:
        result = audit(read_paragraphs(args.input))
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    data = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out_json:
        args.out_json.parent.mkdir(parents=True, exist_ok=True)
        args.out_json.write_text(data + '\n', encoding='utf-8')
    else:
        print(data)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
