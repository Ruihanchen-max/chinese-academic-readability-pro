#!/usr/bin/env python3
"""Create reproducible SVG/PDF charts from real CSV without inventing values.

Requires matplotlib. No smoothing, aggregation or imputation. Preserve source CSV.
For error intervals, supply lower/upper columns AND interval-label.
Example: python scripts/plot_verified_csv.py measurements.csv --x epoch --y accuracy --kind line --out-prefix figs/curve
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path


def _numeric(x, label):
    if x is None or not str(x).strip():
        return math.nan
    try:
        v=float(str(x))
    except ValueError:
        raise ValueError(f"Non-numeric {label}: {x!r}")
    if not math.isfinite(v):
        raise ValueError(f"Invalid nonfinite {label}: {x!r}")
    return v


def plot(source: Path, *, x: str, y: str, kind: str, out_prefix: Path,
         group: str|None=None, lower: str|None=None, upper: str|None=None,
         interval_label: str|None=None, xlabel: str|None=None, ylabel: str|None=None,
         title: str="") -> dict:
    if kind not in {"scatter", "line", "bar"}:
        raise ValueError("kind must be scatter, line or bar")
    if bool(lower) != bool(upper):
        raise ValueError("Lower and upper interval columns must be supplied together")
    if lower and not interval_label:
        raise ValueError("Interval type (CI/SD/SE/etc.) must be declared via --interval-label")
    if kind == 'bar' and group:
        raise ValueError("Grouped bar charts require explicit design; cannot silently aggregate groups")
    with source.open(encoding="utf-8-sig", newline="") as fh:
        reader=csv.DictReader(fh)
        names=set(reader.fieldnames or [])
        required={x,y}|({group} if group else set())|({lower,upper} if lower else set())
        if not required.issubset(names):
            raise ValueError("CSV missing column(s): " + ", ".join(sorted(required-names)))
        rows=list(reader)
    if not rows:
        raise ValueError("CSV has no rows")
    if kind=='bar' and len(rows)>40:
        raise ValueError("More than 40 bars; choose an appropriate summarized design, no automatic filtering")
    groups={}
    skipped=0
    missing_interval=0
    for i,row in enumerate(rows):
        name=row[group] if group else 'data'
        name=name or '(missing group)'
        if name not in groups:groups[name]=[]
        xv=str(row[x]) if kind=='bar' else _numeric(row[x],f'{x} row {i+1}')
        yv=_numeric(row[y],f'{y} row {i+1}')
        lo=_numeric(row[lower],f'{lower} row {i+1}') if lower else math.nan
        hi=_numeric(row[upper],f'{upper} row {i+1}') if upper else math.nan
        if math.isnan(yv): skipped+=1
        if lower and (math.isnan(lo) or math.isnan(hi)):missing_interval+=1
        if lower and all(math.isfinite(z) for z in (yv,lo,hi)) and not (lo<=yv<=hi):
            raise ValueError(f'Interval does not enclose observed value at row {i+1}')
        groups[name].append((xv,yv,lo,hi))
    if all(math.isnan(z[1]) for groupvals in groups.values() for z in groupvals):
        raise ValueError('All y values missing: figure would imply unsupported data')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(6.6,3.9),layout='constrained')
    for name,values in groups.items():
        xx=[z[0] for z in values]; yy=[z[1] for z in values]
        label=name if group else None
        if kind=='line':ax.plot(xx,yy,marker='o',markersize=4,linewidth=1.6,label=label)
        elif kind=='scatter':ax.scatter(xx,yy,s=25,label=label)
        else:
            categories=[str(z) for z in xx]
            ax.bar(categories,yy,label=label,alpha=.85)
            ax.set_ylim(bottom=0)
        if lower:
            valid=[(z[0],z[1],z[2],z[3]) for z in values if all(math.isfinite(v) for v in (z[1],z[2],z[3]))]
            if valid:
                ax.errorbar([z[0] for z in valid], [z[1] for z in valid],
                            yerr=[[z[1]-z[2] for z in valid],[z[3]-z[1] for z in valid]],
                            fmt='none',ecolor='0.35',elinewidth=1,capsize=3)
    ax.set_xlabel(xlabel or x)
    ax.set_ylabel(ylabel or y)
    if title:ax.set_title(title)
    if group:ax.legend(loc='best',frameon=False)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.grid(axis='y',alpha=.2)
    out_prefix.parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(out_prefix.with_suffix('.svg'))
    fig.savefig(out_prefix.with_suffix('.pdf'))
    plt.close(fig)
    sourcehash=hashlib.sha256(source.read_bytes()).hexdigest()
    result={"input":str(source), "input_sha256":sourcehash, "output_svg":str(out_prefix.with_suffix('.svg')),
            "output_pdf":str(out_prefix.with_suffix('.pdf')), "kind":kind, "x":x, "y":y,
            "group":group, "uncertainty":interval_label, "missing_y_rows":skipped,
            "missing_intervals":missing_interval, "data_rows":len(rows), "matplotlib_version":matplotlib.__version__,
            "transformations":"none; original input row order, no aggregation, imputation or smoothing",
            "final_visual_check":"UNVERIFIED", "scientific_interpretation":"UNVERIFIED"}
    out_prefix.with_name(out_prefix.name+'_provenance').with_suffix('.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return result


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('csv_file',type=Path)
    ap.add_argument('--x',required=True); ap.add_argument('--y',required=True)
    ap.add_argument('--kind',choices=['line','scatter','bar'],default='scatter')
    ap.add_argument('--group');ap.add_argument('--lower');ap.add_argument('--upper');ap.add_argument('--interval-label')
    ap.add_argument('--xlabel');ap.add_argument('--ylabel');ap.add_argument('--title',default='')
    ap.add_argument('--out-prefix',type=Path,required=True)
    a=ap.parse_args()
    try:
        result=plot(a.csv_file,x=a.x,y=a.y,kind=a.kind,out_prefix=a.out_prefix,group=a.group,
                    lower=a.lower,upper=a.upper,interval_label=a.interval_label,xlabel=a.xlabel,ylabel=a.ylabel,title=a.title)
    except (OSError, ValueError, ImportError) as e:
        print(json.dumps({'status':'FAIL','reason':str(e)},ensure_ascii=False))
        return 1
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0
if __name__=='__main__':raise SystemExit(main())
