#!/usr/bin/env python3
"""Screen whether an academic figure is editable PPT native art + real SVG geometry.

Structural hints ONLY. PASS is a source-format PASS, never visual/content/font approval.
Only standard Python library is required.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET
from zipfile import ZipFile, BadZipFile

SVG_DRAW_TAGS = frozenset({"path", "rect", "line", "polyline", "polygon", "circle", "ellipse", "text", "use"})
PML_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def inspect_pptx(path: Path) -> dict:
    if not path.is_file():
        raise ValueError(f"PPTX not found: {path}")
    if path.suffix.lower() != ".pptx":
        raise ValueError("Expected a .pptx source file")
    try:
        with ZipFile(path) as archive:
            slides = sorted(
                name for name in archive.namelist()
                if re.fullmatch(r"ppt/slides/slide\d+\.xml", name)
            )
            if not slides:
                raise ValueError("No PPTX slide XML parts")
            native_shapes = 0
            connectors = 0
            pictures = 0
            text_runs = 0
            for slide in slides:
                doc = ET.fromstring(archive.read(slide))
                native_shapes += len(doc.findall(f".//{{{PML_NS}}}sp"))
                connectors += len(doc.findall(f".//{{{PML_NS}}}cxnSp"))
                pictures += len(doc.findall(f".//{{{PML_NS}}}pic"))
                text_runs += len(doc.findall(f".//{{{A_NS}}}t"))
    except BadZipFile as exc:
        raise ValueError("PPTX is not a valid ZIP container") from exc
    except ET.ParseError as exc:
        raise ValueError("Malformed PPTX slide XML") from exc
    return {
        "slide_count": len(slides),
        "native_shapes": native_shapes,
        "editable_connectors": connectors,
        "picture_shapes": pictures,
        "editable_text_runs": text_runs,
    }


def inspect_svg(path: Path) -> dict:
    if not path.is_file():
        raise ValueError(f"SVG not found: {path}")
    if path.suffix.lower() != ".svg":
        raise ValueError("Expected an .svg output file")
    try:
        root = ET.parse(path).getroot()
    except ET.ParseError as exc:
        raise ValueError("SVG XML is invalid") from exc
    if local_name(root.tag) != "svg":
        raise ValueError("XML root element is not SVG")
    drawable_count = 0
    text_count = 0
    image_count = 0
    embedded_raster = 0
    external_images = 0

    def walk(node: ET.Element, in_defs: bool = False) -> None:
        nonlocal drawable_count, text_count, image_count, embedded_raster, external_images
        tag = local_name(node.tag)
        in_defs = in_defs or tag in {"defs", "symbol", "clipPath", "mask", "pattern"}
        if not in_defs and tag in SVG_DRAW_TAGS:
            drawable_count += 1
            if tag == "text":
                text_count += 1
        if not in_defs and tag == "image":
            image_count += 1
            href = next((v for k, v in node.attrib.items() if local_name(k) == "href"), "")
            if href.lower().startswith("data:image/") or re.search(r"\.(png|jpe?g|gif|webp)(?:[?#]|$)", href, re.I):
                embedded_raster += 1
            elif href:
                external_images += 1
        for child in node:
            walk(child, in_defs)

    walk(root)
    return {
        "actual_vector_elements": drawable_count,
        "text_elements": text_count,
        "image_elements": image_count,
        "raster_images": embedded_raster,
        "external_image_references": external_images,
        "has_viewbox": "viewBox" in root.attrib,
    }


def audit(pptx: Path, svg: Path) -> dict:
    source = inspect_pptx(pptx)
    vector = inspect_svg(svg)
    failures = []
    warnings = []
    if source["native_shapes"] + source["editable_connectors"] == 0:
        failures.append("PPTX_NOT_EDITABLE_VECTOR: only pictures or no shapes were found")
    if vector["actual_vector_elements"] == 0:
        failures.append("SVG_NOT_VECTOR: no drawable vector/text elements outside definitions")
    if source["picture_shapes"]:
        warnings.append("PPTX_HAS_PICTURES: inspect for full-page bitmap; real photos can be a justified exception")
    if vector["image_elements"]:
        warnings.append("SVG_HAS_IMAGES: inspect raster embedding/external links; a raster wrapper is not a vector diagram")
    if source["slide_count"] > 1:
        warnings.append("MULTIPLE_SLIDES: confirm which slide corresponds to this SVG")
    if not vector["has_viewbox"]:
        warnings.append("SVG_NO_VIEWBOX: verify scaling and cropping in DOCX/PDF")
    return {
        "structure_status": "FAIL" if failures else "UNVERIFIED" if warnings else "PASS",
        "source_pptx": str(pptx),
        "output_svg": str(svg),
        "pptx_structure": source,
        "svg_structure": vector,
        "failures": failures,
        "warnings": warnings,
        "visual_fidelity": "UNVERIFIED",
        "scientific_content_fidelity": "UNVERIFIED",
        "font_compliance": "UNVERIFIED",
        "note": "Only file structure is screened. Open the PPTX and SVG and check the final PDF visually; do not infer scientific or visual PASS.",
    }


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("pptx", type=Path)
    p.add_argument("svg", type=Path)
    p.add_argument("--out-json", type=Path)
    a = p.parse_args()
    try:
        result = audit(a.pptx, a.svg)
    except (OSError, ValueError) as exc:
        result = {"structure_status": "FAIL", "error": str(exc), "visual_fidelity": "UNVERIFIED"}
    output = json.dumps(result, ensure_ascii=False, indent=2)
    print(output)
    if a.out_json:
        a.out_json.parent.mkdir(parents=True, exist_ok=True)
        a.out_json.write_text(output + "\n", encoding="utf-8")
    return 1 if result["structure_status"] == "FAIL" else 0


if __name__ == "__main__":
    raise SystemExit(main())
