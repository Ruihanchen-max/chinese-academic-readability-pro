#!/usr/bin/env python3
"""Advisory writing-depth audit: NEVER automatically rewrite or certify scientific adequacy.

The selected document purpose controls the *suggestions*. No word count, section
count or jargon count can prove scientific quality. Read-only, standard library.
Supports .txt/.md/.docx; optional --baseline and a manually curated core lock.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import re
import sys
import zipfile
from xml.etree import ElementTree as ET

DOCX_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
PROFILES = {
    "course-preproposal": {
        "reader": "博士课程教师：科学问题、主要设计、关键比较及可行性",
        "principle": "保留科学骨架，实施原则简述，非决定性技术细则只读提示删减候选",
        "detail_review": True,
    },
    "formal-protocol": {
        "reader": "研究实施、伦理、数据管理及统计团队",
        "principle": "可复现与预先规定的实施条件需要较高细节，不得按课程开题规则自动删去",
        "detail_review": False,
    },
    "grant-proposal": {
        "reader": "项目评审专家：创新性、科学可检验性与资源可行性",
        "principle": "突出研究价值与核心路线，按资助机构要求保留风险与里程碑",
        "detail_review": True,
    },
    "empirical-manuscript": {
        "reader": "领域编辑、审稿人与复现研究者",
        "principle": "方法、结果和统计报告以证据完整及报告规范优先，不能仅为通顺删掉必要数字",
        "detail_review": False,
    },
    "theory-paper": {
        "reader": "理论研究者：概念、命题与推理的可追踪性",
        "principle": "以概念界定、证据与反例评价深度，不套用实证样本/统计量规则",
        "detail_review": False,
    },
    "review-paper": {
        "reader": "综述领域读者：证据结构、检索/纳排与异质性",
        "principle": "系统综述应保留检索和偏倚方法，叙述综述突出解释与综合",
        "detail_review": False,
    },
}

# Signals for possible implementation-protocol detail. Flag only for review and
# only in profiles whose audience can likely benefit from summarization.
DETAIL_SIGNALS = [
    ("formula_and_threshold", r"(?:\b(?:V|D|J|U)\s*[≥<=＝]|[≥≤]\s*\d+(?:\.\d+)?\s*%|\bICC\s*[=＝]|半宽约|t\(\d+\)|置信区间半宽)"),
    ("imputation_implementation", r"(?:Barnard[–-]?Rubin|Rubin\s*规则|\bHC3\b|\bMICE\b|\d+\s*(?:次|份)\s*(?:多重)?插补|预测均值匹配)"),
    ("notification_edge_cases", r"(?:通知冲突|延迟上传|时间戳|跨日(?:通知|改时|回复)|补传期|异常编码|提醒上限|通知总数上限|\d+\s*次通知)"),
    ("resampling_gate", r"(?:删一日|逐一删除参与者|留一日(?:剔除|重算)|\d+\s*次重算|三级判断流程|明显不可行|区间退化|点估计通过)"),
    ("enumerated_operations", r"(?:数据快照|日志字段|权限操作|详细编码|服务器接收时间|并列排序|回退原因|资料门槛)"),
]
_DETAIL_REGEX = [(name, re.compile(pat, re.IGNORECASE)) for name, pat in DETAIL_SIGNALS]


def _docx_paragraphs(path: Path) -> list[str]:
    with zipfile.ZipFile(path) as zipf:
        raw = zipf.read("word/document.xml")
    tree = ET.fromstring(raw)
    lines = []
    for p in tree.iter(DOCX_W + "p"):
        # Join Word runs, including text inside table cells, excluding bibliography
        # only when a heading is exactly "参考文献" (TOC entries not mistaken).
        content = "".join(
            (node.text or "") if node.tag in (DOCX_W+"t", DOCX_W+"instrText")
            else "\t" if node.tag == DOCX_W+"tab" else ""
            for node in p.iter()
        ).strip()
        if content:
            lines.append(content)
    return lines


def read_paragraphs(path: Path) -> list[str]:
    if path.suffix.lower() == ".docx":
        return _docx_paragraphs(path)
    if path.suffix.lower() in (".txt", ".md"):
        raw = path.read_text(encoding="utf-8")
        paras = re.split(r"\n\s*\n", raw.replace("\r\n", "\n"))
        return [re.sub(r"\s+", " ", p).strip() for p in paras if p.strip()]
    raise ValueError("Supported inputs: .txt, .md, .docx")


def body_paragraphs(paragraphs: list[str]) -> list[tuple[int, str]]:
    body = []
    for i, p in enumerate(paragraphs, start=1):
        if re.sub(r"\s+", "", p) == "参考文献":
            break
        # Avoid treating TOC dot-leader lines as the body.
        if re.search(r"(?:…|\.{4,})\s*\d+\s*$", p):
            continue
        body.append((i, p))
    return body


def _content_size(paragraphs: list[tuple[int, str]]) -> int:
    return sum(len(re.sub(r"\s+", "", p)) for _, p in paragraphs)


def load_core_lock(path: Path | None) -> list[dict]:
    if path is None:
        return []
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict) or not isinstance(data.get("locks"), list):
        raise ValueError("Core-lock JSON must contain a 'locks' list")
    locks = []
    for item in data["locks"]:
        if not isinstance(item, dict) or not isinstance(item.get("id"), str):
            raise ValueError("Each lock requires a string 'id'")
        groups = item.get("required_groups")
        if (not isinstance(groups, list) or not groups or any(
            not isinstance(g, list) or not g or not all(isinstance(t, str) and t for t in g)
            for g in groups
        )):
            raise ValueError(f"Lock {item['id']} requires nonempty required_groups of literal alternatives")
        locks.append(item)
    return locks


def match_locks(paragraphs: list[tuple[int, str]], locks: list[dict]) -> dict[str, bool]:
    full = "".join(re.sub(r"\s+", "", p).casefold() for _, p in paragraphs)
    return {
        lock["id"]: all(any(re.sub(r"\s+", "", term).casefold() in full for term in group)
                        for group in lock["required_groups"])
        for lock in locks
    }


def audit(path: Path, profile: str, core_lock: Path | None = None,
          baseline: Path | None = None) -> dict:
    if profile not in PROFILES:
        raise ValueError(f"Unknown profile: {profile}")
    paras = body_paragraphs(read_paragraphs(path))
    profile_info = PROFILES[profile]
    findings = []
    signal_summary = Counter()
    for index, p in paras:
        kinds = [name for name, reg in _DETAIL_REGEX if reg.search(p)]
        if not kinds:
            continue
        signal_summary.update(kinds)
        findings.append({
            "paragraph": index,
            "excerpt": p[:130] + ("…" if len(p) > 130 else ""),
            "possible_tier": "C?" if profile == "course-preproposal" else "B/C?",
            "signals": kinds,
            "decision": "REVIEW_ONLY" if profile_info["detail_review"] else "PRESERVE_UNTIL_METHOD_REVIEW",
            "caution": "仅为实施细节候选，不能自动删除；若决定结局、分组或伦理安全则保留",
        })
    locks = load_core_lock(core_lock)
    target = match_locks(paras, locks)
    source = match_locks(body_paragraphs(read_paragraphs(baseline)), locks) if baseline else None
    lock_findings = []
    for lock in locks:
        exists = target[lock["id"]]
        old = source[lock["id"]] if source else None
        status = "ANCHOR_PRESENT_NEEDS_SEMANTIC_REVIEW" if exists else (
            "STOP_AND_REVIEW" if old else "MISSING_OR_REPHRASED_REVIEW")
        lock_findings.append({
            "id": lock["id"], "label": lock.get("label", lock["id"]),
            "present_in_target": exists, "present_in_baseline": old, "status": status,
        })
    return {
        "tool": "depth_control_audit", "result_type": "ADVISORY_NOT_PERFORMANCE_SCORE",
        "input": str(path), "profile": profile, "target_reader": profile_info["reader"],
        "profile_principle": profile_info["principle"],
        "paragraph_count_including_frontmatter": len(paras),
        "nonwhitespace_chars_excluding_bibliography": _content_size(paras),
        "engineering_detail_signals": dict(signal_summary),
        "possible_detail_paragraphs": findings, "core_lock_findings": lock_findings,
        "manual_scholarly_review_required": True,
        "gate": "STOP_AND_REVIEW" if any(x["status"] == "STOP_AND_REVIEW" for x in lock_findings)
                else "UNVERIFIED",
        "limits": [
            "文字信号不是应删内容的判断；含统计方法的正式论文和伦理方案不能按开题等级压缩",
            "字面锁出现不证明语义正确；字面锁缺失也可能是合理改写，必须由作者/方法审查决定",
            "未执行读者理解盲评、论文内容自动重写或 DOCX/PDF 视觉检查",
        ],
    }


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("input", type=Path)
    p.add_argument("--profile", choices=PROFILES, required=True,
                   help="Explicit document purpose; never guess silently")
    p.add_argument("--core-lock", type=Path)
    p.add_argument("--baseline", type=Path)
    p.add_argument("--out-json", type=Path)
    args = p.parse_args()
    try:
        result = audit(args.input, args.profile, args.core_lock, args.baseline)
    except (OSError, KeyError, ValueError, ET.ParseError, zipfile.BadZipFile) as ex:
        print(f"ERROR: {ex}", file=sys.stderr)
        return 2
    content = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out_json:
        args.out_json.parent.mkdir(parents=True, exist_ok=True)
        args.out_json.write_text(content + "\n", encoding="utf-8")
    print(content)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
