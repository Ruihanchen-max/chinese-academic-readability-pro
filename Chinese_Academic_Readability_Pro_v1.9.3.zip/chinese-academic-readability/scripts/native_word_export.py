#!/usr/bin/env python3
"""Export an academic DOCX using installed Microsoft Word with genuine fonts.

Never falls back silently to LibreOffice. If unavailable or fonts not installed,
returns UNVERIFIED. The Word export is rechecked for actual embedded fonts.
macOS AppleScript path is provided for local use and must be validated on that
machine; it has not been tested in this Linux environment.
"""
from __future__ import annotations
import argparse
import json
import platform
import shutil
import subprocess
import sys
from pathlib import Path

from font_audit import audit
from font_environment import inspect_environment


def native_export(docx:Path,out_dir:Path)->dict:
    docx=Path(docx).expanduser().resolve();out_dir=Path(out_dir).expanduser().resolve()
    out_dir.mkdir(parents=True,exist_ok=True)
    result={'status':'UNVERIFIED','docx':str(docx),'pdf':str(out_dir/(docx.stem+'.pdf')),
            'platform':platform.system(),'export_engine':None,'fonts':inspect_environment(), 'reason':None}
    if not docx.is_file():result['reason']='DOCX not found';return result
    if result['fonts']['status']!='PASS':
        result['reason']='Genuine SimSun and/or Times New Roman are not available locally. Install licensed fonts before native Word export.'
        return result
    target=Path(result['pdf'])
    if target.exists():target.unlink()  # stale output cannot pass verification
    try:
        if platform.system()=='Windows':
            try:import win32com.client
            except ImportError:
                result['reason']='pywin32 is missing or Microsoft Word COM cannot be used';return result
            word=None;document=None
            try:
                word=win32com.client.DispatchEx('Word.Application')
                word.Visible=False;word.DisplayAlerts=0
                document=word.Documents.Open(str(docx),ReadOnly=True)
                document.ExportAsFixedFormat(str(target),17)
                result['export_engine']='Microsoft Word Windows COM '+str(word.Version)
            finally:
                if document is not None:document.Close(False)
                if word is not None:word.Quit()
        elif platform.system()=='Darwin':
            if not shutil.which('osascript'):
                result['reason']='osascript unavailable; use Microsoft Word > Save As > PDF manually';return result
            script='''on run argv
set sourceFile to item 1 of argv
set destFile to item 2 of argv
tell application "Microsoft Word"
    open (POSIX file sourceFile)
    set theDocument to active document
    save as theDocument file name destFile file format format PDF
    close theDocument saving no
end tell
end run'''
            run=subprocess.run(['osascript','-e',script,str(docx),str(target)],capture_output=True,text=True,timeout=240)
            if run.returncode!=0:
                result['reason']='Word AppleScript export failed; save as PDF manually: '+(run.stderr or run.stdout).strip()[:300]
                return result
            result['export_engine']='Microsoft Word for macOS (AppleScript, local execution unverified)'
        else:
            result['reason']='Microsoft Word native export not available on this platform'
            return result
    except Exception as exc:
        result['reason']='Native Word export failed: '+str(exc)[:300];return result
    if not target.is_file() or target.stat().st_size<300:
        result['status']='FAIL';result['reason']='Word did not produce a usable PDF';return result
    result['font_audit']=audit(docx,target)
    result['status']=result['font_audit']['status']
    result['reason']='Word PDF produced and font check finished. All-page artifact-qa sign-off remains necessary.'
    return result


def main()->int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('docx',type=Path);p.add_argument('--out-dir',required=True,type=Path)
    p.add_argument('--out-json',type=Path)
    a=p.parse_args();result=native_export(a.docx,a.out_dir)
    if a.out_json:a.out_json.parent.mkdir(parents=True,exist_ok=True);a.out_json.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return {'PASS':0,'FAIL':1,'UNVERIFIED':2}.get(result['status'],2)
if __name__=='__main__':raise SystemExit(main())
