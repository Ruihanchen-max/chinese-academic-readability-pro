#!/usr/bin/env python3
"""Offline rule-based candidate risks in Chinese academic prose, NOT semantic proof.

v1.2: retains paragraph/line context, distinguishes *explicitly* prior evidence
from the current study where possible, and expands negative-control safeguards.
A missed flag NEVER establishes safety; a flag NEVER proves misconduct.
Python standard library only.
"""
from __future__ import annotations

import argparse
from decimal import Decimal, InvalidOperation
import json
import re
from pathlib import Path

CJK_RE = re.compile(r"[\u3400-\u9fff]")
SENTENCE_SPLITTER = re.compile(r"(?<=[。！？!?；;])")
EMPTY_PHRASES = (
    "具有重要的理论意义和实践价值", "多维协同作用机制", "深层次内在逻辑",
    "系统性耦合关系", "形成有效路径", "提供坚实的因果证据", "在一定程度上可能具有",
)
CONNECTOR_RE = re.compile(r"^(此外|与此同时|值得注意的是|需要指出的是|综上所述|进一步而言|在此基础上)[，,：:]?")
OBSERVATIONAL = re.compile(
    r"横断面|断面研究|横断调查|横断研究|问卷调查|观察性研究|观察性调查|回顾性研究|"
    r"相关性研究|关联分析|相关分析|同一天收集|同期测量|同一时间点"
)
PRIOR_SOURCE = re.compile(r"(?:既往|此前|之前|现有|已有|既有|前人|其他|以往|已发表)(?:.{0,9})(?:研究|随机试验|临床试验|试验|文献|证据)|文献报道|有研究指出")
CAUSAL = re.compile(
    r"(?:证实|证明|表明|说明|因此|因而|可以|能够|有效|能).{0,35}"
    r"(?:降低|减少|改善|促进|提高|提升|预防|治疗|导致|引发|缓解|减轻|防治|摆脱|恶化|消除|引起)"
    r"|(?:降低|减少|改善|促进|提高|提升|预防|治疗|导致|引发|缓解|减轻|防治|摆脱).{0,15}(?:因果|有效)"
    r"|(?:证明|证实|结果显示|表明).{0,38}(?:越多|越少|越高).{0,18}(?:越高|越低|越少|越多)"
    r"|(?:锻炼|运动|活动|久坐|暴露).{0,28}(?:导致|引发|使得|促使).{0,24}(?:降低|减少|增加|改善|恶化)"
)
NEGATION = re.compile(r"不能|无法|尚不能|不足以|并不能|不意味着|不宜|不得|不应|未能|尚无|不支持|不能据此|不代表|并非|未必|不一定|不等于|不应据此")
NONSIGNIFICANT = re.compile(r"差异.{0,16}(?:未达|未达到|没有达到|不具有|无).{0,14}(?:显著|统计学)|未达(?:到)?统计(?:学)?显著|未检出显著|无统计学显著性|结果不显著")
P_VALUE_RE = re.compile(r"(?<![A-Za-z])(?:P|p)\s*(=|＝|>|≥)\s*(0?\.\d+|1(?:\.0*)?)")
EQUIVALENCE = re.compile(
    r"完全相同|完全一致|没有任何差异|毫无差异|效果相同|效果等同|同样有效|无区别|"
    r"不存在差别|没有差别|不存在关联|没有差异|等效|不劣于|非劣|无效"
)
PLANNED = re.compile(r"拟招募|计划招募|计划开展|拟开展|拟进行|预期|尚未开展|将开展|将招募|计划实施|研究方案|拟于.{0,12}开展")
COMPLETED = re.compile(r"(?:本研究|研究|结果|数据|试验|实验|分析).{0,12}(?:证实|证明|已证实|表明|发现|显示|已经完成)|已经证实|结果显示|结果表明|已经完成|证实.{0,8}有效|已证明|试验已证实")
UNIVERSAL_CLAIM = re.compile(
    r"(?:所有|全部|一切|任何|普遍|每个人|人人|均|必然).{0,45}"
    r"(?:都会?下降|都会?改善|会?改善|会?降低|能.{0,8}改善|能.{0,8}降低|"
    r"有效|改善|提升|促进|降低|减少|成功|适用|治愈|摆脱|防治)"
)
SAMPLE_SCOPE = re.compile(r"样本内|仅在本样本|仅针对本样本|本样本中的|本研究观察到的|这项研究观察到的")
MEDIATION = re.compile(r"相关|关联")
MECHANISM_CLAIM = re.compile(
    r"(?:因此|进而|从而|由此|可见|说明|证明|证实|揭示).{0,45}(?:中介|神经机制|作用机制|机制|传导路径|通过.{0,35}(?:作用|影响|改善|发挥|降低))"
    r"|(?:证实|证明|揭示).{0,30}(?:通过|中介|作用机制|传导路径)"
)
EMPTY_SIGNIFICANCE = re.compile(
    r"(?:本研究|该研究|这一研究|研究成果|这项工作).{0,12}(?:具有|存在|具备).{0,7}(?:重要|重大|深远).{0,14}(?:意义|价值|贡献)"
    r"|(?:具有|意义在于).{0,15}(?:理论意义|实践价值)"
    r"|(?:本研究|本文|该研究).{0,12}(?:对于|对).{0,15}(?:学术界|领域|实践).{0,15}(?:不可替代|巨大|重大).{0,10}(?:贡献|价值|意义)"
)
SPECIFIC_CONTENT = re.compile(r"样本|研究对象|数据|变量|步数|量表|模型|测量|对照|分析|检验|关联|假设|观察|比较|实验|引文|结果|结论|调查|问卷|试验|干预|识别|[0-9]")
CLAUSE_SPLITTER = re.compile(r"[，,]|(?<=。)\s*(?=但|然而|不过)|(?=但(?:是)?|然而|不过|而本研究)")


def _issue(line: int, typ: str, severity: str, evidence: str, hint: str) -> dict:
    return {"line": line, "type": typ, "severity": severity,
            "evidence": evidence.strip()[:120], "hint": hint}


def _is_negated(clause: str, claim_start: int = 0) -> bool:
    """Local, imprecise hedge/negation suppression; never a semantic verifier."""
    prefix = clause[max(0, claim_start - 27):claim_start + 12]
    return bool(NEGATION.search(prefix))


def _prior_clause(clause: str) -> bool:
    """Explicit attribution to *prior* research, not an unqualified current result."""
    src = PRIOR_SOURCE.search(clause)
    cur = re.search(r"本研究|本试验|本调查|本项目", clause)
    if src and (not cur or src.start() <= cur.start()):
        return True
    return False


def _potentially_nonsignificant(text: str) -> bool:
    if NONSIGNIFICANT.search(text):
        return True
    for hit in P_VALUE_RE.finditer(text):
        try:
            if Decimal(hit.group(2)) >= Decimal("0.05"):
                return True
        except InvalidOperation:
            pass
    return False


def _paragraphs(text: str) -> list[list[tuple[int, str]]]:
    """Combine adjacent Markdown lines; do not merge across blank paragraphs."""
    blocks: list[list[tuple[int, str]]] = []
    active: list[tuple[int, str]] = []
    fenced = False
    def flush():
        nonlocal active
        if active:
            blocks.append(active)
            active = []
    for line_no, raw in enumerate(text.splitlines(), 1):
        s = raw.strip()
        if s.startswith("```"):
            flush()
            fenced = not fenced
            continue
        if fenced or not s or s.startswith("#") or s.startswith("|"):
            flush()
            continue
        active.append((line_no, s))
    flush()
    return blocks


def _sentences(block: list[tuple[int, str]]) -> list[tuple[int, str]]:
    joined = "\n".join(s for _, s in block)
    base_lines = [line for line, _ in block]
    out: list[tuple[int, str]] = []
    offset = 0
    for chunk in SENTENCE_SPLITTER.split(joined):
        stripped = chunk.strip()
        if stripped:
            starts_at = min(joined.count("\n", 0, offset + len(chunk) - len(chunk.lstrip())), len(base_lines) - 1)
            out.append((base_lines[starts_at], stripped))
        offset += len(chunk)
    return out


def audit_text(text: str, long_sentence_threshold: int = 90) -> list[dict]:
    issues: list[dict] = []
    para_connectors: dict[str, list[int]] = {}
    for block in _paragraphs(text):
        sentences = _sentences(block)
        for line_no, line in block:
            for phrase in EMPTY_PHRASES:
                if phrase in line:
                    issues.append(_issue(line_no, "abstract_phrase", "low", phrase,
                                         "核对是否有实质信息贡献；有明确概念与证据时可保留"))
            connector = CONNECTOR_RE.search(line)
            if connector:
                para_connectors.setdefault(connector.group(1), []).append(line_no)
        for idx, (line_no, sentence) in enumerate(sentences):
            for segment in SENTENCE_SPLITTER.split(sentence):
                count = len(CJK_RE.findall(segment))
                if count > long_sentence_threshold:
                    item = _issue(line_no, "long_sentence_candidate", "low", segment[:72],
                                  "检查句法负担，而不是机械截断长句")
                    item["cjk_chars"] = count
                    issues.append(item)
            # Use only *preceding* sentences for design, significance and study plan.
            context = " ".join(s for _, s in sentences[:idx + 1])
            previous = " ".join(s for _, s in sentences[:idx])
            observational_context = bool(OBSERVATIONAL.search(context))
            planned_context = bool(PLANNED.search(context))
            nonsig_context = _potentially_nonsignificant(context)
            correlation_context = bool(MEDIATION.search(context))
            # Comma-level scoping: previous RCT evidence != current study evidence.
            clauses = [c.strip() for c in CLAUSE_SPLITTER.split(sentence) if c.strip()]
            for clause in clauses:
                if _prior_clause(clause):
                    continue
                if observational_context:
                    causal = CAUSAL.search(clause)
                    if causal and not _is_negated(clause, causal.start()):
                        issues.append(_issue(line_no, "observational_causal_overclaim", "critical", causal.group(),
                                             "当前观察性设计与因果/干预效果表述可能不匹配；请核查研究来源与推断条件"))
                if nonsig_context:
                    eq = EQUIVALENCE.search(clause)
                    if eq and not _is_negated(clause, eq.start()):
                        issues.append(_issue(line_no, "nonsignificant_as_equivalence", "critical", eq.group(),
                                             "非显著不等于等效、无效或非劣；检查检验目标、区间和效能"))
                if planned_context:
                    completed = COMPLETED.search(clause)
                    if completed and not _is_negated(clause, completed.start()):
                        issues.append(_issue(line_no, "planned_as_completed", "critical", completed.group(),
                                             "计划中的本研究与已完成研究结果可能混淆；核查证据主体"))
                if correlation_context:
                    mechanism = MECHANISM_CLAIM.search(clause)
                    if mechanism and not _is_negated(clause, mechanism.start()):
                        issues.append(_issue(line_no, "association_as_mediation", "critical", mechanism.group(),
                                             "相关本身不能证实中介或机制；需核查模型、时序与独立证据"))
            # Sentence context is needed for universal statements with sample qualifiers.
            if UNIVERSAL_CLAIM.search(sentence) and not SAMPLE_SCOPE.search(sentence):
                if not (NEGATION.search(sentence[:22]) or re.search(r"(?:并非|不是|未必|不能|不一定).{0,20}(?:所有|全部|每个人)", sentence)):
                    issues.append(_issue(line_no, "universal_effect_claim", "high", sentence[:96],
                                         "对所有人群/情形的普遍有效性陈述需核查范围与来源；不是自动判断错误"))
            if EMPTY_SIGNIFICANCE.search(sentence) and len(sentence) <= 100 and not SPECIFIC_CONTENT.search(sentence):
                issues.append(_issue(line_no, "significance_without_claim", "medium", sentence[:96],
                                     "可能只有价值判断，没有具体发现、问题或论证"))
    for connector, occurrences in para_connectors.items():
        if len(occurrences) >= 3:
            issues.append({**_issue(occurrences[0], "repeated_connector", "low", connector,
                                     "连接词重复：核查段落间是否有真实递进"), "lines": occurrences})
    seen: set[tuple[int, str]] = set()
    output: list[dict] = []
    for item in sorted(issues, key=lambda x: (x["line"], x["type"], x["evidence"])):
        k = (item["line"], item["type"])
        if k not in seen:
            output.append(item)
            seen.add(k)
    return output


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("path", type=Path, help="UTF-8 .txt/.md")
    p.add_argument("--format", choices=["json", "markdown"], default="markdown")
    p.add_argument("--long-threshold", type=int, default=90)
    args = p.parse_args()
    if args.long_threshold < 20:
        p.error("--long-threshold must be at least 20")
    if not args.path.is_file():
        p.error("File not found")
    try:
        content = args.path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        p.error("Expected UTF-8 input")
    found = audit_text(content, args.long_threshold)
    warning = "启发式风险候选，不是科研事实裁决或可读性分数；零提示≠无风险，提示≠实质错误"
    if args.format == "json":
        print(json.dumps({"input": str(args.path), "warning": warning, "issues": found}, ensure_ascii=False, indent=2))
    else:
        print("# 中文学术文本候选风险（只读）\n\n" + warning + "\n")
        if not found:
            print("未命中当前规则，仍需检查研究事实、引用和论证。")
        for issue in found:
            print(f"- L{issue['line']} / {issue['severity']} / {issue['type']}: `{issue['evidence']}` — {issue['hint']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
