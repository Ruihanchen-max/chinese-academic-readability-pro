#!/usr/bin/env python3
"""Strict, *source-backed* font QA for Chinese academic DOCX and exported PDF.

DOCX font declarations are not evidence that the PDF uses the actual fonts.
PDF font substitution is FAIL under a strict SimSun/Times New Roman policy.
Math fonts and text baked into images remain separate visual-verification topics.
"""
from __future__ import annotations
import argparse
import json
from collections import Counter
from pathlib import Path
from zipfile import ZipFile
from lxml import etree

W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
Q=lambda x:f'{{{W}}}{x}'
EAST='SimSun'
LATIN='Times New Roman'

def _target_equal(value, expected):
    return (value or '').casefold().replace(' ', '')==expected.casefold().replace(' ', '')

def inspect_docx(path:Path)->dict:
    """Only declared fonts in *used* styles/direct runs; unused theme/fontTable metadata ignored."""
    problems=[]; count=Counter(); used=set(); rfonts=[]; has_visible=False
    with ZipFile(path) as z:
        names=[n for n in z.namelist() if n=='word/document.xml' or n.startswith('word/header') and n.endswith('.xml') or n.startswith('word/footer') and n.endswith('.xml')]
        for name in names:
            root=etree.fromstring(z.read(name))
            for el in root.iter():
                if el.tag in (Q('pStyle'),Q('rStyle')) and el.get(Q('val')):used.add(el.get(Q('val')))
                if el.tag==Q('t') and (el.text or '').strip():has_visible=True
                if el.tag==Q('rFonts'):
                    rfonts.append((name,el))
        sr=etree.fromstring(z.read('word/styles.xml'))
        styles={s.get(Q('styleId')):s for s in sr.findall(Q('style')) if s.get(Q('styleId'))}
        for sid,s in styles.items():
            if s.get(Q('default'))=='1' and s.get(Q('type')) in ('paragraph','character'):used.add(sid)
        todo=list(used)
        while todo:
            sid=todo.pop();s=styles.get(sid)
            if s is not None:
                based=s.find(Q('basedOn'))
                if based is not None:
                    base=based.get(Q('val'))
                    if base and base not in used:used.add(base);todo.append(base)
        for sid in used:
            s=styles.get(sid)
            if s is not None:
                rp=s.find(Q('rPr'))
                if rp is not None:
                    rf=rp.find(Q('rFonts'))
                    if rf is not None:rfonts.append(('style:'+sid,rf))
        # docDefaults may still contain unused theme placeholders. Explicitly used
        # paragraph/character style declarations take precedence over that theme.
        defaults=sr.find(Q('docDefaults'))
        if defaults is not None and not any(loc.startswith('style:') for loc,_ in rfonts):
            for el in defaults.iter(Q('rFonts')):rfonts.append(('docDefaults',el))
        for name,rf in rfonts:
            count[name]+=1
            for att,expected in (('eastAsia',EAST),('ascii',LATIN),('hAnsi',LATIN),('cs',LATIN)):
                val=rf.get(Q(att))
                if val and not _target_equal(val,expected):problems.append({'location':name,'kind':att,'found':val,'expected':expected})
                theme=rf.get(Q(att+'Theme'))
                if theme:problems.append({'location':name,'kind':att+'Theme','found':theme,'expected':'no conflicting theme override'})
            if rf.get(Q('cstheme')):problems.append({'location':name,'kind':'cstheme','found':rf.get(Q('cstheme')),'expected':'no conflicting theme override'})
        found_east=any(_target_equal(rf.get(Q('eastAsia')),EAST) for _,rf in rfonts)
        found_latin=any(_target_equal(rf.get(Q('ascii')),LATIN) and _target_equal(rf.get(Q('hAnsi')),LATIN) for _,rf in rfonts)
    status='FAIL' if problems else ('PASS' if found_east and found_latin and has_visible else 'UNVERIFIED')
    return {'status':status,'required_cjk':EAST,'required_latin':LATIN,'font_declarations_inspected':sum(count.values()),'used_styles':len(used),'declaration_conflicts':problems[:60], 'note':'DOCX declarations only. Figure labels rasterized in images and Office font availability not proven.'}

def _pdf_font_match(font, language):
    base=font.split('+')[-1].casefold().replace(' ','').replace('-','')
    if language=='cjk':return 'simsun' in base and 'noto' not in base
    return any(s in base for s in ('timesnewroman','timesnewromanps'))

def _math_or_symbol_font(font):
    font=font.casefold().replace(' ','')
    return any(x in font for x in ('cambriamath','stix','freeserif','opensymbol','symbol'))

def _normalized_pdf_name(name):
    name=name.split('+')[-1].casefold()
    return ''.join(ch for ch in name if ch.isalnum())


def _font_resource_embed_state(doc,page):
    """Look at the actual PDF FontFile streams, not only a PDF font's advertised name."""
    result={}
    for entry in doc.get_page_fonts(page.number,full=True):
        xref, _ext, _type, base_name = entry[:4]
        normalized=_normalized_pdf_name(base_name)
        try:
            _,_,_,font_bytes=doc.extract_font(xref)
            embedded=bool(font_bytes)
        except (ValueError,RuntimeError):
            embedded=None
        result.setdefault(normalized,[]).append(embedded)
    return result


def inspect_pdf(path:Path)->dict:
    import fitz
    violations=Counter();byfont=Counter(); samples=[];images=0;recognized=0;embedded_confirmed=0;unknown=0
    with fitz.open(path) as pdf:
        pages=len(pdf)
        for page_idx,p in enumerate(pdf,1):
            images+=len(p.get_images(full=False))
            embedded_state=_font_resource_embed_state(pdf,p)
            for block in p.get_text('dict')['blocks']:
                for line in block.get('lines',[]):
                    for sp in line['spans']:
                        s=sp['text'];font=sp['font']
                        if not s.strip():continue
                        has_cjk=any('\u3400'<=c<='\u9fff' for c in s)
                        has_latin=any(('a'<=c.lower()<='z') or c.isdigit() for c in s)
                        category=[]
                        if has_cjk:category.append('cjk')
                        if has_latin and not (not has_cjk and _math_or_symbol_font(font)):category.append('latin')
                        norm=_normalized_pdf_name(font)
                        resources=embedded_state.get(norm)
                        for lang in category:
                            recognized+=1;byfont[(lang,font)]+=1
                            defect=None
                            if not _pdf_font_match(font,lang):defect='font_substitution_or_wrong_family'
                            elif resources is None:
                                unknown+=1;defect='pdf_font_resource_unverified'
                            elif not all(v is True for v in resources):
                                defect='font_not_proven_embedded' if None in resources else 'font_not_embedded'
                            else:embedded_confirmed+=1
                            if defect:
                                violations[(lang,font,defect)]+=1
                                if len(samples)<18:samples.append({'page':page_idx,'language':lang,'font':font,'issue':defect,'snippet':s[:80]})
    hard_violations=sum(count for (lang,font,reason),count in violations.items() if reason!='pdf_font_resource_unverified')
    if not recognized:status='UNVERIFIED'
    elif hard_violations:status='FAIL'
    else:status='UNVERIFIED' if unknown or images else 'PASS'
    return {'status':status,'pages':pages,'font_spans_checked':recognized,'embeddings_confirmed':embedded_confirmed,
            'unresolved_font_resources':unknown,'image_objects':images,
            'violations': [{'language':l,'font':f,'issue':kind,'spans':n} for ((l,f,kind),n) in violations.most_common()],
            'samples':samples,'note':'PDF text spans and embedded FontFile streams verified. Mathematical symbols may use dedicated fonts. Text inside raster images is not font-verifiable. No fonts are bundled.'}

def audit(docx:Path,pdf:Path|None=None)->dict:
    a=inspect_docx(docx)
    b=inspect_pdf(pdf) if pdf else {'status':'UNVERIFIED','reason':'No PDF supplied'}
    statuses=[a['status'],b['status']]
    status='FAIL' if 'FAIL' in statuses else ('PASS' if statuses==['PASS','PASS'] else 'UNVERIFIED')
    return {'status':status,'docx':a,'pdf':b,'strict_font_policy':{'chinese':'SimSun (宋体)','english_and_digits':'Times New Roman'}, 'note':'PASS requires both an eligible DOCX declaration and a proven compliant PDF; never distribute proprietary fonts.'}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('docx',type=Path)
    p.add_argument('--pdf',type=Path)
    p.add_argument('--out-json',type=Path)
    args=p.parse_args()
    result=audit(args.docx,args.pdf)
    if args.out_json:args.out_json.parent.mkdir(parents=True,exist_ok=True);args.out_json.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return {'PASS':0,'FAIL':1,'UNVERIFIED':2}[result['status']]
if __name__=='__main__':raise SystemExit(main())
