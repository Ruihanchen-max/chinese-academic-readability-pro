#!/usr/bin/env python3
"""Verify that figure-plan source file hashes still match; stdlib only.

This cannot prove a diagram's scientific semantics or visualize it.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path


def audit(plan: dict, source_root: Path) -> dict:
    errors: list[str] = []
    if not isinstance(plan, dict):
        raise ValueError("plan must be object")
    records = plan.get("source_records", [])
    if not isinstance(records, list):
        raise ValueError("source_records must be list")
    for record in records:
        if not isinstance(record, dict) or not isinstance(record.get("path"), str):
            errors.append("Bad source record")
            continue
        path = source_root / record["path"]
        if not path.is_file():
            errors.append(f"MISSING: {record['path']}")
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != record.get("sha256"):
            errors.append(f"CHANGED: {record['path']}")
    if plan.get("evidence_kind") in ("quantitative", "mixed") and not records:
        errors.append("NO_DATA_SOURCE: cannot validate actual numerical figure")
    return {"provenance_status": "FAIL" if errors else ("PASS" if records else "UNVERIFIED"), "verified_files": len(records), "errors": errors,
            "scientific_accuracy": "UNVERIFIED", "visual_quality": "UNVERIFIED"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("plan", type=Path)
    parser.add_argument("--source-root", type=Path, default=Path("."))
    a = parser.parse_args()
    try:
        result = audit(json.loads(a.plan.read_text(encoding="utf-8")), a.source_root)
    except (ValueError, OSError) as exc:
        result = {"provenance_status": "FAIL", "error": str(exc)}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 1 if result["provenance_status"] == "FAIL" else 0


if __name__ == "__main__":
    raise SystemExit(main())
