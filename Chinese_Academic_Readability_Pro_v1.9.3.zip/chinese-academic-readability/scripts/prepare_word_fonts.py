#!/usr/bin/env python3
"""Prepare an already font-normalized DOCX for native Microsoft Word saving.

Set the OOXML request to embed TrueType fonts (subject to availability and the
fonts' embedding license), but never embed or package any font bytes here.
No document content, styles, tables, or equations are changed by this utility.
The request has no power to make Word/PDF embed fonts that are not installed.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile
from lxml import etree

W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
Q=lambda x:f'{{{W}}}{x}'


def prepare_docx(source:Path,target:Path)->dict:
    source=Path(source).expanduser().resolve();target=Path(target).expanduser().resolve()
    if not source.is_file():return {'status':'FAIL','reason':'Input DOCX does not exist'}
    if source==target:return {'status':'FAIL','reason':'Refusing to overwrite input DOCX'}
    target.parent.mkdir(parents=True,exist_ok=True)
    changed=[]
    with ZipFile(source,'r') as check:
        if 'word/settings.xml' not in check.namelist():
            return {'status':'UNVERIFIED','reason':'This DOCX has no word/settings.xml; no changes were made'}
    with ZipFile(source,'r') as archive,ZipFile(target,'w') as output:
        for entry in archive.infolist():
            data=archive.read(entry.filename)
            if entry.filename=='word/settings.xml':
                root=etree.fromstring(data)
                for name in ('embedTrueTypeFonts','saveSubsetFonts'):
                    elem=root.find(Q(name))
                    if elem is None:
                        elem=etree.Element(Q(name))
                        root.insert(1 if name=='embedTrueTypeFonts' else 2,elem)
                    elem.set(Q('val'),'1')
                data=etree.tostring(root,encoding='UTF-8',xml_declaration=True,standalone=True)
                changed.append('word/settings.xml')
            output.writestr(entry,data)
    with ZipFile(source) as before,ZipFile(target) as after:
        changed_actual=[name for name in before.namelist() if before.read(name)!=after.read(name)]
        unchanged_all_but_settings=changed_actual in ([],['word/settings.xml'])
        assert unchanged_all_but_settings,changed_actual
        content_preserved=before.read('word/document.xml')==after.read('word/document.xml')
    return {'status':'PASS' if content_preserved else 'FAIL',
            'source':str(source),'prepared_docx':str(target),
            'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
            'prepared_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
            'changed_ooxml_parts':changed_actual,'research_document_xml_unchanged':content_preserved,
            'fonts_embedded':False,
            'note':'The settings only REQUEST Word to embed available/licensed TrueType fonts when saving; they do not embed fonts now or guarantee PDF embedding.'}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('docx',type=Path);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--out-json',type=Path)
    a=p.parse_args();r=prepare_docx(a.docx,a.out)
    if a.out_json:a.out_json.parent.mkdir(parents=True,exist_ok=True);a.out_json.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(r,ensure_ascii=False,indent=2));return {'PASS':0,'FAIL':1,'UNVERIFIED':2}[r['status']]
if __name__=='__main__':raise SystemExit(main())
