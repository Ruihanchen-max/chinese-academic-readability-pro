#!/usr/bin/env python3
"""Verify an installable Skill ZIP: safe paths, SHA-256, then optional tests.

Usage: python scripts/verify_release.py /path/to/Skill_v1.4.zip --run-tests
Only test archives received from trusted sources; --run-tests executes their code.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys
import tempfile
from zipfile import ZipFile, BadZipFile

ROOT_DIR = "chinese-academic-readability"
MANIFEST = "FILES_SHA256.txt"


def verify(zip_path: Path, run_tests: bool = False) -> dict:
    with ZipFile(zip_path) as archive:
        problems = []
        members = []
        for meta in archive.infolist():
            original = meta.filename
            path = PurePosixPath(original)
            if (not original or original.startswith("/") or "\\" in original or
                any(part in ("", ".", "..") for part in (original[:-1] if meta.is_dir() else original).split("/")) or
                not path.parts or path.parts[0] != ROOT_DIR):
                problems.append(f"Unsafe / unexpected ZIP path: {original}")
            if stat.S_IFMT(meta.external_attr >> 16) == stat.S_IFLNK:
                problems.append(f"ZIP symlink not allowed: {original}")
            if not meta.is_dir():
                members.append(original)
        if len(members) != len(set(members)):
            problems.append("Duplicate ZIP entries are not allowed")
        if problems:
            raise ValueError("; ".join(problems))
        corrupt = archive.testzip()
        if corrupt:
            raise ValueError(f"ZIP CRC failed for {corrupt}")
        with tempfile.TemporaryDirectory() as tmp:
            archive.extractall(tmp)
            root = Path(tmp) / ROOT_DIR
            manifest_path = root / MANIFEST
            if not manifest_path.is_file():
                raise ValueError("Missing SHA-256 manifest")
            expected = {}
            for row in manifest_path.read_text(encoding="utf-8").splitlines():
                if not row.strip():
                    continue
                digest, sep, relative = row.partition("  ")
                if not sep or len(digest) != 64 or not all(ch in "0123456789abcdef" for ch in digest):
                    raise ValueError(f"Malformed manifest entry: {row[:100]}")
                path = PurePosixPath(relative)
                if not path.parts or relative.startswith("/") or ".." in path.parts or "\\" in relative:
                    raise ValueError(f"Unsafe manifest path: {relative}")
                if relative in expected:
                    raise ValueError(f"Duplicate manifest path: {relative}")
                expected[relative] = digest
            actual_files = {
                str(p.relative_to(root)).replace(os.sep, "/")
                for p in root.rglob("*") if p.is_file() and p.name != MANIFEST
            }
            if actual_files != set(expected):
                raise ValueError(f"Manifest/file mismatch: extra={sorted(actual_files-set(expected))}, missing={sorted(set(expected)-actual_files)}")
            bad_hashes = []
            for name, digest in expected.items():
                found = hashlib.sha256((root / name).read_bytes()).hexdigest()
                if found != digest:
                    bad_hashes.append(name)
            if bad_hashes:
                raise ValueError(f"SHA-256 mismatch: {bad_hashes}")
            count = None
            if run_tests:
                validation = subprocess.run([sys.executable, "scripts/validate_skill.py", "."], cwd=root,
                                            text=True, capture_output=True)
                if validation.returncode:
                    raise ValueError(f"Structural validation failure: {validation.stdout} {validation.stderr}")
                unit = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-q"],
                                      cwd=root, text=True, capture_output=True)
                if unit.returncode:
                    raise ValueError(f"Unit tests failed: {unit.stdout} {unit.stderr}")
                import re
                m = re.search(r"Ran\s+(\d+)\s+tests", unit.stderr)
                count = int(m.group(1)) if m else None
            return {"status": "PASS", "zip": str(zip_path), "sha256_files": len(expected),
                    "zip_files": len(members), "tests_run": count,
                    "note": "File and deterministic program verification only; not a human paper readability trial."}


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("zip", type=Path)
    p.add_argument("--run-tests", action="store_true")
    args = p.parse_args()
    try:
        result = verify(args.zip, args.run_tests)
    except (OSError, ValueError, BadZipFile) as ex:
        print(json.dumps({"status": "FAIL", "error": str(ex)}, ensure_ascii=False, indent=2))
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
