"""Lightweight document navigation hints (not a visual or scientific-validity audit).

Usage: python scripts/navigation_audit.py draft.docx --out-json navigation_audit.json
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re
from typing import Any

from docx import Document

RQ_RE=re.compile(r'(?<![A-Z0-9])RQ\d+(?!\d)',re.I)
H_RE=re.compile(r'(?<![A-Z0-9])H[1-9]\d*(?!\d)',re.I)
CAP_RE=re.compile(r'^图\s*(\d+)\s*(.*)$')
REF_RE=re.compile(r'图\s*(\d+)')
KEY_THRESHOLDS={
    'wear_10h': re.compile(r'(?:至少|≥)\s*10\s*小时'),
    'wear_80pct': re.compile(r'(?:至少|达到|≥)\s*80\s*%'),
    'baseline_5days': re.compile(r'至少\s*5\s*个?有效日'),
    'outcome_10days': re.compile(r'至少\s*10\s*个?有效日'),
    'ema_16answers': re.compile(r'至少\s*16\s*条?有效'),
}


def audit(path: str | Path) -> dict[str,Any]:
    p=Path(path)
    if p.suffix.lower()!='.docx':raise ValueError('Only DOCX is supported')
    doc=Document(p)
    paragraphs=[(i,p) for i,p in enumerate(doc.paragraphs) if p.text.strip() and not p.style.name.startswith('TOC')]
    headings=[];rq=[];hyp=[];captions=[];references=[];warnings=[];thresholds=[]
    for i,par in paragraphs:
        text=par.text.strip()
        if par.style.name.startswith('Heading'):
            headings.append({'paragraph':i,'level':par.style.name,'text':text})
        m=CAP_RE.match(text)
        if m:
            captions.append({'paragraph':i,'number':int(m.group(1)),'text':text})
        else:
            for r in REF_RE.finditer(text):
                references.append({'paragraph':i,'number':int(r.group(1))})
        rqs=RQ_RE.findall(text);hs=H_RE.findall(text)
        if rqs:rq.append({'paragraph':i,'identifiers':rqs,'characters':len(text)})
        if hs:hyp.append({'paragraph':i,'identifiers':hs,'characters':len(text)})
        if len(set(rqs))>=2:
            warnings.append({'code':'RQ_MULTIPLE_IN_ONE_PARAGRAPH','paragraph':i,'detail':'Consider separate lines if this is a proposal; preserve wording.'})
        if len(set(hs))>=2:
            warnings.append({'code':'H_MULTIPLE_IN_ONE_PARAGRAPH','paragraph':i,'detail':'Consider separate lines; preserve exploratory status.'})
        if re.search(r'(?<!\w)S\s+\*(?!\w)',text):
            warnings.append({'code':'S_STAR_TEXT_SPACING','paragraph':i,'detail':'Inspect actual PDF glyph; extracted text alone is insufficient.'})
        for code,pat in KEY_THRESHOLDS.items():
            if pat.search(text):
                marker=pat.search(text).group(0)
                # This is only a surface indicator: runs can split words and PDF can still hide them.
                emphasized=any(run.bold and marker.replace(' ','') in run.text.replace(' ','') for run in par.runs)
                thresholds.append({'code':code,'paragraph':i,'emphasized_in_single_run':bool(emphasized)})
                if not emphasized:
                    warnings.append({'code':'THRESHOLD_FINDABILITY_REVIEW','paragraph':i,'detail':code+' exists in prose; decide if a single bold anchor helps.'})
    nums=[x['number'] for x in captions]
    if len(nums)!=len(set(nums)):
        warnings.append({'code':'DUPLICATE_FIGURE_CAPTION','detail':nums})
    if nums and nums!=list(range(1,len(nums)+1)):
        warnings.append({'code':'FIGURE_CAPTION_NUMBERING_REVIEW','detail':nums})
    for r in references:
        if r['number'] not in nums:
            warnings.append({'code':'FIGURE_REFERENCE_MISSING_CAPTION','paragraph':r['paragraph'],'detail':r['number']})
    for tab_i,table in enumerate(doc.tables):
        for row_i,row in enumerate(table.rows):
            for col_i,cell in enumerate(row.cells):
                if re.search(r'由\s*选择',cell.text) and not re.search(r'由\s*(?:[^。；，]*?)(?:A|B|C|S\*|规则|程序)\s*选择',cell.text):
                    warnings.append({'code':'TABLE_AMBIGUOUS_WRAP','table':tab_i,'row':row_i,'column':col_i,
                                     'detail':'Verify that the selector is named in the same cell.'})
    return {
        'status':'HEURISTIC_ONLY_NOT_VISUAL_QA',
        'source':str(p),
        'paragraph_count':len(paragraphs),
        'heading_count':len(headings),
        'headings':headings,
        'rq_anchors':rq,'hypothesis_anchors':hyp,
        'figure_captions':captions,
        'figure_references':references,
        'inline_picture_count':len(doc.inline_shapes),
        'key_thresholds':thresholds,
        'warnings':warnings,
        'is_independent_reader_evidence':False,
        'is_page_visual_validation':False,
    }


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('input_docx')
    ap.add_argument('--out-json')
    args=ap.parse_args()
    result=audit(args.input_docx)
    value=json.dumps(result,ensure_ascii=False,indent=2)
    if args.out_json:Path(args.out_json).write_text(value,encoding='utf-8')
    print(json.dumps({'status':result['status'],'warnings':len(result['warnings']),
                      'figure_captions':[v['number'] for v in result['figure_captions']],
                      'key_thresholds':len(result['key_thresholds'])},ensure_ascii=False))

if __name__=='__main__':main()
