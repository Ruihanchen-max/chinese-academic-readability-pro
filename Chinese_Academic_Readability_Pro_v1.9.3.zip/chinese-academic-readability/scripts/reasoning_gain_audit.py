#!/usr/bin/env python3
"""Screen whether a revision's added text has a documented reasoning purpose.

Important: evaluates author/agent-supplied annotations and length, NOT semantic
truth, academic quality, or real reader comprehension. The 15% trigger is a
review threshold, never an automatic maximum length or deletion mandate.

Usage:
  python scripts/reasoning_gain_audit.py evals/example_reasoning_gain_v161.json
  python scripts/reasoning_gain_audit.py input.json --out-json output.json
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

SUPPORTED_TYPES = {"key_reasoning_bridge", "clarify_comparison", "design_justification", "necessary_boundary", "optional_background"}
SUPPORTED_PRIORITIES = {"CRITICAL", "IMPORTANT", "OPTIONAL"}
SUPPORTED_EVIDENCE = {"source_grounded", "explicit_hypothesis", "not_verified"}
SUPPORTED_ACTIONS = {"replace", "add", "retain"}
SPACE = re.compile(r"\s+")


def _text(x: object) -> str:
    return x.strip() if isinstance(x, str) else ""


def _length(s: str) -> int:
    # Use the SAME non-whitespace character metric for both versions.
    # A language-dependent fallback can misreport shortening as expansion.
    return len(SPACE.sub("", s))


def audit(data: dict) -> dict:
    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    baseline = _text(data.get("baseline_text"))
    revision = _text(data.get("revision_text"))
    if not baseline or not revision:
        raise ValueError("baseline_text and revision_text are required nonempty strings")
    threshold = data.get("review_threshold", 0.15)
    if isinstance(threshold, bool) or not isinstance(threshold, (int, float)) or not 0 < threshold <= 1:
        raise ValueError("review_threshold must be a number >0 and <=1")
    gains = data.get("gains", [])
    if not isinstance(gains, list):
        raise ValueError("gains must be a list")
    locks = data.get("locks", {})
    if not isinstance(locks, dict):
        raise ValueError("locks must be an object")
    for k in ("fact", "comparison", "design"):
        if k in locks and locks[k] is not None and type(locks[k]) is not bool:
            raise ValueError(f"locks.{k} must be true, false or null")
    findings = []

    def flag(code: str, level: str, explanation: str) -> None:
        findings.append({"code": code, "level": level, "explanation": explanation})

    for k in ("fact", "comparison", "design"):
        if locks.get(k) is False:
            flag("LOCK_BREACH_" + k.upper(), "BLOCK", f"{k} lock reported as broken; stop and reconcile scientific meaning")
        elif locks.get(k) is not True:
            flag("LOCK_NOT_VERIFIED_" + k.upper(), "REVIEW", f"{k} lock has not been independently checked")

    seen = set()
    strong_gains = []
    for i, g in enumerate(gains):
        if not isinstance(g, dict):
            raise ValueError("gains entries must be objects")
        gid = _text(g.get("id"))
        if not gid or gid in seen:
            raise ValueError("Each gain needs a unique nonempty id")
        seen.add(gid)
        for field, allowed in (("type", SUPPORTED_TYPES), ("priority", SUPPORTED_PRIORITIES),
                               ("evidence_status", SUPPORTED_EVIDENCE), ("action", SUPPORTED_ACTIONS)):
            if g.get(field) not in allowed:
                raise ValueError(f"gain {gid}: invalid {field}")
        if not _text(g.get("anchor")) or not _text(g.get("why_needed")):
            flag("UNSUPPORTED_GAIN_LEDGER", "REVIEW", f"{gid}: no text/source anchor or necessity explanation")
        if g["evidence_status"] == "not_verified":
            flag("UNVERIFIED_NEW_EXPLANATION", "REVIEW", f"{gid}: claim needs a source or explicit hypothesis label")
        if g["priority"] == "OPTIONAL" or g["type"] == "optional_background":
            flag("OPTIONAL_ADDITION", "REVIEW", f"{gid}: optional explanation should ordinarily be removed or deferred")
        elif (g["action"] != "retain" and g["evidence_status"] != "not_verified"
              and _text(g.get("anchor")) and _text(g.get("why_needed"))):
            strong_gains.append(g)

    b, r = _length(baseline), _length(revision)
    change = (r - b) / b
    same = baseline == revision
    if not same and change > threshold:
        flag("EXPANSION_OVER_REVIEW_THRESHOLD", "REVIEW",
             f"Text increased {change:.1%}; requires review of added reasoning, not automatic trimming")
        if not strong_gains:
            flag("NO_NECESSARY_GAIN_FOR_EXPANSION", "BLOCK",
                 "The large expansion has no anchored CRITICAL/IMPORTANT reasoning gain")
        elif all(x["action"] == "add" for x in strong_gains):
            flag("APPEND_WITHOUT_REPLACEMENT", "REVIEW",
                 "Try replacing repetitive text instead of appending more prose")
    # Even shorter revisions require human factual checks; these flags do not
    # certify that omitted sentences are safe to delete.
    if same:
        flag("KEEP_UNCHANGED", "INFO", "No change; this can be a good editorial decision")
    if not same and not gains:
        flag("NO_REASONING_LEDGER", "REVIEW", "Unexplained edits require checking against the original")

    status = ("BLOCK_AND_REVISE" if any(f["level"] == "BLOCK" for f in findings)
              else "HUMAN_REVIEW_REQUIRED" if any(f["level"] == "REVIEW" for f in findings)
              else "SCREEN_CLEAR_NOT_QUALITY_PROOF")
    return {
        "status": status,
        "baseline_chars": b,
        "revision_chars": r,
        "change_ratio": round(change, 5),
        "review_threshold": threshold,
        "threshold_triggered": change > threshold,
        "findings": findings,
        "independent_reader_effect_tested": False,
        "fact_truth_independently_verified": False,
        "scope": "Length and author/agent annotation checks only. No automated judgment of reasoning quality or meaning.",
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("input", type=Path, help="JSON revision ledger")
    ap.add_argument("--out-json", type=Path)
    args = ap.parse_args()
    try:
        data = json.loads(args.input.read_text(encoding="utf-8"))
        result = audit(data)
        output = json.dumps(result, ensure_ascii=False, indent=2)
        if args.out_json:
            args.out_json.parent.mkdir(parents=True, exist_ok=True)
            args.out_json.write_text(output + "\n", encoding="utf-8")
        print(output)
        return 2 if result["status"] == "BLOCK_AND_REVISE" else 0
    except (OSError, ValueError, TypeError) as exc:
        print(json.dumps({"status": "INVALID_INPUT", "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
