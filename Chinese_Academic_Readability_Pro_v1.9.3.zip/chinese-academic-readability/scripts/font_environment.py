#!/usr/bin/env python3
"""Preflight genuine local SimSun/Times New Roman before a *native* PDF export.

This script reads local font metadata; it never installs, copies, embeds or distributes
licensed font files. System font aliases / fontconfig substitutions are NOT matches.
PDF verification is a separate mandatory step after exporting from Word.
"""
from __future__ import annotations
import argparse
import json
import os
import platform
import shutil
import subprocess
from pathlib import Path

REQUIRED=('SimSun','Times New Roman')


def _family_variants(s: str) -> set[str]:
    return {x.strip().casefold().replace(' ', '') for x in s.split(',') if x.strip()}


def _fontconfig_fonts() -> list[tuple[str,Path]]:
    fc = shutil.which('fc-list')
    if not fc: return []
    try:
        result=subprocess.run([fc,'--format','%{family}\t%{file}\n'],capture_output=True,text=True,timeout=20,check=True)
    except (subprocess.TimeoutExpired, OSError, subprocess.CalledProcessError): return []
    found=[]
    for line in result.stdout.splitlines():
        if '\t' not in line:continue
        fam,path=line.split('\t',1)
        if path.strip():found.append((fam,Path(path.strip())))
    return found


def _known_font_paths() -> list[Path]:
    home=Path.home()
    entries=[]
    if platform.system() == 'Darwin':
        bases=[home/'Library/Fonts',Path('/Library/Fonts'),Path('/System/Library/Fonts')]
    elif platform.system()=='Windows':
        bases=[Path(os.environ.get('WINDIR', 'C:/Windows'))/'Fonts',home/'AppData/Local/Microsoft/Windows/Fonts']
    else:
        bases=[home/'.local/share/fonts',home/'.fonts',Path('/usr/local/share/fonts'),Path('/usr/share/fonts')]
    terms=('simsun','sim sun','times new roman','timesnewroman','timesnr','times')
    for base in bases:
        if not base.is_dir(): continue
        for root,_,names in os.walk(base):
            for name in names:
                if any(t in name.casefold() for t in terms) and name.lower().endswith(('.ttf','.ttc','.otf','.otc')):
                    entries.append(Path(root)/name)
    return entries


def _font_names_from_file(path:Path) -> set[str]:
    try:
        from fontTools.ttLib import TTFont, TTCollection
    except ImportError:
        return set()
    try:
        fonts=TTCollection(path,lazy=True).fonts if path.suffix.lower() in ('.ttc','.otc') else [TTFont(path,lazy=True)]
        names=set()
        for font in fonts:
            try:
                for rec in font['name'].names:
                    if rec.nameID in (1, 16):
                        try:names.add(rec.toUnicode().strip())
                        except (UnicodeError,ValueError):pass
            finally:font.close()
        return names
    except Exception:return set()


def inspect_environment(font_files: list[str] | None = None)->dict:
    """Treat fc-list family names as candidates but confirm every match in font metadata."""
    families={k: [] for k in REQUIRED}
    candidates={}
    for family,path in _fontconfig_fonts():
        variants=_family_variants(family)
        for required in REQUIRED:
            if required.casefold().replace(' ','') in variants:
                candidates[str(path)]=path
    for path in _known_font_paths():candidates[str(path)]=path
    for path in font_files or []:
        p=Path(path).expanduser(); candidates[str(p)]=p
    for p in sorted(candidates.values(),key=str):
        if not p.is_file():continue
        actual={n.casefold().replace(' ','') for n in _font_names_from_file(p)}
        for family in REQUIRED:
            if family.casefold().replace(' ','') in actual:
                families[family].append({'path':str(p),'name_verified_from_font_metadata':True})
    missing=[f for f in REQUIRED if not families[f]]
    return {'status':'PASS' if not missing else 'UNVERIFIED',
            'platform':platform.system(),'required_font_families':list(REQUIRED),
            'installed_genuine_fonts':families,'missing_font_families':missing,
            'note':'Local font metadata only; does not prove Word can load fonts or PDF embeds them. Never package font files.'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--font-file',action='append',default=[],help='Inspect an already licensed/installed font at this local path; no file is copied')
    p.add_argument('--out-json',type=Path)
    a=p.parse_args()
    r=inspect_environment(a.font_file)
    if a.out_json:a.out_json.parent.mkdir(parents=True,exist_ok=True);a.out_json.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(r,ensure_ascii=False,indent=2))
    return 0 if r['status']=='PASS' else 2
if __name__=='__main__':raise SystemExit(main())
