# v1.9.1 快速调用：段落太多、论述过碎

```text
使用 chinese-academic-readability v1.9.1 的 paragraph-flow 模式，只调整段落组织和相邻段落的自然衔接。
先判断各段承担的论证任务；同一问题的事实、证据和解释若被机械拆段，可合并并去重；
真正不同的研究问题、RQ/H、阶段、估计对象及必要科学限定应保持分开。
不按固定比例删段，不通过加连接词制造流畅，也不把全部内容堆成长段。
核对事实、比较、引文和必要限定。原本清楚则 KEEP；只给实质调整及修改后正文。
[正文]
```

只读候选筛查：`python scripts/paragraph_flow_audit.py manuscript.docx --out-json flow_candidates.json`。输出 `REVIEW_ONLY`，不是自动合并或可读性得分。若最终交付 DOCX/PDF，仍需独立 `artifact-qa`。

---

## 读者导航与必要配图（v1.8）

请使用 `reader-navigation` 模式，先识别最重要的研究问题、设计比较和质量标准，再对正文做最小必要的小标题/分行/局部强调。仅当图能揭示现有文字或图表不易看到的关系时增设一张示意图；图内不制造实测数据。输出 DOCX/PDF 时逐页视觉检查并核对目录、图号、表号、字体。

## v1.7 新增：减少防御性写作而不削弱科研审慎

```text
使用 chinese-academic-readability v1.7 审查下面的中文学术段落。先用一句话明确本段有证据支持的核心判断。逐项区分必要科学限定、真实可能误读的澄清、无信息增益的预设反驳。仅删除或重写第三类；保留决定样本、比较、时间、结果和因果强度的限定。已经清楚的段落原样保留。输出修订正文以及最多三处关键改动与需要核实的科学边界，不要附加没有意义的防御性尾句。
[正文与必要上下文]
```

---

# v1.6.1：思想深度增加，但不扩写成实施协议

```text
使用 chinese-academic-readability v1.6.1 的 intellectual-depth + reasoning-gain 模式。
先判断这段是否缺关键推理；已有清楚表达时 KEEP 或 SHORTEN。
对于核心学术命题，优先替换原有冗余句补上唯一必要的解释，不要堆叠机制、限定和技术情景。
若相对清晰基准稿扩写超过约15%，说明新增的哪一条推理不可或缺；
仍不能证明必要时删除扩写。全过程保持 FACT/COMPARISON/DESIGN LOCK。
方法中的通知负担只讲测量策略、规模、负担评价和试运行，不恢复极端通知计算。
```

只读辅助：`python scripts/reasoning_gain_audit.py evals/example_reasoning_gain_v161.json`

---

# v1.4.2 中文调用与验证指南

## ① 一页论文先诊断（不修改）

```text
使用 chinese-academic-readability 的 diagnose 模式审查以下中文论文节选。
不要直接改正文。按原文锚点指出最严重的 3–5 个阅读障碍：
(1) 中心主张是否具体；(2) 来源与论据；(3) 中间推理是否缺失；
(4) 和前后段的实际关系；(5) 具体概念、比较对象与统计限定。
指出哪些句子本来清楚应当保留。不要凭空补文献。
[正文]
```

## ② 实证论文引言深度重构（建议优先使用）

```text
使用 chinese-academic-readability v1.4 的 rebuild 模式。
稿件：中文体育科学实证论文引言。目标：让读者不依赖写作说明，
也能准确知道研究要解决什么、现有证据还缺什么、本文数据能回答什么。
先建立 FACT LOCK，列出 P1-Pn 的主张—证据—推理—段间关系；
只修复确有问题的段落，必要时合并冗余背景。给出完整修订稿，
禁止新增未经核实引用、实验结果或因果机制。最后比较前后事实。
[正文、方法摘要、现有引文]
```

## ③ 讨论部分：严格保护统计和结论强度

```text
使用 chinese-academic-readability 修改讨论。保持研究设计、样本、
变量、系数、方向、P 值、CI、子群限定和原有引文的正确归属。
逐段指出观察结果、作者解释、机制假设和建议；不能把关联写成因果。
如果原稿自己夸大了因果，请明确标注“推断纠错”，进行有证据的弱化。
避免“具有重要意义”“复杂机制”等空泛重复，保留必要的谨慎限定。
输出完整正文以及需要作者核实的事实清单。
[方法、结果、讨论]
```

## ④ 已经清楚的段落：最小必要修改

```text
使用 chinese-academic-readability polish 模式处理以下段落。
先判断是否已经准确、自然且论证可追踪；如果是，原文原样保留。
不要为了优化而新增连接词、无意义小标题或抽象名词。
[正文]
```

## ⑤ 真正的独立读者测试

```text
使用 chinese-academic-readability 的 reader test。
若可以调用全新、与修改过程隔离的代理，只给它修订后正文和
READER_SCORECARD.md 的问题；不发原稿、修改记录或预设答案。
回答是否能准确复述主张、证据和结论上限。若无法隔离，必须标为
“单模型模拟冷读”，不得称独立盲审。
```

## ⑥ A/B/C 三组对照，避免模型自评偏差

准备完全相同的原稿与研究证据：A 普通润色，B 强化 Prompt 但不用 Skill，C 启用 Skill；三组都采用相同模型设置。先由学科读者建立原稿参照答案，再运行盲化脚本：

```bash
python scripts/prepare_blind_eval.py abc_input.json blind_out --seed 20261122
```

只发送 **`blind_out/reviewer_pack.md`** 给至少两位不参与改写的评审。私钥默认保存在用户私有状态目录，不在 `blind_out` 中；绝对不要发送其所在目录。可以用 `--key-dir` 指向其他独立私有目录。使用 `evals/READER_SCORECARD.md` 填表，报告事实错误、理解正确率和评审分歧，**不把短句率或“AI 率”当可读性**。

## ⑦ 本地规则检查（辅助，不是最后的审稿结论）

```bash
python scripts/audit_text.py my_draft.md --format json
python scripts/compare_versions.py original.md revised.md --format markdown
```

出现提示：查看原文，决定是否真的需要修正；无提示：仍需按 FACT LOCK 和读者问题逐项检查。

## ⑧ 目标期刊风格适配

```text
以我提供的《体育科学》《上海体育大学学报》近年正式发表论文为参考，
按实证/理论/综述文章类型，提取其研究问题收束、段落递进、
证据与讨论安排等“篇章动作”。不得复制原文句子；没有正式样本时
只给通用中文体育学术表达建议，不宣称已学习某刊文风。
[目标稿和参考论文]
```

## ⑨ v1.4 必检：数字与组别绑定

```bash
python scripts/compare_versions.py original.md revised.md --format json
```

`numbers_changed`：实际数值集合发生变化；`number_binding_changed`：同组别/指标的数值归属变化（例如两组均值互换）；`direction_binding_changed`：相同变量关系的正/负方向互换。即使无警告仍需原表核查，复杂句的自动绑定存在漏检/误报。


## 7. 真实稿件中“不同”绝不能自动改成“更好”

```text
使用 chinese-academic-readability v1.4 对这段中文体育科研论文精修。
启用 COMPARISON LOCK：分别记录原研究比较目标是“差异/优效/等效/非劣”中的哪一种、
研究是否已完成、比较对象与指标是什么。不要把“区别于基础策略A”改写成“优于基础策略A”，
也不要把“既往研究结果”写成“本研究已证明”。原文清楚时保留，不为了优化而扩写。
先输出正文，再报告最多3处实质调整，最后给出需要核对的事实风险。
[原稿、方法与结果证据]
```

## 8. 单次接触的独立读者理解测试

```bash
python scripts/prepare_reader_study.py evals/example_reader_study_v13.json \
  ./public_readers --reviewers 12 --private-dir ./private_keys
```

该命令只建立 **12 份匿名读者材料**，每位读者每段只接触一个版本；它不会自动产生独立真人结果。公共文件只能逐份发给获得授权的读者，私钥目录绝不能分享给读者。旧 `prepare_blind_eval.py` 是三个版本并列比较，不适合独立理解测试。

## 9. 检查“越改越长”

```bash
python scripts/edit_footprint.py before.md after.md --format json
```

其输出没有可读性成绩。长度膨胀与改写幅度较大时，回到原稿核查是否新增了未经证实的研究论点；并不是要求学术论文永远写得更短。


## v1.4 最终 Word/PDF 成稿验收

将审定稿 DOCX 与真实导出 PDF 送入 `artifact-qa`，不要触动 `polish` 的研究正文。

```text
请使用 chinese-academic-readability v1.4 的 artifact-qa 模式：冻结原始 DOCX，分别记录真实导出引擎与版本，将每页 PDF 渲染为 PNG，对照 Word 核查中文缺字、表格、公式上下标、目录和页码。所有页面必须完成视觉签核，不存在高风险问题才可 PASS；没完成标 UNVERIFIED；发现丢字标 FAIL。若需改版面，禁止改研究数据/结论，并进行重新完整渲染与回归。
```

命令：`python scripts/submission_gate.py 论文.docx --out-dir qa --engine libreoffice`。本机没有 Word 时不以 LibreOffice 结果冒充 Word 结果。


## v1.4.1 字体与实际 PDF 验证

中文固定宋体（SimSun），英文及数字 Times New Roman。需执行 `python scripts/font_audit.py report.docx --pdf report.pdf` 以及 `python scripts/submission_gate.py report.docx --out-dir qa --strict-simsun-times`。如果导出 PDF 使用 Noto Serif CJK 或 Liberation Serif，虽然看起来可读，也不能算严格字体门禁 PASS；应在具有正规字库的 Word 环境重新导出，再验证。

## v1.4.2 — 在自己 Mac/Windows 的 Word 导出真正的宋体与 Times New Roman PDF

1. 使用 `python scripts/font_environment.py` 检查本地是否有正版 `SimSun` 和 `Times New Roman`。缺少就按系统许可合法安装；`Songti SC` 并不等于 `SimSun`。
2. 可执行 `python scripts/prepare_word_fonts.py my.docx --out word_ready.docx` 请求 Word 保存时嵌入已授权字体，**不把字体装入 DOCX**，不改变研究文字。
3. 用安装了两种目标字体的 Microsoft Word 打开 `word_ready.docx` 并导出打印品质 PDF。不要再经 LibreOffice 重导；可以选用可选 `native_word_export.py` 自动化，但 macOS 需要本机实测，失败则手动保存。
4. 用 `python scripts/submission_gate.py word_ready.docx --existing-pdf word_ready.pdf --out-dir qa_native --strict-simsun-times` 验收原 PDF。检查 `font_audit.json`、`submission_gate.json`，全页视觉审查并签核。只有真正通过全部检查才算正式可提交 PDF。
5. 如果没有正版字体，仅交付待 Word 导出的 DOCX 和标记了替代字体的预览，PDF 原生字体状态仍为 FAIL/UNVERIFIED。

## v1.5：初步开题写作深度控制（优先推荐）

```text
使用 chinese-academic-readability v1.5 的 depth-control 模式，
将我提供的博士课程初步开题稿从技术实施协议式写法调整为适合课程教师审阅的学术报告。
先建立 DEPTH LOCK（对象：博士课程教师；阶段：尚未开展正式试验），
再使用 FACT LOCK / COMPARISON LOCK 锁定研究问题、研究对象、阶段关系、
核心随机比较、主要结局与时间窗。
把最小有意义的命题分为 A 必写科学骨架、B 简述研究原则、C 可概括或删减的执行细则。
只在用户允许的范围做内容删改，不要硬性限制页数；不用缩字号来实现压缩。
给出修改后完整正文、关键删改说明、课程教师与方法审查双视角结论。
无法调用隔离审读时请明确注明“非独立审读”。
若输出 Word/PDF，请另执行 artifact-qa 并记录字体与逐页验收状态。
[原稿与明确的核心研究设计]
```

**不要误用**：若文稿是伦理试验实施方案、正式注册文件或需要可复现方法的投稿论文，不要为了减少工程感按课程开题规则删除必要的统计、过程和安全细节。

只读预筛：`python scripts/depth_control_audit.py input.docx --profile course-preproposal --out-json report.json`。此工具输出候选审查位置，不提供学术质量分或实际真人可读性成绩。


## v1.6：文章思想浅、论证浮于表面，同时担心“还不够全面”

```text
使用 chinese-academic-readability v1.6 的 intellectual-depth 模式。
这篇稿件不需要增加更多技术细则，而要提高思想与论证深度。
先识别最重要的1—3个学术命题，对每个命题检查：具体问题、来源证据、
关键推理桥梁、最相关的竞争解释、研究设计能/不能检验的内容。
将新增内容按 CRITICAL / IMPORTANT / OPTIONAL 分级：重点深化前两者，
不要为追求全面穷举异常情形、机制猜想或无来源文献。
当核心论证成立、关键证据边界已清楚且没有未处理的核心风险时停止扩写。
允许清楚且准确的段落不修改。保持原始数据、组间比较、研究阶段和结论强度。
最后交付完整修订稿、最重要的改变与明确的停止理由。
[原稿、已核实的文献/设计信息、文章类型]
```

**与 v1.5 的区别**：`depth-control` 决定针对特定文体要写到多细；`intellectual-depth` 决定对核心学术判断有没有解释清楚。可以先 `depth-control` 再 `intellectual-depth`，但**不要求把后者用在每段、也不要求必须增加字数**。

可选人工结构化预审：

```bash
python scripts/intellectual_depth_audit.py evals/example_intellectual_depth_v16.json --out-json review.json
```

此工具不会自行读取论文、决定论文思想深度或向文章补写证据；只有读者/Agent 根据原文填好论证账本后，才能对账本进行完整性和优先级检查。工程门禁通过不等于独立读者盲评通过。


## v1.8.1：优先使用 PPT 原生可编辑图元 → SVG 制作原创科研图示

```text
使用 chinese-academic-readability 的 reader-navigation 模式。先判断是否需要新增学术示意图；
对于研究流程图、概念关系图、机制框架图及组间比较示意图，默认用 PowerPoint 原生形状、
可编辑文字与连接线绘制，先保存 PPTX 源文件，再导出真正矢量 SVG，论文中使用 SVG。
同时交付 PPTX + SVG（必要时另附 PNG 兼容预览），不得把 PNG/JPG 包进 SVG 冒充矢量。
图中的变量、因果箭头、样本数、时间窗和结论必须逐项对照原稿。
真实数据图使用真实数据生成的矢量图；原论文配图与照片保留来源与使用许可，不强行用 PPT 描摹。
最后验证 SVG 字体/裁切以及 DOCX→PDF 的全部页面；无法验证时明确标记 UNVERIFIED。
```

具体见 [PPT 原生 SVG 制图工作流](references/ppt-native-svg-workflow.md)。


## v1.9 科研论文配图/ICML图示

> 使用 chinese-academic-readability v1.9 的 scientific-figures 模式。请先读我的论文方法、实验设计与真实输出，确定此图唯一要说明的关系、已有依据和图号，再在方法总览/机制放大/评测管线/数据趋势/多面板中选择最合适构图。原创方法示意用可编辑PPTX形状制作并导出SVG，数据/消融图必须由真实数据与Python绘制。保留来源、绘图代码、原生PPTX和SVG，检查最终PDF的可读性、字体、箭头与数据一致性。没有结果数据时只能规划图，不允许生成虚构结果图。

仅测试路由：`python scripts/scientific_figure_plan.py evals/figure_contract_schematic_example.json --out /tmp/figure_plan.json`。若有实际数值图必须提供CSV/JSON/分析输出路径，再进行来源哈希校验：`python scripts/figure_provenance_audit.py /tmp/figure_plan.json --source-root .`。

具备真实CSV时可使用：`python scripts/plot_verified_csv.py real_results.csv --x epoch --y accuracy --kind line --out-prefix figures/accuracy`。误差线需手动提供`--lower/--upper/--interval-label`。


## v1.9.2 科研图内文字精简

调用：**“请按 figure-text-economy 优化可编辑 PPTX 科研示意图，图内仅保留对象/关系/变量标签，将‘核心区别’‘不代表结果’及长句说明移到随图出现的图注，不删事实身份，不改真实结果图的坐标轴/单位/图例。保留 PPTX 和重新导出的 SVG，并检查最终 PDF。”**

可运行 `python scripts/figure_text_economy_audit.py figure.pptx --out-json review.json` 初筛潜在元话语；审查结果只能是人工复核线索。


## v1.9.3 叙述节奏与具体图示（按需）

```text
使用 chinese-academic-readability v1.9.3 改善我的博士课程初步开题。
优先让承担同一论证任务的相邻段落自然连贯，但不要规定目标段数；
第七章这种综合章节优先使用自然段，非必要不增加二级小标题。
精修空泛、防御性及重复句时保留核心比较与方法学边界。
如需要研究机制图，优先根据我实际给出的日程、规则与变量绘制可验证的具体过程；
若示例条件不足，不能编造。示意图保留原生PPTX和真SVG，
图内只留时间、窗口、策略等必要标签，图注说明例示前提与未完成研究性质。
最后进行事实保真、图表交叉引用及DOCX/PDF逐页检查。
```

### 需要核查科研示意图的条件性例子时

```bash
python scripts/timing_figure_case_check.py assets/figure_case_timing/figure_case.json
python scripts/figure_source_audit.py assets/figure_case_timing/figure_01.pptx assets/figure_case_timing/figure_01.svg
python scripts/figure_text_economy_audit.py assets/figure_case_timing/figure_01.pptx
```

脚本只验证时间先后及文件结构的已知约束。返回 `REVIEW_ONLY` 是正常结果，并不代表人的读图理解、策略B/C科学正确性、字体或正式论文配图通过。
