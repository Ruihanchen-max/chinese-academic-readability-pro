## v1.9.2 图内文字最小化（Figure Text Economy）

原创科研示意图只保留对象、关系、变量、策略、单位等**读图必需文字**；“核心区别”“研究切入点示意”“不代表试验结果”等元话语放在论文图注/来源说明中，而不放进画面。对真实数据图保留坐标轴、单位、图例及不确定性信息。

新版演示 `assets/figure_demo/figure_01.pptx` 已移除冗余底栏和免责声明，并重新导出 `figure_01.svg`；图注在 [examples/16_minimal_text_in_figures.md](examples/16_minimal_text_in_figures.md)。

```bash
python scripts/figure_text_economy_audit.py assets/figure_demo/figure_01.pptx
python -m unittest discover -s tests -q
```

---

## v1.9.1 新增：段落整合与自然论述（Paragraph Cohesion & Narrative Flow）

支持 `paragraph-flow` 模式。新机制在 `reader-navigation` 的基础上避免“每个写作动作单独成段”，通过邻段的真实论证任务判断 `KEEP/MERGE/REFRAME/SPLIT`。不制定段落数或段长硬指标；保留 RQ/H、研究阶段与事实/统计限定。提供只读 `scripts/paragraph_flow_audit.py` 与测试、案例和评测协议。**此版仅更新 Skill，不对既有19页课程报告执行全篇合并。**

```bash
python scripts/paragraph_flow_audit.py manuscript.docx --out-json flow_candidates.json
python -m unittest discover -s tests -q
```

## v1.8.1：新增 PPT 原生示意图 → SVG 的默认图源流程

在 v1.8 的“读者导航与必要配图”基础上，**原创关系/流程/机制/研究设计示意图**默认先用 PowerPoint 原生形状和可编辑文本绘制，保留 `.pptx`，再输出真实 `.svg`。有真实数据的结果图优先用数据与作图代码导出矢量格式；既有论文原图、照片等不强行 PPT 描摹。SVG 不可只是 PNG/JPG 的包裹文件。

图源规范见 [references/ppt-native-svg-workflow.md](references/ppt-native-svg-workflow.md)，可编辑源与矢量结构初筛运行 `python scripts/figure_source_audit.py figure.pptx figure.svg`。**这只是结构检查，不能代替真实图义复核和最终 PDF 全页视觉审查。**

---

**v1.8 新增：** `reader-navigation` 模式，依据读者任务选择小标题、独立 RQ/H 行、必要的研究示意图与质量标准显著性；不自动增加装饰图，不改变研究事实。见 `references/reader-navigation-and-figures.md`。

## v1.7.0：有证据支撑的明确判断（Calibrated Academic Assertiveness）

新增对“必要科学限定 / 真正可能误读的澄清 / 无信息增益的预设反驳”的功能性区分。保留事实与比较边界，优先用正面研究判断替换无用的提前辩解；不是禁用“不能”“可能”等词，不要求所有否定句消失，也不强制多代理或全篇改写。修复此前候选方案暴露的“缺推理 ≠ 缺证据”、中英混排长度计数和保留旧句冒充新增论证等问题。

```bash
python -m unittest discover -s tests -q
python scripts/defensive_writing_audit.py evals/example_assertiveness_v17.json
```

参见 [references/calibrated-academic-assertiveness.md](references/calibrated-academic-assertiveness.md) 和 [evals/CALIBRATED_ASSERTIVENESS_EVALUATION_PROTOCOL.md](evals/CALIBRATED_ASSERTIVENESS_EVALUATION_PROTOCOL.md)。自动化测试通过不代表真人可读性提高。

---

## v1.6.1：论证增益而非扩写（2026-11-23）

基于 v1.5/v1.6 在五段真实研究设计稿上的探索性对照：v1.6 在部分核心论证中增益明显，但汉字量较 v1.5 增加约25%；通知负担段过长。现在要求对新增解释说明明确推理价值，**优先替换重复话语**；超过约15%的扩写需要人工复核，不将其作为强制字数上限。方法/伦理/通知负担已清楚时优先 KEEP/SHORTEN。新增标准库脚本 `reasoning_gain_audit.py`、可追溯账本、正反例和独立读者评测规范；不自动证明实际可读性提升。保留全部 v1.6 功能。

```bash
python scripts/reasoning_gain_audit.py evals/example_reasoning_gain_v161.json
python -m unittest discover -s tests -q
```

详情：[references/reasoning-gain-per-word.md](references/reasoning-gain-per-word.md) · [evals/REASONING_GAIN_EVALUATION_PROTOCOL.md](evals/REASONING_GAIN_EVALUATION_PROTOCOL.md)。

---

# Chinese Academic Readability Pro v1.9.3

新增 **Intellectual Depth & Critical Reasoning（学术思想深度与批判性论证）**及 **Scientific Priority & Stop Rule（科研问题优先级与停止规则）**：不再将“考虑更多例外和技术细节”误认为思想深刻。优先审查影响整篇研究成立的 1—3 条核心命题，追踪问题、证据、推理桥梁、竞争性解释与设计可检验性；对边缘实施细节及时停止扩写。保留 v1.5 的文章类型与 A/B/C 深度分级，及 FACT/COMPARISON LOCK、DOCX/PDF 成稿 QA。新增模块**不会替你制造文献、自动修改研究设计或保证真人可读性得分提高**。

最快调用：

```text
使用 chinese-academic-readability v1.6 的 intellectual-depth 模式，
先识别本文最重要的两三个学术判断，检查证据和推理是否真正支持它们，
对必要的竞争解释和设计边界适度深化。不要补充无来源机制，
不要穷举所有技术例外；当科学主线足够明确时执行 PRIORITY & STOP RULE。
保留事实、核心比较和研究阶段，并给出修改后全文。
```

只读账本检验：

```bash
python scripts/intellectual_depth_audit.py evals/example_intellectual_depth_v16.json
python -m unittest discover -s tests -q
```

详见 [references/intellectual-depth-gate.md](references/intellectual-depth-gate.md)、[references/scientific-priority-stop-rule.md](references/scientific-priority-stop-rule.md)、[examples/09_intellectual_depth_without_perfectionism.md](examples/09_intellectual_depth_without_perfectionism.md)。

---

新增 **Academic Writing Depth Control／学术写作深度控制**。解决“学术上很严谨，但针对课程初步开题写得像操作协议”的问题。核心工作流：先确定读者与写作类型（DEPTH LOCK）→ 保留科学设计与比较（FACT / COMPARISON LOCK）→ 最小命题 A/B/C 分类（必写/简述/当前正文可省）→ 有边界的内容重构 → 教师/方法双视角审读 → 文档成稿时执行原有 artifact-qa。

**不会**凭技术词或长度自动删除段落。正式方案、伦理注册、实证论文方法和系统综述有不同的细节要求。无独立读者结果不得声称 Skill 已被实验证明提升可读性。

快速预审：

```bash
python scripts/depth_control_audit.py report.docx --profile course-preproposal --out-json depth.json
python -m unittest discover -s tests -q
```

详细文体画像见 [references/writing-depth-profiles.md](references/writing-depth-profiles.md)，分级账本见 [references/content-tier-decision.md](references/content-tier-decision.md)，新命令在 [USAGE_GUIDE_CN.md](USAGE_GUIDE_CN.md)。

---

## v1.4.2 已保留功能

## 新增：v1.4 文件渲染与视觉核查（与润色独立）

当任务交付 DOCX/PDF 时，请额外运行：

```bash
pip install python-docx PyMuPDF Pillow numpy lxml
python scripts/submission_gate.py /path/to/report.docx --out-dir /path/to/qa-out --engine libreoffice
```

它输出独立的 **DOCX→PDF→全部页面 PNG**、字体信息、目录校验、来源文字/表格单元格保真候选、逐页签核模板和 `submission_gate.json`/`submission_report.md`。必须逐页签核才能 PASS。没有 Word 引擎，Word 模式会 UNVERIFIED；PDF 已有缺字会 FAIL。**不会修改论文内容**。完整细则见 [references/document-rendering-qa.md](references/document-rendering-qa.md)。

源开发回归测试保留 68 项，v1.4 新增 26 项（总计至少 94 项）。测试通过只说明工程功能，不等于真人可读性效果或所有渲染软件无故障。**用户的私有 28 页 DOCX 不包含在安装包中**。

**中文学术论文论证与可读性优化 Skill**。重点适配体育科学、运动干预、行为科学与心理健康相关科研写作，保护事实和结论边界，不以“去 AI 味”或语言换词为唯一目标。

## 保留的 v1.3 学术语义机制（基于真实科研稿缺陷）

- **比较命题锁（COMPARISON LOCK）**：不再允许“有差异/区别于”被未经核查地润色为“优于/劣于/等效/非劣”。新增 `comparison_hypothesis_shift` 专项报警，可提示比较目标、断言强度、既往/当前研究来源变更。此条来自真实科研设计稿对照暴露的失效类型。
- **研究事实新增门槛**：增加 `unit_binding_changed` 和 `stat_comparator_changed`，发现数值集合不变却把“28天”写成“28周”或 `P<0.05` 改成 `P>0.05` 等问题；对部分必要限定删除报警。
- **最小必要改写**：把 KEEP/POLISH/REORDER/MERGE/NEED_SOURCE/STOP & REVIEW 变成编辑决策，并用 `edit_footprint.py` 给出篇幅/句长变化描述，禁止把“更短”当成可读性证明。
- **更严格的独立读者设计**：新增 `prepare_reader_study.py`，每名读者每段仅接触一版，跨读者轮换均衡，并将版本映射与参考答案保存在独立私有目录。旧 `prepare_blind_eval.py` 改标为并列偏好用途。
- **额外测试**：增加针对比较假设漂移、统计符号、单位、来源归属、误报对照、读者分配与隐私隔离的自动化回归。

**注意：**前一轮确实使用用户已有中文体育科研研究设计稿做过 A/B/C 文本示范，但在同一模型上下文生成，没有独立真人结果；不得把这项示范写成“Skill 已证实优于普通 AI”。

## 保留的 v1.2 和 v1.1 功能

- **论证关系图（Argument Map）**：每段中心判断、原稿证据、推理桥梁、段间关系、保留/合并/重排建议。
- **语义保真审计**：数字之外，还检查变量方向、否定、比较对象、方法设计、显著性、计划时态和因果强度。
- **候选科研风险提示**：`audit_text.py` 基于候选线索识别观察性因果夸大、非显著等效误判、方案冒充成果、无依据的泛化与机制证实等可疑句子；不自动定罪。
- **修改前后比较工具**：`compare_versions.py` 发现中文紧贴单位的数值变化，并新增组别—指标—数值、变量关系方向的绑定提示；无法理解所有语义归属。
- **独立评审工具链**：`prepare_blind_eval.py` 随机遮盖同稿 A/B/C 的来源，输出可交给外部读者的材料；答案映射默认单独存放在用户私有状态目录（0600），绝不和评审文件共用目录。
- **中文体育学科风格卡**：强调观察与干预、测量与机制、症状评分与诊断的区别；**不是**对任何期刊的已验证风格模仿。
- **新增 31 条针对性规则回归场景**（包括阴性对照），并保留原有 10 个模型行为场景，新增 v1.4 失效回归和 CLI 安全测试。

## 目录结构

```text
chinese-academic-readability/
├── SKILL.md                          # Skill 入口（兼容 Agent Skills 结构）
├── README.md / USAGE_GUIDE_CN.md
├── references/
│   ├── argument-mapping.md           # 新增：命题—证据—推理—段间关系
│   ├── semantic-fidelity.md          # 新增：语义保真
│   ├── sports-academic-style-card.md # 新增：中文体育科研写作
│   └── ...                            # 保留原来的读者、章节、方法边界规则
├── scripts/
│   ├── audit_text.py                 # 只读：候选风险检测
│   ├── compare_versions.py           # 只读：数值/单位/比较等级/因果等变更线索
│   ├── edit_footprint.py             # 只读：篇幅/句长/改写幅度描述（非评分）
│   ├── prepare_reader_study.py       # 单次接触的分组均衡盲评材料
│   ├── prepare_blind_eval.py         # 仅用于并列匿名偏好对照
│   └── validate_skill.py             # 本地：文件/链接结构检查
├── evals/
│   ├── EVALUATION_PROTOCOL.md        # 同稿 A/B/C 比较协议
│   ├── READER_SCORECARD.md           # 独立读者评分表
│   ├── risk_regression_cases.json    # 31 条定向测试及阴性对照
│   ├── scenarios.json                # 原有 10 项模型行为评测规范
│   └── example_abc_input.json        # 仅虚构演示，非真实论文证据
├── examples/                          # 虚构例文，说明如何执行
└── tests/                             # Python 3.10+ 标准库测试
```

## 安装

完整解压到所使用的 Agent 支持的 Skill 目录，保留文件夹名 `chinese-academic-readability`。**不要复制单独的 SKILL.md 而丢失 references/scripts。**

常见个人技能目录示例（请以当前客户端官方文档为准）：

- Codex：`~/.agents/skills/chinese-academic-readability/`
- Claude Code：`~/.claude/skills/chinese-academic-readability/`
- Antigravity / Gemini：检查当前版本实际发现的技能目录，不直接假设与 Codex 相同。

已安装 v1.0 时，请**备份旧目录**再替换。更新后开启新任务，先让 Agent 列出本 Skill 的版本号 `1.9.3`，再进行一次简单只读检查。**本包只生成了可安装文件，未自动修改用户本机。**

## 常用调用

```text
使用 chinese-academic-readability v1.9.3 的深度重构模式修改下述《体育科学》方向的实证论文引言。
先建立 FACT LOCK，再提取段落的核心主张、证据锚点、推理桥梁和段间关系。
只对真正影响理解的位置重构；删掉空泛套话，但不删除必要的研究限定。
最后运行语义保真复核，若无法启用独立读者 Agent，请明确写“未独立盲评”。
[粘贴正文与已核实来源]
```

更多调用见 [USAGE_GUIDE_CN.md](USAGE_GUIDE_CN.md)。

## v1.4 工程检验门槛

- **科研数字回归**：原先漏报的 10 组数值变化，现应全部产生 `numbers_changed`。
- **科研风险回归**：上一轮留下的 21 个正例、12 个阴性案例（现在是已知回归集），以及新增 14 个定向反例，均应符合预期。
- **组别/变量归属**：交换干预组与对照组均值、交换正负关联对象时，必须产生专项提示。
- **盲评安全**：公开目录只含评审资料，不得含答案映射。私钥文件权限 0600，私钥目录不可位于公开目录内。
- **发版安全**：所有文件需通过 SHA-256、ZIP 路径安全检查；全新解压后再次通过单测。

这些是确定性工程验收标准，不代表真实论文效果已通过独立盲评。

## 本地验证

从 Skill 根目录运行：

```bash
python scripts/validate_skill.py .
python scripts/verify_release.py /path/to/Chinese_Academic_Readability_Pro_v1.9.3.zip --run-tests
python -m unittest discover -s tests -v
python scripts/audit_text.py examples/05_argument_map.md --format markdown
python scripts/compare_versions.py before.md after.md --format json
python scripts/prepare_blind_eval.py evals/example_abc_input.json ./blind_example --seed 20261122
python scripts/prepare_reader_study.py evals/example_reader_study_v13.json ./reader_folder --reviewers 12 --private-dir ./separate_keys
python scripts/edit_footprint.py before.md after.md --format json
```

`edit_footprint.py` 和 `compare_versions.py` 需要准备 `before.md`/`after.md`。两种评审工具的默认私钥目录不同：单次接触读者为 `~/.local/state/chinese-academic-readability/reader-keys/`，并列比较为 `~/.local/state/chinese-academic-readability/blind-keys/`。如通过 `--private-dir/--key-dir` 指定路径，务必放在公开文件目录之外，**绝不能与公开目录存在父子关系**。不要向评审者分享私钥或整个实验父目录。

### 重要限制

自动脚本是**候选风险线索**，不是科学结论验证器、AI 检测器或可读性打分器。测试通过仅说明包结构与**预设规则**回归正常。目前尚无真实独立读者评分和严格隔离生成的对照结果，**不能宣称相对普通 AI 有稳定的真实效果提升**。论文使用 AI 的披露及投稿政策由作者依据目标期刊规则负责。


## v1.4.1 字体与实际 PDF 验证

中文固定宋体（SimSun），英文及数字 Times New Roman。需执行 `python scripts/font_audit.py report.docx --pdf report.pdf` 以及 `python scripts/submission_gate.py report.docx --out-dir qa --strict-simsun-times`。如果导出 PDF 使用 Noto Serif CJK 或 Liberation Serif，虽然看起来可读，也不能算严格字体门禁 PASS；应在具有正规字库的 Word 环境重新导出，再验证。

## v1.4.2 — 原生字体 PDF 导出与直接验收

严格区分 **Word 声明宋体/Times New Roman** 和 **最终 PDF 实际嵌入了这两套字体**。使用 `font_environment.py` 检查系统中真正存在的字体元数据（不接受 fontconfig 替代）；`prepare_word_fonts.py` 只设置 Word 在保存时的字体嵌入请求，不携带任何字体字节。只有在有合法字库的 Word 环境中导出，才有机会获得符合要求的 PDF。

```bash
python scripts/font_environment.py
python scripts/prepare_word_fonts.py report.docx --out report_word_ready.docx
# 在装有授权 SimSun / Times New Roman 的 Microsoft Word 中导出 report_word_ready.pdf
python scripts/font_audit.py report_word_ready.docx --pdf report_word_ready.pdf
python scripts/submission_gate.py report_word_ready.docx \
  --existing-pdf report_word_ready.pdf --out-dir qa_native \
  --external-engine-label 'Microsoft Word (user-reported)' --strict-simsun-times
```

Linux 当前环境没有 SimSun / Times New Roman 原字库，不可制作原生字体 PDF。macOS 的 Word 可手工导出；`native_word_export.py` 的 macOS AppleScript 是待本机实际验证的可选方式。`--existing-pdf` **不会再调用 LibreOffice 重导**，从而保留真实 Word 导出结果进行检查。

新增外部 PDF 来源整体不匹配阻断、PDF 实际 FontFile 嵌入校验、系统字体真实名字校验；本版共 115 项程序测试，技术测试不代表真人视觉签核已完成。严禁把字体文件纳入 ZIP。


## v1.9 科研绘图路线（CCF-Figure/ARIS/CCFA方向的自有整合）

读 [references/scientific-figure-intelligence.md](references/scientific-figure-intelligence.md)：先图义与证据，再类型选择。原创架构、研究流程用可编辑 `PPTX→SVG`；真实实验结果使用可复现 Python/数据→SVG/PDF；原论文图、照片保留来源和权利。`scripts/scientific_figure_plan.py` 只输出路线规划，不会虚构数值；`scripts/figure_provenance_audit.py` 检查数据/源文件SHA。样例见 [examples/14_figure_selection_preproposal_icml.md](examples/14_figure_selection_preproposal_icml.md)。来源链接与限制写在引用文档；没有复制外部 Skills 的源码。

真实CSV的最小 SVG/PDF 绘图命令见 `scripts/plot_verified_csv.py --help`；不自动聚合或填补缺失。


## v1.9.3 自然段落与具体机制图

- 在真实稿件中只合并服务同一论证任务的段落；课程初步开题的综合章节不强制增加二级标题。
- 当有已确认的选时/实验流程条件时，优先提供能展示实际决策逻辑的具体示意图；如果条件不充分，使用诚实的抽象结构或不配图。
- 适用的原创图示必须保留可编辑 PPTX、真正矢量 SVG 和随图图注；**S* 等尚未冻结的设计不得画成已观察结果或固定选择**。
- 查看 `examples/17_narrative_and_timing_figure.md`，以及 `assets/figure_case_timing/` 的来源与图源。

> **提示（v1.9.3）**：`assets/figure_case_timing/` 采用用户研究设计实例，仅供其个人技能试用；在公共仓库分发或向无权获知研究细节的第三方分享前，请核对并移除此案例素材。它不是已完成实验的结果图。
