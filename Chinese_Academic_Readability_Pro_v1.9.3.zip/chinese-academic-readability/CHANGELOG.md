# v1.9.3 — Natural Narrative & Contextual Figures（2026-11-23）

- 依据最新版19页课程开题修改案例，把“自然段落与具体机制图”的优先级写入 `SKILL.md`：不靠段数优化质量，不因综合章节而机械增设小节。
- 对抽象“提示发送时间 vs 实际步行时间”比较图增加**有前提的具体日程时间线案例**，保留原生PPTX+SVG，图义条件写在随图图注与来源记录中。
- 明确S*在留出核查前未确定；图示只能说明A/B/C规则在某个条件下可能产生不同选择，不能表示实际效果或普遍方向。
- 新增示例、来源合同及回归测试；保留 v1.9.2 所有既有工具和数据检查，无整篇论文内容入包。
- 工程验收与真实读者效果验证分别报告，不拿测试项数量替代可读性证据。

# v1.9.2 — Figure Text Economy（2026-11-23）

- 图面默认只保留读图必需文字；图注和来源记录承载免责声明、研究阶段与详细解释。
- 修改可编辑 PPTX 示例，删除图内“核心区别”“研究切入点示意”“不代表试验结果”，保持策略和时点关系及真实矢量图。
- 新增只读 PPTX 文字审查器、规则、示例和回归测试；不按固定字数裁决复杂数据图。
- 保留 v1.9.1 既有论证、科研事实、段落、科研绘图与 Artifact QA 能力。

## v1.9.1 — Paragraph Cohesion & Narrative Flow（2026-11-23）

- 在 v1.9 原有科研绘图、论证、FACT/COMPARISON/DESIGN LOCK 与成稿 QA 基础上新增 `paragraph-flow` 模式。
- 用邻段“同一完整论证任务”决定是否合并；避免机械三段式、独立微标签与过度小标题，明确保护 RQ/H、研究阶段、统计与因果边界。
- 不规定段落数量或长度目标，不自动合并；新增只读候选脚本、科研示范、评测协议与专项单元测试。
- 不改动旧版例图、科研图表工具、历史测试和任何原论文文件。自动测试通过不等于真人读者可读性提升已获证明。

## v1.9 — Scientific Figure Intelligence (2026-11-23)

- 新增论文类型与证据类型相结合的 figure contract 路由，方法架构/体育科研方案优先 PPTX 原生可编辑图元→SVG，真实数据图优先 Python 可复现。
- 新增 `scripts/scientific_figure_plan.py`（数据缺失硬阻断）、`scripts/figure_provenance_audit.py`（来源哈希检查）、`scripts/plot_verified_csv.py`（真实数据 SVG/PDF 绘图）、独立测试、审计协议与演示示例。
- 借鉴 CCF-Figure、CCFA Visual Composer、ARIS paper-figure、K-Dense Scientific Visualization 的*公开设计思路*，不复制其仓库代码或许可证受限内容。
- 所有旧版论文语言、语义保真、文档/字体 QA 和可编辑 SVG 图源规则继续保留。

## v1.8.1 — PPT Native Editable Diagrams → SVG（2026-11-23）

- 对**适用的大多数原创学术示意图**确立 PowerPoint 原生形状/文字/连接线 → 可编辑 PPTX → 真正矢量 SVG 的默认工作流。
- 例外包括真实科研数据图、原论文图、真实照片、需专业工具的特殊图；不为凑“多数”增加无必要配图。
- 新增图源审查规范、用例、技术结构检查与回归测试；禁止 PNG/JPG 套壳 SVG，必须保留来源图义与字体、最终 PDF 逐页复核。
- 原有论文与 v1.8 成稿未改动；工具和新图源规则不能证明独立读者效果。

## v1.8.0 — Reader Navigation & Selective Figures

- 新增读者导航与必要图示模块，避免长段阅读疲劳与研究假设难以定位。
- 增加 RQ/H、图号/图注、关键阈值的辅助检查；非视觉判决、非自动插图。
- 保留 v1.7 全部科学审查工具与回归测试。

# v1.7.0 — Calibrated Academic Assertiveness

- 增加必要科学限定、真实澄清、无信息预设辩解的分类与修订准则。
- 保证已有证据但缺推理时可补解释，缺事实证据时不得靠修辞补足。
- 统一多语言文本的篇幅计数；对锁状态拒绝数字 0/1，保留旧文不计作新论证。
- 新增账本一致性检查、正反例、使用示范和回归测试；独立读者效果仍需另验。
- v1.6.1 全部文件与测试保留，未改其旧测试文件。

# v1.6.1 · Reasoning Gain per Word（2026-11-23）

- 根据 2026-11-23 五段体育科学真实稿探索性对照的 T5 通知负担扩写问题，增设“有限必要推理”门禁。
- 对关键引言/讨论允许有据深化，对已清楚的方法、伦理及通知负担优先保留或精简；新增解释应优先替换重复内容而不是叠加。
- 新增相对基准文稿扩写超过约15%的人审提醒，**不**构成强制长度上限或自动学术评分。
- 新增 `references/reasoning-gain-per-word.md`、`scripts/reasoning_gain_audit.py`、`tests/test_v161.py` 及对应虚构样例/评测协议；旧版全部文件及科研/渲染门禁保留。
- 未取得独立真人读者效果，不可声称 v1.6.1 已被证明优于 v1.5/v1.6。

---

# v1.6.0 · Intellectual Depth & Priority Stop（2026-11-22）

- 新增 `intellectual-depth` 模式：区别“方法写到多细”（v1.5 `depth-control`）与“解释是否深入”。优先检查1—3个核心学术命题的证据、推理、竞争解释、比较和研究可检验边界。
- 新增 `SCIENTIFIC PRIORITY & STOP RULE`：按 CRITICAL / IMPORTANT / OPTIONAL 分级，避免为完美主义穷举异常、技术实施细节和无来源的机制。关键研究设计或安全问题绝不省略。
- 新增 `references/intellectual-depth-gate.md`、`references/scientific-priority-stop-rule.md`、`examples/09_intellectual_depth_without_perfectionism.md`、`evals/INTELLECTUAL_DEPTH_EVALUATION_PROTOCOL.md`。
- 新增标准库只读 `scripts/intellectual_depth_audit.py` 与 `tests/test_v16.py`；脚本仅检查人工/Agent标注的论证账本，不生成正文、不评价真人理解或学术深度分数。
- 保留 v1.5 的原有140项回归和原有文件 QA 工具；新增工程测试并执行发布包独立解压校验。

---

# v1.5.0 — Academic Writing Depth Control（2026-11-22）

- 新增 `depth-control` 模式与 `DEPTH LOCK`：根据写作类型、读者和研究阶段决定正文应该写到何种深度，避免将课程初步开题写成实施协议。
- 新增 A/B/C 命题层级与删改账本；保留 FACT LOCK/COMPARISON LOCK，区分固定的科学设计与待预测试的执行参数。
- 设六种文章目标画像，课程开题下自动识别**可能**过细的实施段落，但明确禁止自动删除或以字数证明质量。
- 新增 `scripts/depth_control_audit.py`、合成样例、课程开题编辑指引、真实读者效果评测协议与单元回归测试。
- 保留 v1.4.2 的 DOCX/PDF 视觉质量与原生字体检查；所有内容重构之后再独立进行 artifact-qa。
- 用真实28页技术化开题和19页课程稿做**回顾性结构对照**，不是独立受控的人类可读性A/B/C试验。

# Changelog

## v1.4.0 — Artifact Fidelity / Rendering & Visual QA

- 保留 v1.3 的 FACT LOCK、COMPARISON LOCK、正文论证诊断、独立读者流程和 68 项旧回归测试。
- 增加独立 `artifact-qa`，不修改科研正文；文件交付时强制执行。
- 新增 `render_document.py`：记录导出引擎和版本、生成 PDF 与全页 PNG、隔离 LibreOffice profile；Windows Word COM 可选，环境不可用标 UNVERIFIED。
- 新增 `artifact_fidelity.py`：DOCX 正文与表格单元格对照 PDF，已知中文失字锚点、局部缺失段和原生数学公式清点；证据不全不宣告 PASS。
- 新增 `visual_audit.py`：目录页码、源字体声明与 PDF 字体清单、越界文本、像素缺字候选、全页视觉签核证据/图像哈希。
- 新增 `submission_gate.py`：PASS/FAIL/UNVERIFIED，输出结构化 JSON 与可追溯报告；`--reuse-render` 校验 PDF/图片哈希后复用已签核文件。
- 新增 26 项 v1.4 测试，涵盖中文缺字、表格截断、公式、目录、隐藏白字、不同引擎和人工签核；旧 68 项保留。
- 用用户提供的真实 28 页 DOCX 进行 LibreOffice 导出验收：确认 28/28 页、16/16 目录项相符，但已知策略 C 和表 4 中文丢字触发 FAIL。

# 更新记录

## 1.3.0 — 2026-11-22

- 针对真实研究稿测试发现的“区别于 A→优于 A”推断偏移，新增 COMPARISON LOCK 与审查模块。
- 版本比较工具新增：`comparison_hypothesis_shift`、`unit_binding_changed`、`stat_comparator_changed`、`essential_qualifier_removed` 候选提示；区分部分比较断言/假设及前人/本研究证据归属。
- 加入最小必要改写决策与 `edit_footprint.py`，避免用无证据扩写、句长压缩冒充改进。
- 加入 `prepare_reader_study.py`：一位读者只见同题一版，跨读者均衡分配，答案映射私有隔离。
- 保留 `prepare_blind_eval.py` 供并列偏好评审；不再用于声称独立理解测试。
- 新增 v1.3 正反例、权限和 CLI 回归测试；先于发布在全新解压目录运行。
- **尚未获得独立真人理解测试成绩，也无本次真实论文因果效果结论。**

# Changelog

## v1.2.0 — 2026-11-22

- 修复中文数字紧邻单位时的未检测问题；兼容千分位、小数、负号、百分数、科学计数法。
- 新增数字归属绑定提示（组别/指标）和变量方向归属变化提示。
- 审核器改为自然段/跨行上下文，增加研究来源主体区分，并补充非显著→等效、机制推断等近义线索。
- 安全分离盲评材料与答案私钥；默认保存到私有状态目录，权限 `0700/0600`；允许指定独立私钥目录。
- 增加上一轮 33 条外部挑战样本及全新测试；保留原版规则的回归。
- 更新阅读工作流、自动检查边界和停止条件；任何脚本通过不代表真实论文可读性已改善。

## v1.1.0

新增 FACT LOCK、ARGUMENT MAP、语义保真检查、学科风格卡、读者 A/B/C 评审协议。

## v1.4.1 — 2026-11-22
- 新增双层字体验收：DOCX 的 `SimSun/Times New Roman` 声明，以及 PDF 真实字体替换审查。
- `submission_gate.py` 新增 `--strict-simsun-times`，字体代替时整体 FAIL。
- 28页真实科研报告确认：只改字体声明即可修复先前两处缺字，但会引发文献目录页码漂移，需配合分页回归；当前 Linux PDF 没有真正的商业字体，不能冒充严格交付 PASS。


## v1.4.2 — 2026-11-22 · Native font export and exact-PDF gate
- 字体系统预检：检查真实家族元数据，拒绝把系统回退或字体文件名当成 SimSun / Times New Roman。
- Word 保存时字体嵌入请求：仅改 `word/settings.xml`，不改研究文字、表格、公式，也不打包字体。
- 支持 Microsoft Word（Windows COM / macOS 可选 AppleScript）本地导出；没有可用原字库时停止并报告 UNVERIFIED。
- 新增 `submission_gate.py --existing-pdf`，直接审查用户在 Word 导出的 PDF，不让没有字库的 LibreOffice 重导替代。
- PDF 嵌入验证要求检查 FontFile 字体实际数据，不单凭字体名称。
- 当 DOCX/PDF 内容显著不匹配、没有自定义锚点或都是短段落时，仍阻止误判为 PASS。
- 原 101 项回归保留，新增 14 项，总计 115 项程序测试。真实原生 PDF 字体最终交付仍需在有字体的 Word 环境另行验证。
