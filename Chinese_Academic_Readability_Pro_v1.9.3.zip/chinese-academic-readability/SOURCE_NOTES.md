## v1.9.1 source note

The paragraph-cohesion rule, synthetic practice examples, read-only Python checker and tests in this update were newly authored for this Skill. They are not copied from external third-party repositories. Earlier CCF-Figure / CCFA / ARIS figure-workflow source attributions remain unchanged. The private user's actual academic report is NOT bundled.

# 来源与独立性说明

本项目是对上一版独立 Skill 的原创增量开发；没有下载、打包或照搬第三方仓库文件，也未冒称与期刊或项目作者合作。

## 借鉴的公开资料（2026-11-22 核查）

- Gusuhanfeng / `academic-writing`：先论证再表达、证据与作者原稿优先。https://github.com/Gusuhanfeng/academic-writing
- WenyuChiou / `academic-writing-skills`：论文论证/审查职责可拆分。https://github.com/WenyuChiou/academic-writing-skills
- Agent Skills 规范：`SKILL.md` + YAML frontmatter + 可选 references/scripts。https://agentskills.io/specification
- Lingard L. (2022), *Writing for the reader*: 读者预期与信息顺序在科学写作中的启发。https://doi.org/10.1007/s40037-022-00708-w
- Gopen & Swan (1990), *The Science of Scientific Writing*: topic/stress position 的读者理解观点。https://www.gatsby.ucl.ac.uk/~pel/misc/gopen_swan.pdf
- ICMJE, *Use of AI by Authors*: 人类作者承担 AI 辅助稿件的准确性、责任与披露义务。https://www.icmje.org/recommendations/browse/artificial-intelligence/ai-use-by-authors.html

## 知识与效果边界

- 英文学术写作的 reader expectations 主要作为中文写作的**启发式**策略，不是经验证的中文句法定律。
- 不曾从真实《体育科学》《上海体育大学学报》期刊语料中计算本包“风格卡”的分布，不能说已经学到两刊“官方文风”。
- `scripts/` 检测依赖有限模式匹配，会有误报、漏报和跨段上下文误解；不能替代文献阅读或统计审计。
- 包内所有含实验数据的修改示例均为**虚构练习**，不属于已经验证的论文证据。
- Python 回归测试通过 ≠ 模型执行 Skill 就一定遵循指令 ≠ 已完成真实读者盲评 ≠ 实际论文可读性稳定改善。
- 公开仓库来源和 ICMJE 等准则用于规范设计，不表示它们认可本 Skill。


## v1.4 数据来源与保密
用户实际 28 页研究设计稿只在隔离验收目录使用，不打包进公开安装 ZIP。示例锚点只有少量科研文字、不包括姓名或学号；Word/LibreOffice 官方导出方式需由使用者在本机确认。视觉审查不依赖 OCR。


## v1.5 依据与限制（2026-11-22）

依据用户已提供的《体育科学研究方法》课程初步开题实际改稿过程，增加“写作对象与内容深度”控制。28页原稿与19页精简稿属于用户文档，不随本安装包分发；本 Skill 只包括合成示例和通用规则。新增脚本回归、用户文稿回顾性对照不属于独立真人读者效果实验。


## v1.6 思想深度与停止规则的证据边界

依据用户在本对话中指出的“思想浅、浮于表面且因完美主义不断增加技术细节”问题，原创加入论证深度门禁与止损机制。规则是编辑工作流建议，不声称已由新文献实验验证或代表任何期刊官方标准；体育科学示例为虚构的教学演示，不包含用户个人资料、真实实验结果或新造引文。即便审查账本通过，也不能认定文章经过了独立真人可读性验证。


## v1.6.1 依据

内部案例：2026-11-23 同模型 v1.5/v1.6 对照中，部分核心论证改善但出现非必要扩写；T5 通知负担段改写过长。此材料属于用户真实、未发表的研究设计稿，不随安装包附带。新脚本只做文本长度和人工账本形式检验，不能代替独立读者判断。


### v1.9 科研图示设计参考（链接记录）

- CCF Figure: https://github.com/Deepshare-Official/CCF-Figure （论文类型→图示结构）
- CCFA-Skills ccf-visual-composer: https://github.com/mikubaka88/CCFA-Skills/tree/main/ccf-visual-composer （visual contract/图源/输出分工）
- ARIS paper-figure: https://github.com/Dcx-swjtu/CCFA-skill （数据图与 LaTeX 表格）
- K-Dense Scientific Visualization: https://github.com/K-Dense-AI/scientific-agent-skills/tree/main/skills/scientific-visualization （数据诚实、误差表达与导出核验）

仅参考这些项目的公开功能思路，不将其文本/代码复制到包中。不同项目的名称和仓库归属不可混淆。

## v1.9.3 用户研究情境示例与文件分发边界

本版在 `assets/figure_case_timing/` 中加入一张从用户已提供的课程研究设计修改过程产生的原创选时示意图（PPTX/SVG/PNG），及仅涵盖时间窗、策略选择的条件化JSON。**不包含整篇用户论文、姓名、学号、真实参加者或原始观测数据**。这是对本用户研究适用的私有示范素材；若将整个 Skill 公开发布或转交无权查看研究方案的第三方，应先移除此目录并删除对应引用，或取得用户明确许可。图中 A/C 选择当晚、B 选择次日午间只在图注前提下成立，S* 尚未由研究一确定。该案例来自开发过程，不能当作独立模型/真人盲评样本。
