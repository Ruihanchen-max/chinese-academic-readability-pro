> 此目录为 v1.9.2 的抽象构图回归样例。对于具有可信实例条件的任务，首选 `assets/figure_case_timing/` 的具体时间线样例；不得由本样例推断实际结果。

# PPTX → SVG clean academic figure: provenance (v1.9.2)

- Figure type: original *conceptual* study design comparison, **no observed result**. Its two right-side timing bars illustrate one possible comparison, not empirical time stamps or intervention effectiveness.
- Content basis: user's course preproposal on timing of information delivery versus timing of planned walking; shared AI service, choice of basic strategy A vs frozen strategy S*. Two strategies may choose the same window or fall back to A.
- Critical context was moved **outside the picture**: see `figure_01_caption.md`. The figure intentionally contains no “不代表试验结果”, “核心区别”, “研究切入点示意” text banners. This omission does not erase the study-phase caveat.
- Editable source: `scripts/build_comparison_demo.py` using python-pptx true PowerPoint shape and text objects; `figure_01.pptx` contains no embedded raster screenshot.
- Actual export: LibreOffice Impress → PDF → Poppler `pdftocairo -svg`; SVG preview rendered with Inkscape. Export was not performed by Microsoft PowerPoint.
- Artifacts: `figure_01.pptx`, `figure_01.pdf`, `figure_01.svg`, `figure_01_preview.png`; text audit and vector audit `figure_01_audit.json`.
- Font limitation: PDF/SVG may contain font substitutions/outlines. Source PowerPoint labels are editable, but SVG text is not guaranteed to remain editable.
- Validation: the PPTX/SVG vector and figure-text heuristics are *structural screening only*. Scientific correctness, target journal acceptance, actual Word/PDF embedding, and human readability require separate verification.
