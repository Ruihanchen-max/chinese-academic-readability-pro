# v1.9 科研配图模块评估协议

## 程序回归（可执行）

- 图类型路由：方法框架→PPTX；观察性结果→Python；原论文图/照片→来源保留；混合图→分开制作+合成。
- 数据来源缺失：`quantitative` 有数据但 `source_files=[]`，不允许生成模拟结果和假 PASS。
- 不能凭 `paper_type` 猜出作者实际上不存在的模型模块；缺少来源时标记审查。
- 图义保真：`research_stage=planned` 不绘制虚假统计效果或显著性标注。
- 样本示意 PPTX 包含原生形状与文本，转换后 SVG 包含可绘制矢量元素，均在正式页面大小检查标签。
- 老版本 242 项回归保持；新增测试不要修改旧测试中的期望值来制造通过。

## 不属于程序可证明的结果

- 模型结构与真实论文/代码的科学一致性、图是否具有ICML审稿水准、原论文转载许可、真实字体遵循、外部读者能否立即理解、各期刊最新格式。必须有原论文/代码/合法原图、视觉审查与必要的人类裁决。

## 外部独立实测建议

将同一真实论文的同一图面任务随机交给：A 自由制图、B v1.8.1、C v1.9；由不知版本来源的读者评估科学图义理解、可编辑性和视觉拥挤。真实结果图另核对准确数据/误差/缺失处理，禁止偏好评分抵消科学错误。

## Data plotting execution gate (v1.9)

`scripts/plot_verified_csv.py` supports single series or explicit group labels in CSV. It does not aggregate, interpolate, impute, or calculate confidence intervals. A requested interval requires both lower and upper columns and an interval definition. Regression tests use explicit **synthetic test fixtures**, never paper results. Final plots require real CSV source and a manual check of axes, captions, independent sample units and grouping. This route is distinct from PPTX schematic export.

## v1.9.2 图内文字回归检查

- 原 PPTX 示例必须不再出现“核心区别”“研究切入点示意”“不代表试验结果”等画面文字；这些信息必须在来源记录或独立论文图注中正确保留。
- 数字图中的轴、单位、组别、误差含义不得因简化文字被删除；在无真实数据时仍不可造结果图。
- `figure_text_economy_audit.py` 只标识元话语候选，不对可读性、科研正确性或视觉质量自动评分。
