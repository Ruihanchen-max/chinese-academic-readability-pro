# v1.4 真实 28 页学术报告的交付门禁复核协议

**样本**：用户提供的 28 页中文博士课程研究设计 DOCX。原件为用户资料，不包含在可分发 Skill ZIP 中。

## 已知失效锚点（仅用于回归，不代表未知错误检出率）

- PDF 物理第 12 页，源 DOCX 有“再取该时段最早的合格时间”，本次 LibreOffice 导出中缺字。
- PDF 物理第 16 页，源 DOCX 表 4 有“汇总、质控、筛选可行窗口”，导出后变成残缺片段。
- 第 11 页包含 ICC 原生公式，需要真实页面确认下标及分式，不可仅文本抽取；本轮查看该页未发现显著错位。
- 目录 16 项声明页码须与 PDF 对应标题位置一致。

将该报告另行提供给 Agent，运行如下命令：

```bash
python scripts/submission_gate.py /data/report.docx --engine libreoffice \
  --out-dir /tmp/report-qa --anchors-json examples/real-report-anchors-v14.json
```

验收要求：导出 28 页、生成 28 张 PNG，目录验证 16 项，已知缺字必须触发 `FAIL`；检查 PDF 与 Word 的字体差异，并保留公式和视觉签核 `UNVERIFIED` 直到逐页签核。不要为了强行得出 PASS 而偷偷改写研究文本。

如果 Word 引擎可用，在 Windows+Microsoft Word 上另行执行一遍并列对比。结果必须报告各引擎，不得把本机 LibreOffice 的 FAIL 外推为所有 Word 导出方式都失败。

修复后：每次重新生成 PDF 和全页图像；重复相同锚点、目录、数学对象与全部页面审核；经审查者逐页签核后才可将修订版本判为 PASS。无人工审查数据时必须保持未验证。
