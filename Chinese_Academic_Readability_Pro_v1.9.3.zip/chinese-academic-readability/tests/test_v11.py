"""Offline regression tests for v1.1; no model/reader studies are claimed."""
from __future__ import annotations

import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_script(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / "scripts" / f"{name}.py")
    obj = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(obj)
    return obj


auditor = load_script("audit_text")
comparer = load_script("compare_versions")
blind = load_script("prepare_blind_eval")
validator = load_script("validate_skill")


class V11RiskCases(unittest.TestCase):
    def test_fixture_set_is_nontrivial_and_balanced(self):
        cases = json.loads((ROOT / "evals/risk_regression_cases.json").read_text(encoding="utf-8"))
        self.assertGreaterEqual(len(cases), 28)
        self.assertGreaterEqual(sum(bool(x.get("expect")) for x in cases), 12)
        self.assertGreaterEqual(sum(bool(x.get("exclude")) for x in cases), 12)
        self.assertEqual(len({x["id"] for x in cases}), len(cases))

    def test_rule_cases_and_negative_controls(self):
        cases = json.loads((ROOT / "evals/risk_regression_cases.json").read_text(encoding="utf-8"))
        for item in cases:
            with self.subTest(case=item["id"]):
                types = {issue["type"] for issue in auditor.audit_text(item["text"])}
                self.assertTrue(set(item.get("expect", [])).issubset(types), (item["id"], types))
                self.assertFalse(set(item.get("exclude", [])) & types, (item["id"], types))

    def test_detects_six_originally_missed_error_classes(self):
        text = [
            "横断面调查显示二者相关，因此运动可以降低焦虑。",
            "差异未达统计显著，因此两组效果完全相同。",
            "拟招募受试者，研究证实干预有效。",
            "所有运动模式均能改善心理健康。",
            "本研究具有重要的理论意义和实践价值。",
            "两项指标与幸福感相关，因此证明它们通过中介路径发挥作用。",
        ]
        expected = {
            "observational_causal_overclaim", "nonsignificant_as_equivalence", "planned_as_completed",
            "universal_effect_claim", "significance_without_claim", "association_as_mediation",
        }
        matched = set().union(*({i["type"] for i in auditor.audit_text(t)} for t in text))
        self.assertTrue(expected.issubset(matched), matched)

    def test_no_readability_score(self):
        result = auditor.audit_text("本研究具有重要的理论意义和实践价值。")
        self.assertTrue(result)
        self.assertTrue(all("score" not in issue for issue in result))

    def test_fenced_code_excluded(self):
        self.assertEqual(auditor.audit_text("```\n本研究具有重要的理论意义和实践价值。\n```"), [])


class V11SemanticCompare(unittest.TestCase):
    def test_changed_numeric_sign(self):
        flags = comparer.compare_versions("β=-0.18，P=.002。", "β=0.18，P=.002。")
        self.assertIn("numbers_changed", {f["type"] for f in flags})

    def test_equivalent_decimal_presentation(self):
        self.assertEqual(comparer.numbers("P=.002"), comparer.numbers("P=0.002"))

    def test_unchanged_numbers_but_direction_reversed(self):
        flags = comparer.compare_versions("β=-0.18，呈负相关。", "β=-0.18，呈正相关。")
        self.assertNotIn("numbers_changed", {f["type"] for f in flags})
        self.assertIn("direction_or_significance_cue_changed", {f["type"] for f in flags})

    def test_citation_swap(self):
        flags = comparer.compare_versions("已有证据[2]支持关联。", "已有证据[3]支持关联。")
        self.assertIn("citations_changed", {f["type"] for f in flags})

    def test_warning_even_if_rule_has_no_cues(self):
        flags = comparer.compare_versions("本文关注某个概念。", "本文探讨另一个对象。")
        self.assertEqual([f["type"] for f in flags], ["unverified_semantic_change"])

    def test_identical_text_no_difference(self):
        self.assertEqual(comparer.compare_versions("同一段。", "同一段。"), [])

    def test_planned_and_completed_word_cues(self):
        flags = comparer.compare_versions("计划开展实验。", "已经开展实验。")
        self.assertIn("claim_strength_or_scope_cue_changed", {f["type"] for f in flags})


class V11BlindEvaluation(unittest.TestCase):
    def setUp(self):
        self.payload = {"cases": [{"id": "example-1", "variants": {"A": "普通写法。", "B": "强化写法。", "C": "技能写法。"}},
                                  {"id": "example-2", "variants": {"A": "甲。", "B": "乙。", "C": "丙。"}}]}

    def test_blind_mapping_is_complete_and_reproducible(self):
        a, key = blind.prepare(self.payload, seed=12)
        b, key2 = blind.prepare(self.payload, seed=12)
        self.assertEqual((a, key), (b, key2))
        for item in key:
            self.assertEqual(set(item["mapping"].values()), {"A", "B", "C"})
            self.assertEqual(len(item["mapping"]), 3)

    def test_public_document_does_not_contain_answer_key(self):
        a, key = blind.prepare(self.payload)
        content = blind.format_reviewer_pack(a)
        self.assertNotIn("PRIVATE_key", content)
        self.assertNotIn('"mapping"', content)
        self.assertIn("example-1", content)

    def test_invalid_and_duplicate_cases_rejected(self):
        with self.assertRaises(ValueError):
            blind.prepare({"cases": [{"id": "x", "variants": {"A": "a", "B": "b"}}]})
        with self.assertRaises(ValueError):
            blind.prepare({"cases": [{"id": "x", "variants": {"A": "a", "B": "b", "C": "c"}},
                                     {"id": "x", "variants": {"A": "a", "B": "b", "C": "c"}}]})


class V11PackageContract(unittest.TestCase):
    def test_expected_files_and_links(self):
        self.assertEqual(validator.validate(ROOT), [])

    def test_version_and_contract(self):
        body = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        for word in ("1.3.0", "ARGUMENT MAP", "FACT LOCK", "单模型模拟冷读", "语义保真", "A/B/C", "零修改"):
            self.assertIn(word, body)

    def test_critical_references_are_present(self):
        for filename in ("references/argument-mapping.md", "references/semantic-fidelity.md", "references/sports-academic-style-card.md",
                         "evals/READER_SCORECARD.md", "evals/risk_regression_cases.json"):
            self.assertTrue((ROOT / filename).is_file())


if __name__ == "__main__":
    unittest.main()
