"""v1.6.1 reasoning-gain-per-word regression and boundary tests."""
from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
PATH = ROOT / 'scripts' / 'reasoning_gain_audit.py'
spec = importlib.util.spec_from_file_location('reasoning_gain_v161', PATH)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

BASE = '连续测量可以记录日常情绪，研究会适度控制通知次数，并在正式实施前核查实际负担。'
LONG = BASE + '此外需要列举日常每一种异常情形、跨日通知、全部时间冲突、理论最坏上限与每一种重复提示规则，才能体现研究考虑得很全面。'


def payload(b=BASE, r=BASE, gains=None, locks=None):
    return {'baseline_text':b, 'revision_text':r,
            'gains':gains if gains is not None else [],
            'locks':locks if locks is not None else {'fact':True,'comparison':True,'design':True}}


def gain(priority='IMPORTANT', type='key_reasoning_bridge', action='replace',
         evidence_status='explicit_hypothesis', anchor='已定位原段', why_needed='缺少关键解释'):
    return {'id':'G1','priority':priority,'type':type,'action':action,
            'evidence_status':evidence_status,'anchor':anchor,'why_needed':why_needed}


def codes(result):
    return [x['code'] for x in result['findings']]


class ReasoningGainTests(unittest.TestCase):
    def test_keeps_clear_text(self):
        r=m.audit(payload())
        self.assertEqual(r['status'],'SCREEN_CLEAR_NOT_QUALITY_PROOF')
        self.assertIn('KEEP_UNCHANGED',codes(r))

    def test_long_optional_expansion_blocks(self):
        r=m.audit(payload(r=LONG,gains=[gain(priority='OPTIONAL',type='optional_background', action='add')]))
        self.assertEqual(r['status'],'BLOCK_AND_REVISE')
        self.assertIn('EXPANSION_OVER_REVIEW_THRESHOLD',codes(r))
        self.assertIn('NO_NECESSARY_GAIN_FOR_EXPANSION',codes(r))

    def test_long_unannotated_blocks(self):
        r=m.audit(payload(r=LONG))
        self.assertIn('NO_NECESSARY_GAIN_FOR_EXPANSION',codes(r))

    def test_critical_necessary_growth_is_review_not_auto_cut(self):
        r=m.audit(payload(r=LONG,gains=[gain(priority='CRITICAL')]))
        self.assertEqual(r['status'],'HUMAN_REVIEW_REQUIRED')
        self.assertNotIn('NO_NECESSARY_GAIN_FOR_EXPANSION',codes(r))

    def test_append_only_review(self):
        r=m.audit(payload(r=LONG,gains=[gain(action='add')]))
        self.assertIn('APPEND_WITHOUT_REPLACEMENT',codes(r))

    def test_replacement_does_not_force_append_warning(self):
        r=m.audit(payload(r=LONG,gains=[gain(action='replace')]))
        self.assertNotIn('APPEND_WITHOUT_REPLACEMENT',codes(r))

    def test_shortening_not_rejected_for_length(self):
        r=m.audit(payload(r='研究将预先核查通知负担并减少重复提示。',gains=[gain()]))
        self.assertNotIn('EXPANSION_OVER_REVIEW_THRESHOLD',codes(r))

    def test_unknown_locks_do_not_pass(self):
        r=m.audit(payload(locks={'fact':None,'comparison':True,'design':True}))
        self.assertIn('LOCK_NOT_VERIFIED_FACT',codes(r))
        self.assertEqual(r['status'],'HUMAN_REVIEW_REQUIRED')

    def test_lock_breach_blocks_even_when_shorter(self):
        r=m.audit(payload(r='研究已完成。',locks={'fact':False,'comparison':True,'design':True}))
        self.assertIn('LOCK_BREACH_FACT',codes(r))
        self.assertEqual(r['status'],'BLOCK_AND_REVISE')

    def test_unverified_claim_not_silently_approved(self):
        r=m.audit(payload(r=LONG,gains=[gain(evidence_status='not_verified')]))
        self.assertIn('UNVERIFIED_NEW_EXPLANATION',codes(r))
        self.assertIn('NO_NECESSARY_GAIN_FOR_EXPANSION',codes(r))

    def test_gain_requires_anchor(self):
        r=m.audit(payload(r=LONG,gains=[gain(anchor='')]))
        self.assertIn('UNSUPPORTED_GAIN_LEDGER',codes(r))

    def test_invalid_threshold_rejected(self):
        for x in (-1,0,1.1,True,'0.15'):
            with self.assertRaises(ValueError):m.audit({**payload(), 'review_threshold':x})

    def test_duplicate_gain_ids_rejected(self):
        with self.assertRaises(ValueError):m.audit(payload(gains=[gain(),gain()]))

    def test_nonChinese_counts_nonzero(self):
        r=m.audit(payload(b='We examine comparison quality.',r='We compare daily activity time and prompt time.'))
        self.assertGreater(r['baseline_chars'],0)

    def test_invalid_input_rejected(self):
        for obj in (None, {}, {'baseline_text':'ab', 'revision_text':' '}, {'baseline_text':'x', 'revision_text':'xx','gains':[3]}):
            with self.assertRaises(ValueError):m.audit(obj)

    def test_cli_json_output_and_block_exit(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp)
            inp,out=d/'input.json',d/'out.json'
            inp.write_text(json.dumps(payload(r=LONG),ensure_ascii=False),encoding='utf-8')
            res=subprocess.run([sys.executable,str(PATH),str(inp),'--out-json',str(out)],capture_output=True,text=True)
            self.assertEqual(res.returncode,2,res.stderr)
            self.assertEqual(json.loads(out.read_text(encoding='utf-8'))['status'],'BLOCK_AND_REVISE')

    def test_example_not_fake_reader_validation(self):
        x=json.loads((ROOT/'evals'/'example_reasoning_gain_v161.json').read_text(encoding='utf-8'))
        r=m.audit(x)
        self.assertFalse(r['independent_reader_effect_tested'])
        self.assertFalse(r['fact_truth_independently_verified'])

    def test_documentation_files_present(self):
        for rel in ['references/reasoning-gain-per-word.md','examples/10_reasoning_gain_without_bloat.md',
                    'evals/REASONING_GAIN_EVALUATION_PROTOCOL.md','scripts/reasoning_gain_audit.py']:
            self.assertTrue((ROOT/rel).is_file(),rel)
        s=(ROOT/'SKILL.md').read_text(encoding='utf-8')
        for t in ['1.6.1','Reasoning Gain per Word','15%','FACT LOCK']:
            self.assertIn(t,s)

    def test_shortening_original_notification_still_not_fidelity_proof(self):
        b='为控制连续测量带来的作答负担，研究采用简短心理题项并限定通知频次。研究一计划42次日常测量，研究二还计划70次日常测量，并列举极端提醒情景。'
        c='研究一计划42次日常测量，研究二计划70次日常测量，提醒负担在正式研究前核查。'
        r=m.audit(payload(b=b,r=c,gains=[gain()]))
        self.assertFalse(r['fact_truth_independently_verified'])
        self.assertNotIn('EXPANSION_OVER_REVIEW_THRESHOLD',codes(r))


if __name__=='__main__':
    unittest.main()
