"""v1.9.1 paragraph-flow tests: triage, boundaries, manual-only, unchanged previous behavior."""
import importlib.util
import json
import subprocess
import sys
import tempfile
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('paragraph_flow_audit',ROOT/'scripts/paragraph_flow_audit.py')
MOD=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MOD)

def p(i,text,kind=None):
    return {'index':i,'text':text,'kind':kind or MOD.classify(text)}

class ParagraphFlowV191(unittest.TestCase):
    def test_short_adjacent_prose_is_only_candidate(self):
        r=MOD.audit([p(1,'短时步行可能嵌入课间安排。'),p(2,'个人课程时间决定了能否落实建议。')])
        self.assertEqual(r['status'],'REVIEW_ONLY')
        self.assertEqual(r['automatic_merges'],0)
        self.assertIn('adjacent_short_prose',[c['type'] for c in r['candidates']])
    def test_rq_independent_lines_are_protected(self):
        r=MOD.audit([p(1,'RQ1：活动与情绪有什么关联？'),p(2,'RQ2：随机比较能否影响步数？'),p(3,'RQ3：日程与执行有什么关系？')])
        self.assertEqual(r['candidate_count'],0)
        self.assertEqual(r['protected_or_structured_count'],3)
    def test_hypotheses_protected(self):
        r=MOD.audit([p(1,'H1（主要行为）：实验组平均步数更高。'),p(2,'H2（心理次要）：日常情绪效价更高。'),p(3,'H3（探索性）：考察适配与执行。')])
        self.assertEqual(r['candidate_count'],0)
    def test_headings_mark_boundary(self):
        r=MOD.audit([p(1,'上段末尾。'),p(2,'第三章 研究目的与总体设计'),p(3,'下章开头。')])
        self.assertEqual(r['candidate_count'],0)
    def test_markdown_heading(self):
        self.assertEqual(MOD.classify('## 研究背景'), 'heading')
        self.assertEqual(MOD.classify('4.2 研究方法'), 'heading')
    def test_list_and_table_not_prose(self):
        self.assertEqual(MOD.classify('- 变量 A'), 'structured')
        self.assertEqual(MOD.classify('| 研究阶段 | 方法 |'), 'structured')
        r=MOD.audit([p(1,'- 方法一'),p(2,'- 方法二')])
        self.assertEqual(r['candidate_count'],0)
    def test_standalone_label_flagged_not_deleted(self):
        r=MOD.audit([p(1,'研究准备。'),p(2,'拟开展小规模试运行，核查设备与问卷理解。')])
        self.assertEqual(len(r['candidates']),1)
        self.assertEqual(r['candidates'][0]['type'],'standalone_micro_label')
    def test_repeated_opening_candidate_not_error(self):
        r=MOD.audit([p(1,'本研究拟比较两种时间安排。'),p(2,'本研究拟记录建议是否按时完成。')])
        self.assertIn('repeated_opening',[c['type'] for c in r['candidates']])
        self.assertEqual(r['scientific_fidelity'],'UNVERIFIED')
    def test_distinct_study_stages_not_flagged(self):
        r=MOD.audit([p(1,'研究一：开展自然观察。'),p(2,'研究二：开展随机试点。')])
        self.assertEqual(r['candidate_count'],0)
    def test_distinct_ema_measurements_not_flagged(self):
        r=MOD.audit([p(1,'日常 EMA 用于两组日常情绪。'),p(2,'事件 EMA 描述实际步行前后的体验。')])
        self.assertEqual(r['candidate_count'],0)
    def test_distinct_strategy_rules_not_flagged(self):
        r=MOD.audit([p(1,'策略 B：优先活动下降时段。'),p(2,'策略 C：优先历史稳定活跃时段。')])
        self.assertEqual(r['candidate_count'],0)
    def test_distinct_observation_and_randomized_comparison_not_flagged(self):
        r=MOD.audit([p(1,'观察性分析关注关联。'),p(2,'随机试点比较组间差异。')])
        self.assertEqual(r['candidate_count'],0)
    def test_clear_long_prose_zero_candidates(self):
        a='步行建议的时间是否可行，既与日程安排有关，也与个人的活动规律有关。' * 4
        r=MOD.audit([p(1,a), p(2,'本研究采用独立日常测量，以比较两组日常情绪变化。'*5)])
        self.assertEqual(r['candidate_count'],0)
        self.assertEqual(r['readability_improvement'],'UNVERIFIED')
    def test_text_and_md_read(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'t.md';f.write_text('## 背景\n\n第一段。\n\n第二段。\n',encoding='utf-8')
            out=MOD.read_paragraphs(f)
            self.assertEqual([x['kind'] for x in out],['heading','prose','prose'])
    def test_cli_non_mutating(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'t.md';original='第一段。\n\n第二段。\n';f.write_text(original,encoding='utf-8')
            report=Path(d)/'out.json'
            subprocess.run([sys.executable,str(ROOT/'scripts/paragraph_flow_audit.py'),str(f),'--out-json',str(report)],check=True)
            self.assertEqual(f.read_text(encoding='utf-8'),original)
            self.assertEqual(json.loads(report.read_text())['status'],'REVIEW_ONLY')
    def test_reject_unsupported_file_type(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'test.pdf';f.write_text('fake',encoding='utf-8')
            with self.assertRaises(ValueError): MOD.read_paragraphs(f)
    def test_source_wiring_and_reference(self):
        skill=(ROOT/'SKILL.md').read_text(encoding='utf-8')
        for key in ('paragraph-flow','Paragraph Cohesion & Narrative Flow','references/paragraph-cohesion-and-narrative-flow.md','scripts/paragraph_flow_audit.py'):
            self.assertIn(key,skill)
        ref=(ROOT/'references/paragraph-cohesion-and-narrative-flow.md').read_text(encoding='utf-8')
        for key in ('FACT','RQ','H1','KEEP','MERGE','10%'):
            self.assertIn(key,ref)
    def test_source_unchanged_if_no_merge_needed(self):
        a='在共同 AI 服务下比较 A 与 S*，以末两周步数为主要结局。'
        self.assertEqual(MOD.audit([p(1,a)])['candidate_count'],0)
        self.assertEqual(MOD.audit([p(1,a)])['automatic_merges'],0)
    def test_hypothesis_preface_is_structured(self):
        self.assertEqual(MOD.classify('对应的研究假设与探索性预期为：'),'structured')
        r=MOD.audit([p(1,'三个问题分别关注关联、策略效果和实施过程。'),
                     p(2,'对应的研究假设与探索性预期为：')])
        self.assertEqual(r['candidate_count'],0)
    def test_cover_and_contents_not_flagged_as_micro_paragraphs(self):
        try:
            from docx import Document
        except ImportError:
            self.skipTest('python-docx not present')
        with tempfile.TemporaryDirectory() as d:
            doc=Document();doc.add_paragraph('博士课程作业');doc.add_paragraph('报告标题')
            doc.add_paragraph('目 录');doc.add_paragraph('第一章 背景　4')
            doc.add_heading('摘要',1);doc.add_paragraph('本研究拟考察步行与情绪。')
            f=Path(d)/'cover.docx';doc.save(f)
            parts=MOD.read_paragraphs(f)
            self.assertEqual([x['kind'] for x in parts[:4]],['frontmatter']*4)
            self.assertEqual(MOD.audit(parts)['candidate_count'],0)
    def test_docx_paragraphs_if_dependency(self):
        try:
            from docx import Document
        except ImportError:
            self.skipTest('python-docx not present')
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'test.docx';doc=Document();doc.add_heading('研究目的',level=1);doc.add_paragraph('本研究考察步数。');doc.add_paragraph('随后比较不同策略。');doc.save(f)
            ps=MOD.read_paragraphs(f)
            self.assertEqual(ps[0]['kind'],'heading')
            self.assertEqual(len(ps),3)
    def test_no_percent_target_written_in_metadata(self):
        ref=(ROOT/'references/paragraph-cohesion-and-narrative-flow.md').read_text()
        self.assertIn('不等于',ref)
        self.assertIn('不',ref)

if __name__=='__main__':unittest.main()
