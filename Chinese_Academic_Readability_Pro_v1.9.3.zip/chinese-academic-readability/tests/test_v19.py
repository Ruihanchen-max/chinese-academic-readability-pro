"""Figure routing and evidence integrity checks; stdlib only."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
def load(name):
    spec=importlib.util.spec_from_file_location(name, ROOT/'scripts'/f'{name}.py')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod
planner=load('scientific_figure_plan')
prov=load('figure_provenance_audit')

class FigurePlannerTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.basic={"figure_id":"fig_1","paper_type":"intervention","study_phase":"proposal",
            "evidence_kind":"schematic","reader_question":"What is compared?","claim":"Compare timing policies",
            "source_description":"From user draft","elements":["A","S*"]}
    def test_concept_routes_to_editable_ppt_svg(self):
        r=planner.plan(self.basic,self.root)
        self.assertEqual(r['selected_route'],'pptx_native_to_svg')
        self.assertEqual(r['planner_status'],'READY_FOR_CREATION')
        self.assertEqual(r['gates']['visual'],'UNVERIFIED')
    def test_missing_results_data_rejected(self):
        d={**self.basic,"evidence_kind":"quantitative", "paper_type":"analysis", "measurement":"Steps", "unit":"steps/day", "independent_unit":"participants"}
        r=planner.plan(d,self.root)
        self.assertEqual(r['planner_status'],'FAIL')
        self.assertTrue(any('Actual data source' in x for x in r['errors']))
    def test_real_data_routes_to_reproducible_python(self):
        file=self.root/'values.csv';file.write_text('arm,steps\nA,10\nB,13\n')
        d={**self.basic,"evidence_kind":"quantitative", "paper_type":"analysis", "source_files":["values.csv"], "measurement":"Steps", "unit":"steps/day", "independent_unit":"participants", "uncertainty":"SD"}
        r=planner.plan(d,self.root)
        self.assertEqual(r['selected_route'],'python_reproducible_svg_pdf')
        self.assertEqual(len(r['source_records']),1)
        self.assertEqual(prov.audit(r,self.root)['provenance_status'],'PASS')
    def test_changed_data_hash_fails(self):
        file=self.root/'source.csv';file.write_text('x,y\n1,2\n')
        d={**self.basic,"evidence_kind":"quantitative", "source_files":["source.csv"], "measurement":"y", "unit":"units", "independent_unit":"trial", "uncertainty":"CI"}
        p=planner.plan(d,self.root);file.write_text('x,y\n1,9\n')
        self.assertEqual(prov.audit(p,self.root)['provenance_status'],'FAIL')
    def test_mixed_evidence_routes_to_two_source_pipelines(self):
        (self.root/'data.json').write_text('{"value":1}')
        d={**self.basic,"evidence_kind":"mixed", "source_files":["data.json"],"measurement":"Accuracy", "unit":"%", "independent_unit":"subject"}
        p=planner.plan(d,self.root)
        self.assertEqual(p['selected_route'],'separate_pptx_and_python_panels')
    def test_published_no_source_must_fail(self):
        d={**self.basic,"evidence_kind":"published"}
        self.assertEqual(planner.plan(d,self.root)['planner_status'],'FAIL')
    def test_photograph_routes_to_original(self):
        f=self.root/'photo.jpg';f.write_bytes(b'not-real-image-file')
        d={**self.basic,'evidence_kind':'photo','source_files':['photo.jpg']}
        self.assertEqual(planner.plan(d,self.root)['selected_route'],'preserve_authentic_image')
    def test_unknown_type_requires_explicit_identification(self):
        d={**self.basic,'paper_type':'neuroscience-unknown'}
        self.assertEqual(planner.plan(d,self.root)['planner_status'],'FAIL')
    def test_no_question_is_rejected(self):
        d={**self.basic,'reader_question': ''}
        self.assertEqual(planner.plan(d,self.root)['planner_status'],'FAIL')
    def test_bad_json_value_type_does_not_coerce(self):
        d={**self.basic,'figure_needed':1}
        self.assertEqual(planner.plan(d,self.root)['planner_status'],'FAIL')
    def test_no_figure_is_valid_stop(self):
        d={**self.basic,'figure_needed':False}
        self.assertEqual(planner.plan(d,self.root)['planner_status'],'SKIP')
    def test_planned_data_warns_never_silent(self):
        (self.root/'data.csv').write_text('x\n1')
        d={**self.basic, 'evidence_kind':'quantitative', 'source_files':['data.csv'], 'measurement':'steps', 'unit':'steps/day', 'independent_unit':'person'}
        self.assertIn('Planned study', ' '.join(planner.plan(d,self.root)['warnings']))
    def test_missing_source_description_is_blocked(self):
        d={**self.basic,'source_description':''}
        self.assertEqual(planner.plan(d,self.root)['planner_status'],'FAIL')
    def test_included_example_has_no_fake_result(self):
        a=json.loads((ROOT/'evals/figure_contract_schematic_example.json').read_text())
        self.assertEqual(planner.plan(a, ROOT)['selected_route'], 'pptx_native_to_svg')
        b=json.loads((ROOT/'evals/figure_contract_unavailable_results.json').read_text())
        self.assertEqual(planner.plan(b, ROOT)['planner_status'],'FAIL')
    def test_provenance_empty_schematic_only_structural(self):
        p=planner.plan(self.basic,self.root)
        a=prov.audit(p,self.root)
        self.assertEqual(a['scientific_accuracy'],'UNVERIFIED')
        self.assertEqual(a['provenance_status'],'UNVERIFIED')
    def test_demonstration_has_editable_shapes_and_genuine_vector(self):
        mod=load('figure_source_audit')
        demo=ROOT/'assets/figure_demo'
        result=mod.audit(demo/'figure_01.pptx',demo/'figure_01.svg')
        self.assertEqual(result['structure_status'],'PASS')
        self.assertGreater(result['pptx_structure']['native_shapes'],5)
        self.assertEqual(result['pptx_structure']['picture_shapes'],0)
        self.assertEqual(result['svg_structure']['image_elements'],0)
        self.assertEqual(result['scientific_content_fidelity'],'UNVERIFIED')

    def test_reference_paths_and_proper_names(self):
        skill=(ROOT/'SKILL.md').read_text(encoding='utf-8')
        self.assertIn('Scientific Figure Intelligence',skill)
        self.assertIn('references/scientific-figure-intelligence.md',skill)
        ref=(ROOT/'references/scientific-figure-intelligence.md').read_text()
        for s in ('CCF-Figure','CCFA Visual Composer','ARIS paper-figure','Scientific Visualization','PPTX'):
            self.assertIn(s,ref)

if __name__=='__main__':unittest.main()
