"""Data plot tests: rows are explicitly fake test fixtures and are NOT results."""
import importlib.util
from pathlib import Path
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('plot_verified_csv',ROOT/'scripts/plot_verified_csv.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)

class DataPlotTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup)
        self.root=Path(self.t.name)
        self.source=self.root/'test_only_synthetic.csv'
        self.source.write_text('x,y,lower,upper\n1,2,1,3\n2,3,2,4\n',encoding='utf-8')
    def kwargs(self):return {'x':'x','y':'y','kind':'line','out_prefix':self.root/'out'}
    def test_reproducible_plot_has_svg_pdf_and_source_hash(self):
        r=mod.plot(self.source,**self.kwargs())
        self.assertEqual(len(r['input_sha256']),64)
        self.assertTrue((self.root/'out.svg').is_file())
        self.assertTrue((self.root/'out.pdf').is_file())
        self.assertEqual(r['scientific_interpretation'],'UNVERIFIED')
    def test_interval_requires_type(self):
        with self.assertRaises(ValueError):mod.plot(self.source,**self.kwargs(),lower='lower',upper='upper')
    def test_interval_labels_are_recorded(self):
        r=mod.plot(self.source,**self.kwargs(),lower='lower',upper='upper',interval_label='illustrative 95% CI')
        self.assertIn('95%',r['uncertainty'])
    def test_interval_inversion_rejected(self):
        self.source.write_text('x,y,lower,upper\n1,2,3,4\n')
        with self.assertRaises(ValueError):mod.plot(self.source,**self.kwargs(),lower='lower',upper='upper',interval_label='CI')
    def test_missing_column_rejected(self):
        with self.assertRaises(ValueError):mod.plot(self.source,**{**self.kwargs(),'y':'missing'})
    def test_missing_values_not_imputed(self):
        self.source.write_text('x,y,lower,upper\n1,,1,3\n2,3,2,4\n')
        r=mod.plot(self.source,**self.kwargs())
        self.assertEqual(r['missing_y_rows'],1)
        self.assertIn('no aggregation, imputation',r['transformations'])
    def test_grouped_bar_without_design_rejected(self):
        with self.assertRaises(ValueError):mod.plot(self.source,**{**self.kwargs(),'kind':'bar','group':'x'})

if __name__=='__main__':unittest.main()
