"""v1.4.2: genuine font preflight, exact supplied PDF verification and no false embedding claims."""
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from zipfile import ZipFile
from lxml import etree
import json
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from font_environment import inspect_environment
from font_audit import inspect_pdf
from render_document import inspect_existing_pdf, sha256
from submission_gate import run_gate


def fixtures(root):
    import fitz
    from docx import Document
    doc=root/'sample.docx'; d=Document();d.add_paragraph('中文数据共125人，25%');d.save(doc)
    pdf=root/'sample.pdf';p=fitz.open();pg=p.new_page();pg.insert_text((50,75),'Times New Roman required',fontname='helv');p.save(pdf);p.close()
    return doc,pdf


class TestV142(unittest.TestCase):
    def setUp(self):
        self.tmp=TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.docx,self.pdf=fixtures(self.root)

    def test_01_no_font_does_not_claim_installed(self):
        with patch('font_environment._fontconfig_fonts',return_value=[]),patch('font_environment._known_font_paths',return_value=[]):
            self.assertEqual(inspect_environment()['status'],'UNVERIFIED')

    def test_02_font_name_in_filename_not_sufficient(self):
        fake=self.root/'SimSun.ttf';fake.write_bytes(b'not a font')
        with patch('font_environment._fontconfig_fonts',return_value=[('SimSun',fake)]),patch('font_environment._known_font_paths',return_value=[]),patch('font_environment._font_names_from_file',return_value={'Other Font'}):
            r=inspect_environment();self.assertIn('SimSun',r['missing_font_families'])

    def test_03_genuine_metadata_succeeds_with_two_fonts(self):
        a=self.root/'a.ttf';b=self.root/'b.ttf';a.write_bytes(b'fake');b.write_bytes(b'fake')
        def names(p):return {'SimSun'} if p==a else {'Times New Roman'}
        with patch('font_environment._fontconfig_fonts',return_value=[]),patch('font_environment._known_font_paths',return_value=[a,b]),patch('font_environment._font_names_from_file',side_effect=names):
            self.assertEqual(inspect_environment()['status'],'PASS')

    def test_04_pdf_builtin_font_is_not_embedded(self):
        # Force a family match only to isolate the embedding check.
        with patch('font_audit._pdf_font_match',return_value=True):
            r=inspect_pdf(self.pdf)
        self.assertEqual(r['status'],'FAIL')
        self.assertTrue(any(v['issue']=='font_not_embedded' for v in r['violations']))

    def test_05_external_pdf_page_render_and_hash(self):
        r=inspect_existing_pdf(self.docx,self.pdf,self.root/'out',dpi=72,engine_label='Word PDF supplied')
        self.assertEqual(r['status'],'PASS')
        self.assertEqual(r['engine_used'],'Word PDF supplied')
        self.assertFalse(r['export_provenance_verified'])
        self.assertEqual(r['pages'],1)
        self.assertEqual(sha256(self.pdf),r['pdf_sha256'])
        self.assertEqual(len(r['page_images']),1)

    def test_06_external_pdf_gate_never_reexports(self):
        with patch('submission_gate.convert_docx',side_effect=AssertionError('must not re-export')):
            result=run_gate(self.docx,self.root/'external',strict_simsun_times=True,existing_pdf=self.pdf,
                            external_engine_label='Microsoft Word (claimed by user)',scan_ink=False)
        self.assertEqual(result['font_status'],'FAIL')
        self.assertEqual(result['status'],'FAIL')
        manifest=json.loads((self.root/'external/render_manifest.json').read_text())
        self.assertFalse(manifest['export_provenance_verified'])
        self.assertEqual(manifest['pdf_sha256'],sha256(self.pdf))

    def test_07_reuse_and_external_are_incompatible(self):
        with self.assertRaises(ValueError):
            run_gate(self.docx,self.root/'fail',reuse_render=True,existing_pdf=self.pdf)

    def test_08_missing_external_pdf_is_unverified(self):
        r=inspect_existing_pdf(self.docx,self.root/'nonexistent.pdf',self.root/'missing')
        self.assertEqual(r['status'],'UNVERIFIED')

    def test_09_external_pdf_one_page_changes_invalidate_hash(self):
        dir=self.root/'out'
        r=inspect_existing_pdf(self.docx,self.pdf,dir)
        manifest=dir/'render_manifest.json';manifest.write_text(json.dumps(r))
        result=run_gate(self.docx,dir,reuse_render=True,strict_simsun_times=True)
        self.assertEqual(result['status'],'FAIL')  # wrong fonts, not stale image
        (dir/'pages/page-001.png').write_bytes(b'changed')
        result=run_gate(self.docx,dir,reuse_render=True)
        self.assertEqual(result['status'],'FAIL')
        self.assertIn('images',result['reason'])

    def test_10_no_font_native_export_is_unverified(self):
        from native_word_export import native_export
        with patch('native_word_export.inspect_environment',return_value={'status':'UNVERIFIED','missing_font_families':['SimSun']}):
            r=native_export(self.docx,self.root/'native')
        self.assertEqual(r['status'],'UNVERIFIED')
        self.assertFalse(Path(r['pdf']).exists())

    def test_11_nonpdf_as_existing_pdf_fails(self):
        a=inspect_existing_pdf(self.docx,self.docx,self.root/'bad')
        self.assertEqual(a['status'],'FAIL')

    def test_12_external_pdf_not_matched_to_source_is_not_verified_by_render_alone(self):
        r=inspect_existing_pdf(self.docx,self.pdf,self.root/'unrelated')
        self.assertEqual(r['status'],'PASS')
        self.assertIn('user-provided',r['reason'])
        # A render-stage PASS must never be interpreted as source text fidelity PASS.
        from artifact_fidelity import check_fidelity
        result=check_fidelity(self.docx,self.pdf)
        self.assertNotEqual(result['status'],'PASS')

if __name__=='__main__':unittest.main()
