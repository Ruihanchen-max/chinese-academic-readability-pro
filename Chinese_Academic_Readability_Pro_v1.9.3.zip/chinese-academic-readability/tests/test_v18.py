"""v1.8 navigation hints regression: do not mistake a heuristic for quality proof."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from docx import Document

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('navigation_audit_v18',ROOT/'scripts/navigation_audit.py')
audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)

class NavigationTest(unittest.TestCase):
    def go(self,paragraphs=(),table_text=None):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'test.docx'; d=Document()
            for x in paragraphs:d.add_paragraph(x)
            if table_text:
                t=d.add_table(rows=1,cols=1);t.cell(0,0).text=table_text
            d.save(path);return audit.audit(path)
    def codes(self,r):return {x['code'] for x in r['warnings']}
    def test_rq_hidden_in_long_paragraph_warns(self):
        r=self.go(['RQ1：活动有何关联？RQ2：分组效果怎样？'])
        self.assertIn('RQ_MULTIPLE_IN_ONE_PARAGRAPH',self.codes(r))
    def test_rq_separated_no_warning(self):
        r=self.go(['RQ1：活动有何关联？','RQ2：分组效果怎样？'])
        self.assertNotIn('RQ_MULTIPLE_IN_ONE_PARAGRAPH',self.codes(r))
    def test_h3_exploratory_label_not_reclassified(self):
        r=self.go(['H3（探索性）：考察适配与执行的关系。'])
        self.assertIn('H3',r['hypothesis_anchors'][0]['identifiers'])
    def test_multi_h_in_one_paragraph_warns(self):
        self.assertIn('H_MULTIPLE_IN_ONE_PARAGRAPH',self.codes(self.go(['H1支持这一点；H2也预期改善。'])))
    def test_single_figure_ref_and_caption(self):
        r=self.go(['拟定设计见图1。','图1 两阶段研究设计'])
        self.assertNotIn('FIGURE_REFERENCE_MISSING_CAPTION',self.codes(r))
    def test_missing_caption_is_hint(self):
        r=self.go(['研究流程见图2。'])
        self.assertIn('FIGURE_REFERENCE_MISSING_CAPTION',self.codes(r))
    def test_duplicate_caption_flag(self):
        r=self.go(['图1 研究对照','图1 两阶段研究设计'])
        self.assertIn('DUPLICATE_FIGURE_CAPTION',self.codes(r))
    def test_number_gaps_flag(self):
        r=self.go(['图1 研究对照','图3 两阶段研究设计'])
        self.assertIn('FIGURE_CAPTION_NUMBERING_REVIEW',self.codes(r))
    def test_threshold_findability_hint(self):
        r=self.go(['有效日拟以清醒佩戴至少10小时，记录覆盖至少80%判断。'])
        self.assertIn('THRESHOLD_FINDABILITY_REVIEW',self.codes(r))
    def test_absent_threshold_no_invented_flag(self):
        r=self.go(['研究将根据设备记录质量判断有效日。'])
        self.assertFalse(r['key_thresholds'])
    def test_ambiguous_table(self):
        r=self.go(['比较两组。'],table_text='具体时间由选择')
        self.assertIn('TABLE_AMBIGUOUS_WRAP',self.codes(r))
    def test_fixed_table(self):
        r=self.go(['比较两组。'],table_text='按冻结的S*确定步行时间')
        self.assertNotIn('TABLE_AMBIGUOUS_WRAP',self.codes(r))
    def test_no_quality_pass_claim(self):
        r=self.go(['这是一个正常段落。'])
        self.assertEqual(r['status'],'HEURISTIC_ONLY_NOT_VISUAL_QA')
        self.assertFalse(r['is_independent_reader_evidence'])
        self.assertFalse(r['is_page_visual_validation'])
    def test_not_forcing_titles(self):
        r=self.go(['只有一个自然段的中文论文节选。'])
        self.assertFalse(r['warnings'])
    def test_s_star_spacing_is_visual_review_hint(self):
        r=self.go(['将冻结规则 S * 用于研究二。'])
        self.assertIn('S_STAR_TEXT_SPACING',self.codes(r))

if __name__=='__main__':unittest.main()
