"""v1.4.1: strict SimSun / Times New Roman is a separate, verifiable gate."""
from __future__ import annotations
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
import json
import sys
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from font_audit import inspect_docx, inspect_pdf, audit
from submission_gate import run_gate

def make_docx(p:Path, cjk='SimSun'):
    d=Document()
    st=d.styles['Normal']
    for item in (st._element,):
        rp=item.find(qn('w:rPr'))
        if rp is None:rp=OxmlElement('w:rPr');item.append(rp)
        rf=rp.find(qn('w:rFonts'))
        if rf is None:rf=OxmlElement('w:rFonts');rp.insert(0,rf)
        for k,v in [('ascii','Times New Roman'),('hAnsi','Times New Roman'),('eastAsia',cjk),('cs','Times New Roman')]:rf.set(qn('w:'+k),v)
        for k in ('asciiTheme','hAnsiTheme','eastAsiaTheme','cstheme'):rf.attrib.pop(qn('w:'+k),None)
    d.add_paragraph('研究方法：122人，activity intervention.')
    d.save(p)

def make_wrong_pdf(p:Path):
    import fitz
    d=fitz.open();pa=d.new_page();pa.insert_text((70,120),'中文研究：字体检验',fontname='china-s',fontsize=12);pa.insert_text((70,150),'Times New Roman required',fontname='helv',fontsize=11);d.save(p);d.close()

class TestV141(unittest.TestCase):
    def setUp(self):
        t=TemporaryDirectory();self.addCleanup(t.cleanup)
        self.root=Path(t.name);self.docx=self.root/'test.docx';self.pdf=self.root/'test.pdf'
        make_docx(self.docx);make_wrong_pdf(self.pdf)

    def test_01_correct_docx_declared_font_pass(self):
        res=inspect_docx(self.docx)
        self.assertEqual(res['status'],'PASS')

    def test_02_wrong_songti_not_simsun(self):
        make_docx(self.docx,'Songti SC')
        res=inspect_docx(self.docx)
        self.assertEqual(res['status'],'FAIL')

    def test_03_pdf_substitutions_fail(self):
        res=inspect_pdf(self.pdf)
        self.assertEqual(res['status'],'FAIL')
        self.assertGreater(len(res['violations']),0)

    def test_04_missing_pdf_is_unverified(self):
        res=audit(self.docx)
        self.assertEqual(res['status'],'UNVERIFIED')

    def test_05_pdf_font_fail_dominates_docx_pass(self):
        res=audit(self.docx,self.pdf)
        self.assertEqual(res['docx']['status'],'PASS')
        self.assertEqual(res['pdf']['status'],'FAIL')
        self.assertEqual(res['status'],'FAIL')

    def test_06_gate_includes_requested_font_status(self):
        render={'status':'PASS','pdf_path':str(self.pdf),'engine_used':'mock','engine_version':'mock','pdf_sha256':'0', 'pages':1, 'page_images':[str(self.root/'page-001.png')]}
        fidelity={'status':'PASS','anchors':[],'suspected_count':0,'source_inventory':{'native_omath_nodes':0}}
        visual={'status':'PASS','toc_results':[],'toc_checked':0,'suspected_inkless_glyph_page_count':0,'review_status':'PASS'}
        with patch('submission_gate.convert_docx',return_value=render),patch('submission_gate.check_fidelity',return_value=fidelity),patch('submission_gate.inspect_visual',return_value=visual):
            result=run_gate(self.docx,self.root/'out',strict_simsun_times=True)
        self.assertEqual(result['font_status'],'FAIL')
        self.assertEqual(result['status'],'FAIL')
        self.assertTrue((self.root/'out/font_audit.json').exists())

    def test_07_standard_gate_does_not_require_fonts_unless_requested(self):
        render={'status':'PASS','pdf_path':str(self.pdf),'engine_used':'mock','engine_version':'mock','pdf_sha256':'0','pages':1,'page_images':[str(self.root/'page-001.png')]}
        fidelity={'status':'PASS','anchors':[],'suspected_count':0,'source_inventory':{'native_omath_nodes':0}}
        visual={'status':'PASS','toc_results':[],'toc_checked':0,'suspected_inkless_glyph_page_count':0,'review_status':'PASS'}
        with patch('submission_gate.convert_docx',return_value=render),patch('submission_gate.check_fidelity',return_value=fidelity),patch('submission_gate.inspect_visual',return_value=visual):
            result=run_gate(self.docx,self.root/'out',strict_simsun_times=False)
        self.assertEqual(result['font_status'],'NOT_REQUESTED')
        self.assertEqual(result['status'],'PASS')

if __name__=='__main__':unittest.main()
