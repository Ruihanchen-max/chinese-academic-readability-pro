"""v1.9.3 regression: discourse continuity and a scientifically conditional, editable timing figure.

These tests validate deterministic contracts, NOT improvements in human readability.
"""
from __future__ import annotations

import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'scripts/timing_figure_case_check.py'
fig = ROOT / 'assets/figure_case_timing'
spec = importlib.util.spec_from_file_location('timing_figure_case_check', SRC)
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)
CASE = json.loads((fig/'figure_case.json').read_text(encoding='utf-8'))


class V193RoutingAndText(unittest.TestCase):
    def test_version_metadata(self):
        s=(ROOT/'SKILL.md').read_text(encoding='utf8')
        self.assertIn('version: "1.9.3"',s)

    def test_explicit_new_workflow(self):
        s=(ROOT/'SKILL.md').read_text(encoding='utf8')
        self.assertIn('## 0L. Editorial Calibration',s)
        self.assertIn('references/editorial-calibration-and-concrete-figures.md',s)

    def test_chapter7_not_forced_into_subsections(self):
        s=(ROOT/'references/editorial-calibration-and-concrete-figures.md').read_text(encoding='utf8')
        self.assertIn('无须强加',s)
        self.assertIn('7.1/7.2/7.3',s)

    def test_not_a_universal_no_heading_rule(self):
        s=(ROOT/'references/editorial-calibration-and-concrete-figures.md').read_text(encoding='utf8')
        self.assertIn('院系模板',s)

    def test_no_fixed_paragraph_quota(self):
        s=(ROOT/'references/editorial-calibration-and-concrete-figures.md').read_text(encoding='utf8')
        self.assertIn('没有固定字数或段数比例',s)

    def test_protects_rq_h_and_ema_boundaries(self):
        s=(ROOT/'examples/17_narrative_and_timing_figure.md').read_text(encoding='utf8')
        for q in ('RQ/H','策略A/B/C','日常EMA','事件EMA'):
            self.assertIn(q,s)

    def test_no_artificial_mechanism_drawing(self):
        s=(ROOT/'references/editorial-calibration-and-concrete-figures.md').read_text(encoding='utf8')
        self.assertIn('没有实例就不造实例',s)

    def test_needs_source_for_conditional_choices(self):
        s=(ROOT/'examples/17_narrative_and_timing_figure.md').read_text(encoding='utf8')
        self.assertIn('条件来自已有课程研究方案',s)
        self.assertIn('S*仍未确定',s)

    def test_stops_when_no_improvement(self):
        s=(ROOT/'SKILL.md').read_text(encoding='utf8')
        self.assertIn('描述性段落数变化不是质量分数',s)

    def test_existing_mandatory_scientific_locks(self):
        s=(ROOT/'SKILL.md').read_text(encoding='utf8')
        for x in ('FACT LOCK','COMPARISON LOCK','DESIGN LOCK','artifact-qa'):
            self.assertIn(x,s)

    def test_example_keeps_separate_caption(self):
        self.assertTrue((fig/'figure_01_caption.md').exists())
        c=(fig/'figure_01_caption.md').read_text(encoding='utf8')
        self.assertIn('示例',c)
        self.assertIn('S*',c)
        self.assertIn('A与C',c)

    def test_source_provenance_explicit_no_trial_results(self):
        p=(fig/'PROVENANCE.md').read_text(encoding='utf8')
        self.assertIn('不属于真实受试者观测数据',p)
        self.assertIn('真实',p)

    def test_recommended_case_and_legacy_separated(self):
        p=(ROOT/'assets/figure_demo/PROVENANCE.md').read_text(encoding='utf8')
        self.assertIn('figure_case_timing',p)


class V193CaseChecks(unittest.TestCase):
    def check(self,**overrides):
        c=copy.deepcopy(CASE)
        c.update(overrides)
        return checker.audit(c,fig)

    def test_valid_is_review_only_not_science_pass(self):
        r=self.check()
        self.assertEqual(r['status'],'REVIEW_ONLY')
        self.assertEqual(r['scientific_content_fidelity'],'UNVERIFIED')

    def test_a_earliest(self):
        r=self.check(strategy_choices={'A':'next_noon','B':'next_noon','C':'evening'})
        self.assertEqual(r['status'],'FAIL')
        self.assertTrue(any('A_NOT_EARLIEST' in x for x in r['errors']))

    def test_unfrozen_s_star_rejects_premature_selection(self):
        r=self.check(S_star_status='B_selected')
        self.assertEqual(r['status'],'FAIL')

    def test_missing_b_assumptions(self):
        r=self.check(conditional_assumptions={'B':'','C':'当晚为历史稳定活跃的合格时段'})
        self.assertEqual(r['status'],'FAIL')

    def test_unknown_window_rejected(self):
        r=self.check(strategy_choices={'A':'evening','B':'outside','C':'evening'})
        self.assertEqual(r['status'],'FAIL')

    def test_notification_must_precede_window(self):
        r=self.check(notification={'day_offset':0,'time':'19:00'})
        self.assertEqual(r['status'],'FAIL')

    def test_invalid_day_type_rejected(self):
        r=self.check(notification={'day_offset':True,'time':'17:00'})
        self.assertEqual(r['status'],'FAIL')

    def test_duplicate_ids_rejected(self):
        w=copy.deepcopy(CASE['feasible_windows']); w[1]['id']=w[0]['id']
        self.assertEqual(self.check(feasible_windows=w)['status'],'FAIL')

    def test_caption_parent_traversal_rejected(self):
        self.assertEqual(self.check(caption_file='../secret.txt')['status'],'FAIL')

    def test_missing_caption_detected(self):
        self.assertEqual(self.check(caption_file='missing_caption.md')['status'],'FAIL')

    def test_result_masquerade_rejected(self):
        self.assertEqual(self.check(evidence_status='completed_rct_results')['status'],'FAIL')

    def test_example_is_editable_vector_not_raster(self):
        s=ROOT/'scripts/figure_source_audit.py'
        spec2=importlib.util.spec_from_file_location('figure_source_audit_v193',s)
        mod=importlib.util.module_from_spec(spec2);spec2.loader.exec_module(mod)
        r=mod.audit(fig/'figure_01.pptx',fig/'figure_01.svg')
        self.assertEqual(r['structure_status'],'PASS')
        self.assertEqual(r['pptx_structure']['picture_shapes'],0)
        self.assertEqual(r['svg_structure']['image_elements'],0)
        self.assertGreaterEqual(r['pptx_structure']['native_shapes'],10)

    def test_no_disclaimers_inside_example_picture(self):
        s=ROOT/'scripts/figure_text_economy_audit.py'
        sp=importlib.util.spec_from_file_location('figure_text_economy_audit_v193',s)
        m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
        self.assertEqual(m.audit_pptx(fig/'figure_01.pptx')['candidate_count'],0)

    def test_cli_success(self):
        p=subprocess.run([sys.executable,str(SRC),str(fig/'figure_case.json')],capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertEqual(json.loads(p.stdout)['status'],'REVIEW_ONLY')

    def test_cli_bad_case(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'bad.json';bad=copy.deepcopy(CASE);bad['S_star_status']='C_selected'
            path.write_text(json.dumps(bad,ensure_ascii=False),encoding='utf8')
            p=subprocess.run([sys.executable,str(SRC),str(path)],capture_output=True,text=True)
            self.assertNotEqual(p.returncode,0)
            self.assertEqual(json.loads(p.stdout)['status'],'FAIL')


if __name__=='__main__': unittest.main()
