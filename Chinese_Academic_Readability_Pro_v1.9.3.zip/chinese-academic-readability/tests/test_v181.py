"""PPT native shapes → SVG source integrity: stdlib-only regression tests."""
import importlib.util
from pathlib import Path
import tempfile
import unittest
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('figure_source_audit', ROOT / 'scripts/figure_source_audit.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class NativeVectorSourceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.pptx = Path(self.temp.name) / 'figure.pptx'
        self.svg = Path(self.temp.name) / 'figure.svg'

    def ppt(self, native=True, picture=False):
        tags = []
        if native:
            tags.append('<p:sp><p:nvSpPr/><p:spPr/><p:txBody><a:p><a:r><a:t>研究一</a:t></a:r></a:p></p:txBody></p:sp>')
            tags.append('<p:cxnSp><p:nvCxnSpPr/><p:spPr/></p:cxnSp>')
        if picture:
            tags.append('<p:pic><p:nvPicPr/><p:blipFill/></p:pic>')
        xml = f'<p:sld xmlns:p="{module.PML_NS}" xmlns:a="{module.A_NS}"><p:cSld><p:spTree>{"".join(tags)}</p:spTree></p:cSld></p:sld>'
        with ZipFile(self.pptx, 'w') as z:
            z.writestr('ppt/slides/slide1.xml', xml)

    def svg_file(self, contents):
        self.svg.write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 300">' + contents + '</svg>', encoding='utf-8')

    def test_native_shapes_svg_vector_pass_structure_only(self):
        self.ppt(native=True)
        self.svg_file('<rect width="100" height="50"/><text x="0" y="20">研究一</text>')
        r = module.audit(self.pptx, self.svg)
        self.assertEqual(r['structure_status'], 'PASS')
        self.assertEqual(r['visual_fidelity'], 'UNVERIFIED')
        self.assertGreater(r['pptx_structure']['native_shapes'], 0)
        self.assertGreater(r['svg_structure']['actual_vector_elements'], 0)

    def test_picture_only_pptx_not_editable(self):
        self.ppt(native=False, picture=True)
        self.svg_file('<rect width="100" height="50"/>')
        r = module.audit(self.pptx, self.svg)
        self.assertEqual(r['structure_status'], 'FAIL')
        self.assertIn('PPTX_NOT_EDITABLE_VECTOR', r['failures'][0])

    def test_png_wrapped_as_svg_fails(self):
        self.ppt(native=True)
        self.svg_file('<image href="data:image/png;base64,AAA" width="400" height="200"/>')
        r = module.audit(self.pptx, self.svg)
        self.assertEqual(r['structure_status'], 'FAIL')
        self.assertIn('SVG_NOT_VECTOR', r['failures'][0])

    def test_mixed_svg_requires_review_not_false_pass(self):
        self.ppt(native=True)
        self.svg_file('<path d="M 0 0 H 10"/><image href="data:image/jpeg;base64,AAA" width="1" height="1"/>')
        self.assertEqual(module.audit(self.pptx, self.svg)['structure_status'], 'UNVERIFIED')

    def test_real_vector_inside_svg_definition_not_counted(self):
        self.ppt(native=True)
        self.svg_file('<defs><rect id="r" width="5" height="5"/></defs><image href="photo.jpg"/>')
        self.assertEqual(module.audit(self.pptx, self.svg)['structure_status'], 'FAIL')

    def test_invalid_svg_xml_rejected(self):
        self.ppt(native=True)
        self.svg.write_text('<svg><path></svg>', encoding='utf-8')
        with self.assertRaises(ValueError): module.audit(self.pptx, self.svg)

    def test_no_office_is_not_visual_qa(self):
        self.ppt(native=True)
        self.svg_file('<path d="M1 1L2 2"/>')
        r = module.audit(self.pptx, self.svg)
        self.assertEqual(r['scientific_content_fidelity'], 'UNVERIFIED')
        self.assertEqual(r['font_compliance'], 'UNVERIFIED')

    def test_skill_explicitly_contains_policy(self):
        data = (ROOT / 'SKILL.md').read_text(encoding='utf-8')
        self.assertIn('可编辑 PPT', data)
        self.assertIn('矢量 SVG', data)
        self.assertIn('references/ppt-native-svg-workflow.md', data)
        self.assertIn('拒绝假矢量', data)

    def test_workflow_scope_excludes_published_figures(self):
        data = (ROOT / 'references/ppt-native-svg-workflow.md').read_text(encoding='utf-8')
        self.assertIn('真实数据图', data)
        self.assertIn('已发表论文原始图', data)
        self.assertIn('真实照片', data)

if __name__ == '__main__':
    unittest.main()
