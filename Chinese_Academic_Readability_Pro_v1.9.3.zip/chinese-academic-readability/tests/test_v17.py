"""v1.7 calibrated assertiveness and reasoning audit regression tests."""
from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


def load(name):
    path = ROOT / 'scripts' / (name + '.py')
    spec = importlib.util.spec_from_file_location(name + '_v17', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


m = load('defensive_writing_audit')
gain = load('reasoning_gain_audit')


def item(category='UNNECESSARY_DEFENSE', action='REMOVE', original='这不意味着别人完全没有研究过。',
         revision='', scope_verified=True, **kw):
    return {'id': 'I1', 'category':category, 'action':action, 'original':original,
            'revision':revision, 'rationale':'没有对应的实际误读风险',
            'scope_verified':scope_verified, **kw}


def payload(*items, locks=None):
    return {'entries':list(items) if items else [item()], 'locks': locks or
            {'fact':True,'comparison':True,'design':True,'scope':True}}


def codes(r):return {f['code'] for f in r['findings']}


class AssertivenessTests(unittest.TestCase):
    def test_unneeded_rebuttal_can_be_removed_after_scope_review(self):
        r=m.audit(payload(item()))
        self.assertEqual(r['status'],'SCREEN_CLEAR_NOT_QUALITY_PROOF')
        self.assertFalse(r['semantic_fidelity_independently_verified'])

    def test_unneeded_rebuttal_reframed_affirmatively(self):
        r=m.audit(payload(item(action='REFRAME', revision='本研究在共同服务下比较两种选时策略。')))
        self.assertNotIn('ESSENTIAL_SCOPE_REMOVED',codes(r))

    def test_unnecessary_defense_kept_without_reason_is_review(self):
        r=m.audit(payload(item(action='KEEP',revision='这不意味着别人完全没有研究过。')))
        self.assertIn('UNNECESSARY_DEFENSE_KEPT',codes(r))

    def test_essential_boundary_must_never_be_erased(self):
        r=m.audit(payload(item(category='ESSENTIAL_SCOPE', action='REMOVE',
             original='事件内前后变化不能等于随机干预效应.')))
        self.assertEqual(r['status'],'BLOCK_AND_REVISE')
        self.assertIn('ESSENTIAL_SCOPE_REMOVED',codes(r))

    def test_essential_correct_negative_can_remain_unchanged(self):
        line='这一关联无法证明干预因果效应。'
        r=m.audit(payload(item(category='ESSENTIAL_SCOPE',action='KEEP',original=line,revision=line)))
        self.assertEqual(r['status'],'SCREEN_CLEAR_NOT_QUALITY_PROOF')

    def test_changed_essential_boundary_with_unverified_scope_flags(self):
        r=m.audit(payload(item(category='ESSENTIAL_SCOPE',action='REFRAME',
                         revision='这里的解释仅适用于观察数据。',scope_verified=None)))
        self.assertIn('ESSENTIAL_SCOPE_UNVERIFIED',codes(r))

    def test_explicit_scope_breach_blocks(self):
        r=m.audit(payload(item(category='UNNECESSARY_DEFENSE',action='REFRAME',
                         revision='本研究首次证明该干预有效。',scope_verified=False)))
        self.assertEqual(r['status'],'BLOCK_AND_REVISE')

    def test_real_misreading_clarification_removal_requires_review(self):
        r=m.audit(payload(item(category='REAL_MISREADING_CLARIFICATION',action='REMOVE',
                         original='两组均使用相同AI服务。')))
        self.assertIn('CLARIFICATION_REMOVED',codes(r))

    def test_clear_paragraph_edit_requires_justification(self):
        r=m.audit(payload(item(category='ALREADY_CLEAR',action='REFRAME',
                         original='两组使用相同AI服务。',revision='所有两组都共同使用AI支持。')))
        self.assertIn('UNNECESSARY_EDIT_CANDIDATE',codes(r))

    def test_unaudited_locks_cannot_be_called_pass(self):
        r=m.audit(payload(item(),locks={'fact':None,'comparison':True,'design':True,'scope':True}))
        self.assertIn('LOCK_UNVERIFIED_FACT',codes(r))
        self.assertEqual(r['status'],'REVIEW_REQUIRED')

    def test_bool_types_strict(self):
        with self.assertRaises(ValueError):m.audit(payload(item(),locks={'fact':1}))
        with self.assertRaises(ValueError):m.audit(payload(item(scope_verified=1)))

    def test_missing_or_invalid_input(self):
        for obj in ({}, {'entries':[]}, {'entries':[1]}, {'entries':[item(category='invalid')]}):
            with self.assertRaises(ValueError):m.audit(obj)

    def test_cli_essential_scope_violation_exit_code_2(self):
        with tempfile.TemporaryDirectory() as d:
            inp=Path(d)/'input.json'
            out=Path(d)/'out.json'
            inp.write_text(json.dumps(payload(item(category='ESSENTIAL_SCOPE',action='REMOVE')),
                         ensure_ascii=False),encoding='utf-8')
            res=subprocess.run([sys.executable,str(ROOT/'scripts'/'defensive_writing_audit.py'),
                               str(inp),'--out-json',str(out)],capture_output=True,text=True)
            self.assertEqual(res.returncode,2,res.stderr)
            self.assertEqual(json.loads(out.read_text(encoding='utf-8'))['status'],'BLOCK_AND_REVISE')

    def test_example_cannot_prove_independent_reader_improvement(self):
        e=json.loads((ROOT/'evals'/'example_assertiveness_v17.json').read_text(encoding='utf-8'))
        r=m.audit(e)
        self.assertFalse(r['independent_reader_effect_tested'])
        self.assertNotEqual(r['status'],'SCREEN_CLEAR_NOT_QUALITY_PROOF')

    def test_ledger_cannot_claim_semantic_fidelity(self):
        r=m.audit(payload(item()))
        self.assertFalse(r['semantic_fidelity_independently_verified'])

    def test_no_blacklist_of_cannot(self):
        ref=(ROOT/'references'/'calibrated-academic-assertiveness.md').read_text(encoding='utf-8')
        self.assertIn('不等于',ref)
        self.assertIn('不能',ref)
        self.assertIn('必要',ref)


class EarlierCandidateImprovementsTests(unittest.TestCase):
    def test_uniform_length_for_mixed_language(self):
        b='运动健康干预日常记录A B C A B C.'
        r=b+'额外文字'
        self.assertLess(gain.audit({'baseline_text':b,'revision_text':r,'locks':{'fact':True,'comparison':True,'design':True}})['change_ratio'],1)
        # uniformly count non-whitespace characters, not different modes at threshold
        self.assertEqual(gain._length('中文English123'),len('中文English123'))

    def test_numeric_boolean_lock_states_rejected(self):
        payload={'baseline_text':'甲。','revision_text':'甲。','locks':{'fact':0,'comparison':True,'design':True}}
        with self.assertRaises(ValueError):gain.audit(payload)

    def test_retain_is_not_new_evidence_for_expansion(self):
        b='短时步行和情绪有关。'
        rev=b+'此外，需要列举全部异常情形和通知冲突以证明考虑全面。'*3
        ledger={'baseline_text':b,'revision_text':rev,
                'locks':{'fact':True,'comparison':True,'design':True},
                'gains':[{'id':'G1','type':'key_reasoning_bridge','priority':'IMPORTANT',
                          'action':'retain','evidence_status':'source_grounded',
                          'anchor':'原文已有','why_needed':'保留原句'}]}
        r=gain.audit(ledger)
        self.assertIn('NO_NECESSARY_GAIN_FOR_EXPANSION',{x['code'] for x in r['findings']})

    def test_reasoning_bridge_not_always_missing_source(self):
        text=(ROOT/'references'/'minimal-edit-policy.md').read_text(encoding='utf-8')
        self.assertIn('REASONING_BRIDGE',text)
        self.assertIn('缺少来源',text)

    def test_new_module_referenced_in_entry(self):
        s=(ROOT/'SKILL.md').read_text(encoding='utf-8')
        for needle in ['Calibrated Academic Assertiveness','ESSENTIAL_SCOPE','UNNECESSARY_DEFENSE',
                       'FACT LOCK','v1.7.0']:
            self.assertIn(needle,s)

    def test_new_module_files_exist(self):
        for rel in ('references/calibrated-academic-assertiveness.md',
                    'examples/11_assertiveness_without_overclaim.md',
                    'evals/CALIBRATED_ASSERTIVENESS_EVALUATION_PROTOCOL.md',
                    'evals/example_assertiveness_v17.json','scripts/defensive_writing_audit.py'):
            self.assertTrue((ROOT/rel).is_file(),rel)


if __name__=='__main__':unittest.main()
