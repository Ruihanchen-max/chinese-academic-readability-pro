"""v1.3 targeted regression, including negative controls; NOT human efficacy."""
from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


def module(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / "scripts" / (name + ".py"))
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


compare = module("compare_versions")
reader = module("prepare_reader_study")
footprint = module("edit_footprint")


class HypothesisDrift(unittest.TestCase):
    def test_new_assertion_and_negative_controls(self):
        cases = json.loads((ROOT / "evals/v13_comparison_regression.json").read_text(encoding="utf-8"))["cases"]
        self.assertGreaterEqual(len(cases), 18)
        for case in cases:
            with self.subTest(case=case["id"]):
                flag = {f["type"] for f in compare.compare_versions(case["before"], case["after"])}
                self.assertEqual("comparison_hypothesis_shift" in flag, case["expect_shift"], flag)

    def test_real_source_drift_sanitized(self):
        # Sanitized *synthetic* regression representing a failure observed in
        # a user-owned course research design; no unpublished source included.
        before = "研究将考察候选策略S*能否提供可执行、区别于基础策略A的时间安排。"
        after = "研究将考察候选策略S*能否提供可执行、优于基础策略A的时间安排。"
        self.assertIn("comparison_hypothesis_shift",
                      {f["type"] for f in compare.compare_versions(before, after)})
        self.assertNotIn("numbers_changed",
                         {f["type"] for f in compare.compare_versions(before, after)})

    def test_essential_qualifier_disappearance_is_flagged(self):
        before = "仅在本样本中，运动与焦虑评分存在关联，尚不能作因果推断。"
        after = "运动与焦虑评分存在关联，可以作因果推断。"
        flags = compare.compare_versions(before, after)
        self.assertIn("essential_qualifier_removed", {f["type"] for f in flags})
        self.assertEqual({x["cue"] for x in flags if x["type"] == "essential_qualifier_removed"},
                         {"仅在本样本", "尚不能"})

    def test_stat_comparison_operator_reversal(self):
        flags = compare.compare_versions("本研究P<0.05。", "本研究P>0.05。")
        self.assertIn("stat_comparator_changed", {f["type"] for f in flags})
        self.assertNotIn("numbers_changed", {f["type"] for f in flags})

    def test_unit_change_not_hidden_by_equal_numbers(self):
        flags = compare.compare_versions("焦虑评分12.4分，观察28天。", "焦虑评分12.4分钟，观察28周。")
        units = [f["value"] for f in flags if f["type"] == "unit_binding_changed"]
        self.assertEqual(set(units), {"12.4", "28"})
        self.assertNotIn("numbers_changed", {f["type"] for f in flags})

    def test_equivalent_units_not_falsely_flagged(self):
        flags = compare.compare_versions("研究招募60名大学生，剂量为30mg。", "研究招募60人，剂量为30毫克。")
        self.assertNotIn("unit_binding_changed", {f["type"] for f in flags})

    def test_prior_study_cannot_silently_become_current_result(self):
        flags = compare.compare_versions("已有研究证实B优于A。", "本研究证实B优于A。")
        self.assertIn("comparison_hypothesis_shift", {f["type"] for f in flags})

    def test_no_flag_for_clean_reorder_of_same_assertion(self):
        a = "策略B优于策略A。受试者共60人。"
        b = "受试者共60人。策略B优于策略A。"
        self.assertNotIn("comparison_hypothesis_shift", {f["type"] for f in compare.compare_versions(a, b)})


class SingleExposureBlindTest(unittest.TestCase):
    def setUp(self):
        self.data = {"cases": [
            {"id": "c01", "variants": {"A": "第一种写法。", "B": "第二种写法。", "C": "第三种写法。"},
             "questions": ["本段谈什么？"], "answer_key": "测试参考答案：不是正式人类评分"},
            {"id": "c02", "variants": {"A": "短的句子。", "B": "较长的句子。", "C": "另一段。"}},
        ]}

    def test_each_reader_one_variant_each_case_12_readers_balanced(self):
        public, key = reader.assign(self.data, 12, 77)
        self.assertEqual(len(public), 12)
        for code, passages in public.items():
            self.assertEqual(len(passages), 2)
            self.assertEqual({p["case_id"] for p in passages}, {"c01", "c02"})
            for p in passages:
                self.assertEqual(p["passage"], self.data["cases"][0 if p["case_id"] == "c01" else 1]["variants"]
                                 [key["key"][code][p["case_id"]]["arm"]])
        for case in ("c01", "c02"):
            arms = [key["key"][code][case]["arm"] for code in sorted(key["key"]) ]
            self.assertEqual({x: arms.count(x) for x in set(arms)}, {"A": 4, "B": 4, "C": 4})
        self.assertEqual(set(key["answers"]), {"c01"})

    def test_repeatable_for_same_seed(self):
        a, k = reader.assign(self.data, 6, 99)
        b, l = reader.assign(self.data, 6, 99)
        self.assertEqual(a, b)
        self.assertEqual(k, l)

    def test_non_multiple_three_rejected(self):
        for n in (0, 2, 4, 8, 301):
            with self.subTest(n=n), self.assertRaises(ValueError):
                reader.assign(self.data, n, 9)

    def test_private_mapping_is_outside_public_and_0600(self):
        public, key = reader.assign(self.data, 3, 11)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            folder, secret = reader.write_packets(public, key, root / "public", root / "private")
            self.assertEqual(len(list(folder.glob("reader_*.md"))), 3)
            self.assertNotIn("测试参考答案", "\n".join(x.read_text(encoding="utf8") for x in folder.iterdir()))
            self.assertEqual(secret.stat().st_mode & 0o777, 0o600)
            self.assertEqual((root / "private").stat().st_mode & 0o777, 0o700)
            self.assertEqual(len(list(folder.iterdir())), 4)
            with self.assertRaises(FileExistsError):
                reader.write_packets(public, key, folder, root / "other-private")

    def test_reject_key_directory_ancestor_of_public(self):
        public, key = reader.assign(self.data, 3)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with self.assertRaises(ValueError):
                reader.write_packets(public, key, root / "public", root)
            with self.assertRaises(ValueError):
                reader.write_packets(public, key, root / "public", root / "public" / "key")

    def test_cli_and_no_answer_leak(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            input_path = root / "input.json"
            input_path.write_text(json.dumps(self.data, ensure_ascii=False), encoding="utf8")
            cmd = [sys.executable, str(ROOT / "scripts/prepare_reader_study.py"), str(input_path),
                   str(root / "review"), "--reviewers", "6", "--private-dir", str(root / "private")]
            cp = subprocess.run(cmd, text=True, capture_output=True)
            self.assertEqual(cp.returncode, 0, cp.stderr)
            self.assertEqual(len(list((root / "review").glob("reader_*.md"))), 6)
            self.assertFalse(any("测试参考答案" in p.read_text(encoding="utf8") for p in (root / "review").iterdir()))


class EditFootprint(unittest.TestCase):
    def test_zero_edit_does_not_claim_performance(self):
        data = footprint.compare_edit_footprint("本研究拟记录七天步数。", "本研究拟记录七天步数。")
        self.assertEqual(data["han_length_ratio"], 1)
        self.assertTrue(any("KEEP" in s for s in data["review_reminders"]))
        self.assertIn("不证明可读性", data["warning"])

    def test_expanding_text_triggers_review_not_claim_of_error(self):
        old = "研究记录步数。"
        new = "研究记录步数，并在每天两个时间点进行简短的情绪调查。"
        data = footprint.compare_edit_footprint(old, new)
        self.assertGreater(data["han_length_ratio"], 1.25)
        self.assertTrue(data["review_reminders"])

    def test_full_length_manuscript_uses_bounded_similarity(self):
        before = "本研究拟分析身体活动与情绪的关联。" * 500
        after = "本研究拟分析身体活动与情绪的关联。" * 499 + "本研究拟分析步数与情绪的关联。"
        result = footprint.compare_edit_footprint(before, after)
        self.assertTrue(result["similarity_sampled_first_last"])
        self.assertTrue(any("长文" in x for x in result["review_reminders"]))

    def test_cli_json(self):
        with tempfile.TemporaryDirectory() as td:
            a, b = Path(td) / "a.md", Path(td) / "b.md"
            a.write_text("运动与情绪存在关联。", encoding="utf8")
            b.write_text("本研究仅观察到运动与情绪之间的关联。", encoding="utf8")
            p = subprocess.run([sys.executable, str(ROOT / "scripts/edit_footprint.py"), str(a), str(b), "--format", "json"],
                               text=True, capture_output=True)
            self.assertEqual(p.returncode, 0)
            self.assertIn("han_length_ratio", json.loads(p.stdout))


if __name__ == "__main__":
    unittest.main()
