"""Depth-control checks: advisory safeguards, not a human readability assessment."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "depth_control_audit.py"
spec = importlib.util.spec_from_file_location("depth_control_audit", SCRIPT)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class DepthControlV15(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.source = self._file("source.txt", "第一章 研究背景\n\n研究一拟招募40人开展连续观察，研究二拟另招60人随机试点。\n\n进行50次多重插补，使用Barnard–Rubin自由度。\n\n第七章 研究可行性与伦理。")
        self.clean = self._file("clean.txt", "第一章 研究背景\n\n研究一拟招募40人开展连续观察，研究二拟另招60人随机试点。\n\n采用基线调整估计组间差，并开展缺失敏感性分析。\n\n第七章 研究可行性与伦理。")
        self.lock = self.root / "core.json"
        self.lock.write_text(json.dumps({"locks": [
            {"id": "n1", "label": "研究一40人", "required_groups": [["研究一"], ["40人", "四十人"]]},
            {"id": "n2", "label": "研究二60人", "required_groups": [["研究二"], ["60人"]]},
        ]}, ensure_ascii=False), encoding="utf-8")

    def tearDown(self):
        self.tmp.cleanup()

    def _file(self, name, content):
        file = self.root / name
        file.write_text(content, encoding="utf-8")
        return file

    def test_all_six_profiles(self):
        self.assertEqual(len(module.PROFILES), 6)

    def test_course_detects_implementation_detail(self):
        result = module.audit(self.source, "course-preproposal")
        self.assertIn("imputation_implementation", result["engineering_detail_signals"])
        self.assertEqual(result["possible_detail_paragraphs"][0]["decision"], "REVIEW_ONLY")

    def test_not_an_automatic_deletion(self):
        result = module.audit(self.source, "course-preproposal")
        self.assertEqual(result["possible_detail_paragraphs"][0]["possible_tier"], "C?")
        self.assertIn("不能自动删除", result["possible_detail_paragraphs"][0]["caution"])

    def test_protocol_does_not_recommend_deletion(self):
        result = module.audit(self.source, "formal-protocol")
        self.assertEqual(result["possible_detail_paragraphs"][0]["decision"], "PRESERVE_UNTIL_METHOD_REVIEW")

    def test_manuscript_preserves_statistical_detail(self):
        result = module.audit(self.source, "empirical-manuscript")
        self.assertFalse(any(x["decision"] == "REVIEW_ONLY" for x in result["possible_detail_paragraphs"]))

    def test_clean_has_fewer_detail_flags(self):
        before = module.audit(self.source, "course-preproposal")
        after = module.audit(self.clean, "course-preproposal")
        self.assertGreater(len(before["possible_detail_paragraphs"]), len(after["possible_detail_paragraphs"]))

    def test_core_terms_still_present(self):
        result = module.audit(self.clean, "course-preproposal", self.lock, self.source)
        self.assertEqual({x["status"] for x in result["core_lock_findings"]}, {"ANCHOR_PRESENT_NEEDS_SEMANTIC_REVIEW"})
        self.assertEqual(result["gate"], "UNVERIFIED")

    def test_missing_core_stops_review(self):
        changed = self._file("changed.txt", "研究一拟招募40人。研究二将来决定人数。")
        result = module.audit(changed, "course-preproposal", self.lock, self.source)
        self.assertEqual(result["gate"], "STOP_AND_REVIEW")
        self.assertEqual(result["core_lock_findings"][1]["status"], "STOP_AND_REVIEW")

    def test_paraphrase_is_not_autoconvicted(self):
        changed = self._file("paraphrase.txt", "拟开展两阶段研究，第二阶段约六十名学生。")
        result = module.audit(changed, "course-preproposal", self.lock)
        self.assertEqual(result["gate"], "UNVERIFIED")
        self.assertIn("REVIEW", result["core_lock_findings"][1]["status"])

    def test_missing_lock_schema_rejected(self):
        invalid = self._file("invalid.json", "{}")
        with self.assertRaises(ValueError):
            module.load_core_lock(invalid)

    def test_empty_lock_alternatives_rejected(self):
        invalid = self._file("invalid.json", '{"locks":[{"id":"bad","required_groups":[[]]}]}')
        with self.assertRaises(ValueError):
            module.load_core_lock(invalid)

    def test_compact_profile_never_claims_pass(self):
        result = module.audit(self.clean, "course-preproposal")
        self.assertEqual(result["gate"], "UNVERIFIED")
        self.assertTrue(result["manual_scholarly_review_required"])

    def test_different_article_types_are_not_all_preproposals(self):
        self.assertFalse(module.PROFILES["formal-protocol"]["detail_review"])
        self.assertFalse(module.PROFILES["review-paper"]["detail_review"])
        self.assertTrue(module.PROFILES["grant-proposal"]["detail_review"])

    def test_bibliography_not_scanned(self):
        p = self._file("refs.txt", "研究问题很明确。\n\n参考文献\n\n参考资料：采用50次多重插补")
        r = module.audit(p, "course-preproposal")
        self.assertFalse(r["engineering_detail_signals"])

    def test_acronym_does_not_mean_causal_error(self):
        p = self._file("neutral.txt", "主要结局为日步数。采用EMA测量当下情绪。")
        r = module.audit(p, "course-preproposal")
        self.assertEqual(r["possible_detail_paragraphs"], [])

    def test_text_markdown_supported(self):
        t = self._file("x.md", "一、背景\n\n研究目的清楚。")
        self.assertEqual(len(module.read_paragraphs(t)), 2)

    def test_pdf_not_supported(self):
        p = self.root / "x.pdf"
        p.write_bytes(b"%PDF-1.7")
        with self.assertRaises(ValueError):
            module.read_paragraphs(p)

    def test_docx_xml_extraction_with_table(self):
        p = self.root / "mini.docx"
        xml = ('<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
               '<w:body><w:p><w:r><w:t>研究一拟招募</w:t></w:r><w:r><w:t>40人</w:t></w:r></w:p>'
               '<w:tbl><w:tr><w:tc><w:p><w:r><w:t>采用50次多重插补</w:t></w:r></w:p>'
               '</w:tc></w:tr></w:tbl></w:body></w:document>')
        with ZipFile(p, 'w') as z:
            z.writestr('word/document.xml', xml)
        self.assertEqual(module.read_paragraphs(p), ["研究一拟招募40人", "采用50次多重插补"])
        self.assertEqual(len(module.audit(p, "course-preproposal")["possible_detail_paragraphs"]), 1)

    def test_require_explicit_profile(self):
        r = subprocess.run([sys.executable, str(SCRIPT), str(self.clean)],
                           capture_output=True, text=True)
        self.assertNotEqual(r.returncode, 0)

    def test_cli_json_artifact(self):
        dest = self.root / "outputs" / "audit.json"
        r = subprocess.run([sys.executable, str(SCRIPT), str(self.clean),
                            "--profile", "course-preproposal", "--out-json", str(dest)],
                           capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertTrue(dest.exists())
        self.assertEqual(json.loads(dest.read_text(encoding="utf-8"))["profile"], "course-preproposal")

    def test_cli_rejects_unknown_profile(self):
        r = subprocess.run([sys.executable, str(SCRIPT), str(self.clean),
                            "--profile", "university-memo"], capture_output=True, text=True)
        self.assertNotEqual(r.returncode, 0)

    def test_reference_modules_in_package(self):
        for name in ['writing-depth-profiles.md', 'content-tier-decision.md',
                     'design-lock-v15.md', 'course-preproposal-editing.md']:
            self.assertTrue((ROOT/'references'/name).exists())

    def test_main_skill_includes_depth_mode(self):
        skill = (ROOT/'SKILL.md').read_text(encoding='utf-8')
        self.assertIn('depth-control', skill)
        self.assertIn('DEPTH LOCK', skill)

    def test_no_fake_independent_reader_result(self):
        skill = (ROOT/'SKILL.md').read_text(encoding='utf-8')
        self.assertIn('不可声称真人', skill)

    def test_technical_detection_is_not_a_quality_grade(self):
        result = module.audit(self.source, "course-preproposal")
        self.assertEqual(result["result_type"], "ADVISORY_NOT_PERFORMANCE_SCORE")


if __name__ == "__main__":
    unittest.main()
