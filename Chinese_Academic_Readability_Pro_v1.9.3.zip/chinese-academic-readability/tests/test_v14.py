"""v1.4 artifact QA regressions: actual PDF fixtures, no OCR or fake human reviews."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from artifact_fidelity import (norm, ngram_coverage, anchor_check, check_fidelity,
                               docx_strings, paragraph_gaps)
from render_document import convert_docx
from visual_audit import (toc_verify, create_review_template, apply_review,
                          inspect_visual, pixel_glyph_candidates)
from submission_gate import combine


def make_docx(path: Path, *, toc_page: int = 2, formula: bool = False):
    from docx import Document
    from docx.enum.style import WD_STYLE_TYPE
    from docx.oxml import OxmlElement
    document = Document()
    style = document.styles.add_style('TOC 1', WD_STYLE_TYPE.PARAGRAPH)
    p = document.add_paragraph(style=style)
    p.add_run(f'第二章 研究计划\t{toc_page}')
    document.add_paragraph('第二章 研究计划')
    document.add_paragraph('策略C根据已确认的时间窗口选择建议时段，再取该时段最早的合格时间；H相同时直接选择时间最早者。')
    table = document.add_table(rows=2, cols=2)
    table.cell(0, 0).text = '基础组'
    table.cell(0, 1).text = '实验组'
    table.cell(1, 0).text = '汇总、质控、筛选可行窗口，按A确定并填入建议时间。'
    table.cell(1, 1).text = '数据不足时回退基础策略A。'
    if formula:
        math = OxmlElement('m:oMath')
        document.paragraphs[-1]._p.append(math)
    document.save(path)


def make_pdf(path: Path, *, missing: bool = False, missing_table: bool = False,
             second_page_heading: bool = True, invisible: bool = False):
    import fitz
    doc = fitz.open()
    p1 = doc.new_page()
    p1.insert_text((60, 70), '目录', fontname='china-s', fontsize=15)
    p2 = doc.new_page()
    if second_page_heading:
        p2.insert_text((60, 65), '第二章 研究计划', fontname='china-s', fontsize=16)
    main = '策略C根据已确认的时间窗口选择建议时段，再取该时段最早的合格时间；H相同时直接选择时间最早者。'
    if missing:
        main = main.replace('该时段', '')
    p2.insert_text((60, 100), main, fontname='china-s', fontsize=11)
    cell = '汇总、质控、筛选可行窗口，按A确定并填入建议时间。'
    if missing_table:
        cell = cell.replace('汇总、质控、筛选', '、控、')
    p2.insert_text((60, 140), cell, fontname='china-s', fontsize=11)
    if invisible:
        p2.insert_text((60, 180), '这是一段不可见文字', fontname='china-s', fontsize=13, color=(1, 1, 1))
    doc.save(path)
    doc.close()


class TestV14(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.docx = self.root / 'original.docx'
        self.pdf = self.root / 'correct.pdf'
        make_docx(self.docx)
        make_pdf(self.pdf)
        self.anchor = [{'id': 'p2', 'source_text': '再取该时段最早的合格时间', 'pdf_expected_page': 2}]

    def render_images(self, pdf=None):
        import fitz
        pdf = pdf or self.pdf
        folder = self.root / 'pages'
        folder.mkdir(exist_ok=True)
        with fitz.open(pdf) as doc:
            for i, page in enumerate(doc, 1):
                page.get_pixmap(matrix=fitz.Matrix(2, 2)).save(folder / f'page-{i:03}.png')
        return folder

    def test_01_normalization_cjk_ascii(self):
        self.assertEqual(norm(' １２５人 \u2060 '), '125人')

    def test_02_ngram_coverage_exact(self):
        self.assertEqual(ngram_coverage('文字没有丢失', '原文文字没有丢失并且完整'), 1.0)

    def test_03_anchor_present(self):
        self.assertEqual(check_fidelity(self.docx, self.pdf, self.anchor)['anchors'][0]['status'], 'PASS')

    def test_04_missing_chinese_anchor_fails(self):
        bad = self.root / 'bad.pdf'
        make_pdf(bad, missing=True)
        result = check_fidelity(self.docx, bad, self.anchor)
        self.assertEqual(result['status'], 'FAIL')
        self.assertEqual(result['anchors'][0]['status'], 'FAIL')

    def test_05_missing_table_anchor_fails(self):
        bad = self.root / 'bad.pdf'
        make_pdf(bad, missing_table=True)
        anchor = [{'id': 'table', 'source_text': '汇总、质控、筛选可行窗口', 'pdf_expected_page': 2}]
        self.assertEqual(check_fidelity(self.docx, bad, anchor)['status'], 'FAIL')

    def test_06_unknown_source_anchor_unverified_not_false_fail(self):
        other = [{'id': 'unknown', 'source_text': '不存在的参照文本', 'pdf_expected_page': 2}]
        self.assertEqual(check_fidelity(self.docx, self.pdf, other)['anchors'][0]['status'], 'UNVERIFIED')

    def test_07_missing_gaps_detection(self):
        source = norm('策略C根据已确认的时间窗口选择建议时段，再取该时段最早的合格时间；H相同时直接选择时间最早者。')
        observed = source.replace('该时段', '')
        self.assertTrue(paragraph_gaps(source, [observed]))

    def test_08_docx_inventory_and_table(self):
        _, inv = docx_strings(self.docx)
        self.assertEqual(inv['docx_tables'], 1)
        self.assertEqual(inv['docx_toc_entries'], 1)

    def test_09_toc_correct(self):
        import fitz
        with fitz.open(self.pdf) as d:
            toc = toc_verify(self.docx, [p.get_text() for p in d])
        self.assertEqual(toc[0]['status'], 'PASS')

    def test_10_toc_mismatch_detected(self):
        import fitz
        bad_docx = self.root / 'wrong_toc.docx'
        make_docx(bad_docx, toc_page=1)
        with fitz.open(self.pdf) as d:
            toc = toc_verify(bad_docx, [p.get_text() for p in d])
        self.assertEqual(toc[0]['status'], 'FAIL')

    def test_11_manual_review_missing_unverified(self):
        images = self.render_images()
        result = inspect_visual(self.docx, self.pdf, images, scan_ink=False)
        self.assertEqual(result['status'], 'UNVERIFIED')
        self.assertEqual(result['images_verified_present'], 2)

    def test_12_signed_every_page_passes_visual(self):
        images = self.render_images()
        review_path = self.root / 'review.json'
        review = create_review_template(images, 2, review_path)
        review['reviewer'] = 'independent-reviewer-1'
        for rec in review['page_images']:
            rec['status'] = 'PASS'
            for check in rec['checks']:
                rec['checks'][check] = 'PASS'
        review['page_images'][0]['notes'] = 'Directory page intentionally contains only a heading'
        review_path.write_text(json.dumps(review), encoding='utf-8')
        result = inspect_visual(self.docx, self.pdf, images, review_path, scan_ink=False)
        self.assertEqual(result['review_status'], 'PASS')
        self.assertEqual(result['status'], 'PASS')

    def test_13_incomplete_review_is_unverified(self):
        images = self.render_images()
        review_path = self.root / 'review.json'
        review = create_review_template(images, 2, review_path)
        review['reviewer'] = 'independent-reviewer-1'
        review['page_images'][0]['status'] = 'PASS'
        for check in review['page_images'][0]['checks']:
            review['page_images'][0]['checks'][check] = 'PASS'
        review_path.write_text(json.dumps(review), encoding='utf-8')
        self.assertEqual(apply_review(review_path, images, 2)[0], 'UNVERIFIED')

    def test_14_review_fails_when_image_replaced(self):
        images = self.render_images()
        review_path = self.root / 'review.json'
        review = create_review_template(images, 2, review_path)
        review['reviewer'] = 'independent-reviewer-1'
        for rec in review['page_images']:
            rec['status'] = 'PASS'
            for check in rec['checks']:
                rec['checks'][check] = 'PASS'
        review_path.write_text(json.dumps(review), encoding='utf-8')
        (images / 'page-001.png').write_bytes(b'stale-image-after-edit')
        self.assertEqual(apply_review(review_path, images, 2)[0], 'UNVERIFIED')

    def test_15_reviewer_flags_fail(self):
        images = self.render_images()
        review_path = self.root / 'review.json'
        review = create_review_template(images, 2, review_path)
        review['reviewer'] = 'independent-reviewer-1'
        for rec in review['page_images']:
            rec['status'] = 'PASS'
            for check in rec['checks']:
                rec['checks'][check] = 'PASS'
        review['page_images'][1]['status'] = 'FAIL'
        review['page_images'][1]['notes'] = '缺字'
        review_path.write_text(json.dumps(review), encoding='utf-8')
        self.assertEqual(apply_review(review_path, images, 2)[0], 'FAIL')

    def test_16_formula_inventory_requires_manual(self):
        docx = self.root / 'formula.docx'
        make_docx(docx, formula=True)
        result = check_fidelity(docx, self.pdf)
        self.assertGreater(result['source_inventory']['native_omath_nodes'], 0)
        self.assertTrue(result['math_visual_review_pending'])
        self.assertEqual(result['status'], 'UNVERIFIED')

    def test_17_adjudication_hash_mismatch_refused(self):
        bad = {'docx_sha256': '0'*64, 'pdf_sha256': '1'*64, 'reviewer': 'qa',
               'resolved_suspect_locations': ['table:1/row:2/cell:1'],
               'native_math_visual_reviewed': True}
        result = check_fidelity(self.docx, self.pdf, adjudications=bad)
        self.assertFalse(result['adjudication_matches_source_files'])

    def test_18_word_engine_unavailable_not_false_success(self):
        import platform
        if platform.system() == 'Windows':
            self.skipTest('Windows Word availability depends on installed Office')
        report = convert_docx(self.docx, self.root / 'word_run', engine='word')
        self.assertEqual(report['status'], 'UNVERIFIED')
        self.assertIsNone(report['pdf_path'])

    def test_19_no_docx_fails_to_claim_pass(self):
        result = convert_docx(self.root / 'missing.docx', self.root / 'out')
        self.assertEqual(result['status'], 'UNVERIFIED')

    def test_20_gate_precedence(self):
        self.assertEqual(combine(['PASS','FAIL','UNVERIFIED']), 'FAIL')
        self.assertEqual(combine(['PASS','UNVERIFIED']), 'UNVERIFIED')
        self.assertEqual(combine(['PASS','PASS']), 'PASS')

    def test_21_hidden_text_ink_check_screening(self):
        import fitz
        invisible = self.root / 'invisible.pdf'
        make_pdf(invisible, invisible=True)
        image_dir = self.render_images(invisible)
        with fitz.open(invisible) as doc:
            res = pixel_glyph_candidates(doc[1], image_dir / 'page-002.png')
        self.assertGreater(res['glyphs_checked'], 10)
        self.assertTrue(res['possible_inkless_cjk'])

    def test_22_all_pages_rendered(self):
        images = self.render_images()
        self.assertTrue((images / 'page-001.png').is_file())
        self.assertTrue((images / 'page-002.png').is_file())

    def test_23_wrong_page_anchor_fails(self):
        wrong = [{'id': 'wrong_page', 'source_text': '再取该时段最早的合格时间', 'pdf_expected_page': 1}]
        self.assertEqual(check_fidelity(self.docx, self.pdf, wrong)['status'], 'FAIL')

    def test_24_unsupported_engine_rejected(self):
        result = convert_docx(self.docx, self.root / 'bad_engine', engine='imaginary')
        self.assertEqual(result['status'], 'FAIL')


    def test_25_review_checklist_required(self):
        images = self.render_images()
        review_path = self.root / 'review.json'
        review = create_review_template(images, 2, review_path)
        review['reviewer'] = 'reviewer-1'
        for rec in review['page_images']:
            rec['status'] = 'PASS'
        review_path.write_text(json.dumps(review), encoding='utf-8')
        self.assertEqual(apply_review(review_path, images, 2)[0], 'UNVERIFIED')

    def test_26_reuse_rejects_stale_pdf(self):
        from submission_gate import run_gate
        out = self.root / 'existing'
        out.mkdir()
        image_dir = self.render_images()
        (out / 'pages').mkdir()
        for img in image_dir.glob('*.png'):
            (out/'pages'/img.name).write_bytes(img.read_bytes())
        manifest = {'status': 'PASS', 'docx_sha256': hashlib.sha256(self.docx.read_bytes()).hexdigest(),
                    'pdf_sha256': 'bad-hash', 'pdf_path': str(self.pdf),
                    'pages': 2, 'page_images': [str(x) for x in (out/'pages').glob('*.png')],
                    'page_image_sha256': {'1': hashlib.sha256((out/'pages'/'page-001.png').read_bytes()).hexdigest(),
                                          '2': hashlib.sha256((out/'pages'/'page-002.png').read_bytes()).hexdigest()}}
        (out / 'render_manifest.json').write_text(json.dumps(manifest), encoding='utf-8')
        self.assertEqual(run_gate(self.docx, out, reuse_render=True)['status'], 'FAIL')

if __name__ == '__main__':
    unittest.main()
