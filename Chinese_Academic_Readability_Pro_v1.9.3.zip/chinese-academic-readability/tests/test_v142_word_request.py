"""DOCX font embedding request is only metadata; never implies actual font transfer."""
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
from lxml import etree
from docx import Document
import sys
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from prepare_word_fonts import prepare_docx

class TestFontRequest(unittest.TestCase):
    def test_01_metadata_flag_only(self):
        with TemporaryDirectory() as d:
            root=Path(d);a=root/'original.docx';b=root/'prepared.docx';doc=Document();doc.add_paragraph('论文内容：123人、样本量');doc.save(a)
            r=prepare_docx(a,b)
            self.assertEqual(r['status'],'PASS')
            self.assertEqual(r['changed_ooxml_parts'],['word/settings.xml'])
            self.assertFalse(r['fonts_embedded'])
            with ZipFile(a) as x,ZipFile(b) as y:
                self.assertEqual(x.read('word/document.xml'),y.read('word/document.xml'))
                settings=etree.fromstring(y.read('word/settings.xml'))
                ns='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
                for tag in ('embedTrueTypeFonts','saveSubsetFonts'):
                    self.assertEqual(settings.find(ns+tag).get(ns+'val'),'1')
                self.assertFalse(any(n.startswith('word/fonts/') for n in y.namelist()))

    def test_02_refuses_overwrite(self):
        with TemporaryDirectory() as d:
            a=Path(d)/'same.docx';Document().save(a)
            self.assertEqual(prepare_docx(a,a)['status'],'FAIL')

if __name__=='__main__':unittest.main()
