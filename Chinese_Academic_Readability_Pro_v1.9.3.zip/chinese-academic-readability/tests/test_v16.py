"""v1.6 intellectual-depth / scientific priority gates, deterministic regressions."""
from __future__ import annotations

import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "intellectual_depth_audit.py"

spec = importlib.util.spec_from_file_location("v16_depth", SCRIPT)
module = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(module)


def base():
    return {
        "profile": "course-preproposal",
        "core_arguments": [{
            "id": "Q1", "kind": "central_comparison", "state": "planned",
            "claim": "拟比较不同选时规则对日步数的初步影响",
            "question": "安排实际步行时间是否不同于提醒送达时间？",
            "evidence": [{"anchor": "研究设计原稿第3章", "status": "verified"}],
            "reasoning": "控制共同服务可更清楚地区分选时规则",
            "rival_explanation": "既有活动习惯也可能与建议执行相关",
            "boundary": "仅为拟开展的试点，不说明机制已证实",
        }],
        "considerations": [
            {"id": "C1", "issue": "共同AI服务的比较条件", "priority": "CRITICAL",
             "action": "include_body", "reason": "决定试点比较"},
            {"id": "C2", "issue": "逐分钟通知异常编码", "priority": "OPTIONAL",
             "action": "defer_protocol", "reason": "初步开题不必穷举实施异常"},
        ],
        "study_locks": [{"id": "group-comparison", "preserved": True}],
    }


def codes(r):
    return [x["code"] for x in r["blocking_items"] + r["review_items"]]


class IntellectualDepthV16(unittest.TestCase):
    def test_good_structure_is_ready_only_for_human(self):
        r = module.audit(base())
        self.assertEqual(r["status"], "SCOPED_STOP_READY_FOR_HUMAN_REVIEW")
        self.assertFalse(r["source_claims_verified"])
        self.assertFalse(r["independent_reader_effect_tested"])

    def test_empty_input_rejected(self):
        with self.assertRaises(ValueError):
            module.audit({})

    def test_unknown_profile_rejected(self):
        b = base(); b["profile"] = "casual-chat"
        with self.assertRaises(ValueError):
            module.audit(b)

    def test_no_core_arguments_blocks(self):
        b = base(); b["core_arguments"] = []
        self.assertIn("NO_CORE_ARGUMENT", codes(module.audit(b)))

    def test_four_core_claims_is_review_not_forbidden(self):
        b = base(); b["core_arguments"] = []
        for i in range(4):
            a = copy.deepcopy(base()["core_arguments"][0]); a["id"] = f"Q{i}"
            b["core_arguments"].append(a)
        r = module.audit(b)
        self.assertIn("TOO_MANY_CORE_ARGUMENTS", codes(r))
        self.assertEqual(r["status"], "REVIEW_OPEN_ITEMS")

    def test_missing_question(self):
        b = base(); b["core_arguments"][0].pop("question")
        self.assertIn("MISSING_QUESTION", codes(module.audit(b)))

    def test_missing_reasoning(self):
        b = base(); b["core_arguments"][0]["reasoning"] = ""
        self.assertIn("MISSING_REASONING", codes(module.audit(b)))

    def test_missing_boundary(self):
        b = base(); b["core_arguments"][0].pop("boundary")
        self.assertIn("MISSING_BOUNDARY", codes(module.audit(b)))

    def test_missing_claim(self):
        b = base(); b["core_arguments"][0]["claim"] = " "
        self.assertIn("MISSING_CLAIM", codes(module.audit(b)))

    def test_missing_evidence_anchor(self):
        b = base(); b["core_arguments"][0]["evidence"] = []
        self.assertIn("MISSING_EVIDENCE_ANCHOR", codes(module.audit(b)))

    def test_empty_anchor(self):
        b = base(); b["core_arguments"][0]["evidence"][0]["anchor"] = ""
        self.assertIn("EMPTY_EVIDENCE_ANCHOR", codes(module.audit(b)))

    def test_needs_source_blocks(self):
        b = base(); b["core_arguments"][0]["evidence"][0]["status"] = "needs_source"
        self.assertIn("UNSOURCED_CLAIM", codes(module.audit(b)))

    def test_user_source_is_not_independently_verified(self):
        b = base(); b["core_arguments"][0]["evidence"][0]["status"] = "provided_not_verified"
        r = module.audit(b)
        self.assertIn("SOURCE_NOT_INDEPENDENTLY_VERIFIED", codes(r))
        self.assertEqual(r["status"], "REVIEW_OPEN_ITEMS")

    def test_invalid_evidence_status_rejected(self):
        b = base(); b["core_arguments"][0]["evidence"][0]["status"] = "hallucinated"
        with self.assertRaises(ValueError):
            module.audit(b)

    def test_rival_review_missing_for_core_comparison(self):
        b = base(); b["core_arguments"][0].pop("rival_explanation")
        self.assertIn("RIVAL_REVIEW_MISSING", codes(module.audit(b)))

    def test_rival_nonapplicability_can_be_marked(self):
        b = base(); b["core_arguments"][0].pop("rival_explanation")
        b["core_arguments"][0]["why_rival_not_applicable"] = "此处仅记录预设比较对象，不提出机制"
        self.assertNotIn("RIVAL_REVIEW_MISSING", codes(module.audit(b)))

    def test_descriptive_claim_not_forced_to_add_rival(self):
        b = base(); b["core_arguments"][0]["kind"] = "descriptive_scope"
        b["core_arguments"][0].pop("rival_explanation")
        self.assertNotIn("RIVAL_REVIEW_MISSING", codes(module.audit(b)))

    def test_mechanism_requires_testability_limit(self):
        b = base(); b["core_arguments"][0]["kind"] = "mechanism"
        self.assertIn("CAUSAL_LIMIT_MISSING", codes(module.audit(b)))
        b["core_arguments"][0]["testability_limit"] = "试点不能识别中介因果"
        self.assertNotIn("CAUSAL_LIMIT_MISSING", codes(module.audit(b)))

    def test_hypothesis_cannot_claim_proven_effect(self):
        b = base(); b["core_arguments"][0]["state"] = "hypothesis"
        b["core_arguments"][0]["claim"] = "本研究已经证实AI必然改善心理健康"
        self.assertIn("UNQUALIFIED_FUTURE_EFFECT", codes(module.audit(b)))

    def test_planned_qualified_statement_allowed(self):
        b = base(); b["core_arguments"][0]["claim"] = "研究拟评价策略对日步数的初步效果"
        self.assertNotIn("UNQUALIFIED_FUTURE_EFFECT", codes(module.audit(b)))

    def test_defer_optional_detail_is_not_a_problem(self):
        r = module.audit(base())
        self.assertNotIn("POSSIBLE_SCOPE_CREEP", codes(r))

    def test_optional_body_expansion_warns(self):
        b = base(); b["considerations"][1]["action"] = "include_body"
        self.assertIn("POSSIBLE_SCOPE_CREEP", codes(module.audit(b)))

    def test_critical_issue_cannot_be_omitted(self):
        b = base(); b["considerations"][0]["action"] = "omit"
        self.assertIn("CRITICAL_ISSUE_DEFERRED", codes(module.audit(b)))

    def test_critical_issue_cannot_be_deferred_as_protocol(self):
        b = base(); b["considerations"][0]["action"] = "defer_protocol"
        self.assertIn("CRITICAL_ISSUE_DEFERRED", codes(module.audit(b)))

    def test_critical_source_unresolved_blocks(self):
        b = base(); b["considerations"][0]["action"] = "needs_source"
        self.assertIn("CRITICAL_EVIDENCE_UNRESOLVED", codes(module.audit(b)))

    def test_important_omission_requires_review(self):
        b = base(); b["considerations"][0]["priority"] = "IMPORTANT"
        b["considerations"][0]["action"] = "omit"
        self.assertIn("IMPORTANT_OMISSION_REVIEW", codes(module.audit(b)))

    def test_design_lock_broken_blocks(self):
        b = base(); b["study_locks"][0]["preserved"] = False
        self.assertIn("CORE_DESIGN_LOCK_BROKEN", codes(module.audit(b)))

    def test_unverified_design_lock_warns(self):
        b = base(); b["study_locks"][0]["preserved"] = None
        self.assertIn("CORE_DESIGN_LOCK_UNVERIFIED", codes(module.audit(b)))

    def test_no_design_locks_cannot_claim_fidelity(self):
        b = base(); b["study_locks"] = []
        self.assertIn("NO_DESIGN_LOCK_EVIDENCE", codes(module.audit(b)))

    def test_duplicate_claim_id_rejected(self):
        b = base(); b["core_arguments"].append(copy.deepcopy(b["core_arguments"][0]))
        with self.assertRaises(ValueError):
            module.audit(b)

    def test_duplicate_consideration_id_rejected(self):
        b = base(); b["considerations"].append(copy.deepcopy(b["considerations"][0]))
        with self.assertRaises(ValueError):
            module.audit(b)

    def test_bad_priority_and_action_rejected(self):
        b = base(); b["considerations"][1]["priority"] = "EVERYTHING"
        with self.assertRaises(ValueError):
            module.audit(b)
        b = base(); b["considerations"][1]["action"] = "endlessly_expand"
        with self.assertRaises(ValueError):
            module.audit(b)

    def test_example_is_advisory_not_fake_performance(self):
        data = json.loads((ROOT / "evals" / "example_intellectual_depth_v16.json").read_text(encoding="utf-8"))
        r = module.audit(data)
        self.assertEqual(r["status"], "REVIEW_OPEN_ITEMS")
        self.assertFalse(r["independent_reader_effect_tested"])

    def test_cli_output_status_and_code(self):
        b = base()
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            src, out = td / "m.json", td / "out.json"
            src.write_text(json.dumps(b, ensure_ascii=False), encoding="utf-8")
            r = subprocess.run([sys.executable, str(SCRIPT), str(src), "--out-json", str(out)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr)
            self.assertEqual(json.loads(out.read_text(encoding="utf-8"))["status"], "SCOPED_STOP_READY_FOR_HUMAN_REVIEW")
            b["study_locks"][0]["preserved"] = False
            src.write_text(json.dumps(b, ensure_ascii=False), encoding="utf-8")
            r = subprocess.run([sys.executable, str(SCRIPT), str(src)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 2)

    def test_cli_bad_json_fails(self):
        with tempfile.TemporaryDirectory() as td:
            src = Path(td) / "bad.json"; src.write_text("{bad", encoding="utf-8")
            r = subprocess.run([sys.executable, str(SCRIPT), str(src)], capture_output=True, text=True)
            self.assertNotEqual(r.returncode, 0)

    def test_v16_documentation_present(self):
        required = ["references/intellectual-depth-gate.md", "references/scientific-priority-stop-rule.md",
                    "examples/09_intellectual_depth_without_perfectionism.md",
                    "evals/INTELLECTUAL_DEPTH_EVALUATION_PROTOCOL.md"]
        for path in required:
            self.assertTrue((ROOT / path).is_file(), path)
        s = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        for phrase in ["intellectual-depth", "INTELLECTUAL DEPTH GATE", "STOP RULE", "FACT LOCK", "COMPARISON LOCK"]:
            self.assertIn(phrase, s)

    def test_non_course_protocol_cannot_use_same_deletion_rule(self):
        content = (ROOT / "references" / "scientific-priority-stop-rule.md").read_text(encoding="utf-8")
        self.assertIn("伦理", content)
        self.assertIn("正式", content)
        self.assertIn("CRITICAL", content)


if __name__ == "__main__":
    unittest.main()
