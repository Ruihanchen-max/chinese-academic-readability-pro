"""Offline tests only. Do not mistake them for LLM behavior evaluation."""
from __future__ import annotations

import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_script(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / "scripts" / f"{name}.py")
    module = importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(module)
    return module


validator = load_script("validate_skill")
auditor = load_script("audit_text")


class PackageTests(unittest.TestCase):
    def test_structure_and_links(self):
        self.assertEqual(validator.validate(ROOT), [])

    def test_reject_wrong_folder_name(self):
        with tempfile.TemporaryDirectory() as d:
            folder = Path(d) / "wrong-name"
            folder.mkdir()
            (folder / "SKILL.md").write_text((ROOT / "SKILL.md").read_text(encoding="utf-8"), encoding="utf-8")
            self.assertTrue(any("must match folder" in err for err in validator.validate(folder)))

    def test_reject_broken_local_links(self):
        with tempfile.TemporaryDirectory() as d:
            folder = Path(d) / "chinese-academic-readability"
            folder.mkdir()
            (folder / "SKILL.md").write_text((ROOT / "SKILL.md").read_text(encoding="utf-8") + "\n[broken](missing.md)\n", encoding="utf-8")
            self.assertTrue(any("Broken local link" in err for err in validator.validate(folder)))

    def test_scenarios_are_distinct(self):
        items = json.loads((ROOT / "evals/scenarios.json").read_text(encoding="utf-8"))
        self.assertGreaterEqual(len(items), 9)
        self.assertEqual(len({item["id"] for item in items}), len(items))
        for item in items:
            self.assertTrue(all(item.get(k) for k in ("id", "type", "mode", "input", "expected", "hard_fail")))

    def test_examples_explicitly_hypothetical(self):
        for example in (ROOT / "examples").glob("*.md"):
            text = example.read_text(encoding="utf-8")
            self.assertTrue(any(term in text for term in ("虚构", "练习")), example.name)

    def test_skill_has_critical_stages(self):
        text = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        for phrase in ("FACT LOCK", "陌生读者测试", "事实保真", "只读", "零修改"):
            self.assertIn(phrase, text)


class AuditTests(unittest.TestCase):
    def test_flags_abstract_phrases(self):
        issues = auditor.audit_text("这一多维协同作用机制具有重要的理论意义和实践价值。")
        self.assertIn("abstract_phrase", {i["type"] for i in issues})

    def test_flags_long_sentences_without_rewriting(self):
        text = "这个观察性结果需要谨慎解释，" + "针对研究设计限制进行讨论" * 8 + "。"
        issues = auditor.audit_text(text)
        self.assertTrue(any(i["type"] == "long_sentence_candidate" for i in issues))
        self.assertIn("谨慎解释", text)

    def test_zero_edit_sentence_has_no_superficial_flags(self):
        text = "在本样本中，身体活动水平与焦虑评分呈负相关。由于采用横断面设计，本研究无法判断二者的时间顺序。"
        self.assertEqual(auditor.audit_text(text), [])

    def test_repeated_connector_requires_three(self):
        text = "此外，第一段。\n此外，第二段。\n此外，第三段。"
        issues = auditor.audit_text(text)
        self.assertTrue(any(i["type"] == "repeated_connector" for i in issues))
        self.assertEqual(len(auditor.audit_text("此外，第一段。\n此外，第二段。")), 0)

    def test_long_text_only_cues_not_score(self):
        long_text = "研究所使用的术语可能需要明确定义。" * 25
        issues = auditor.audit_text(long_text)
        self.assertTrue(all("score" not in issue for issue in issues))


if __name__ == "__main__":
    unittest.main()
