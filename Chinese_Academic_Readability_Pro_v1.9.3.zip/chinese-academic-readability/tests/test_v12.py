"""v1.2 regression and security tests; NOT paper comprehension performance."""
from __future__ import annotations

import importlib.util
import json
import os
from zipfile import ZipFile
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / "scripts" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


audit = load("audit_text")
compare = load("compare_versions")
blind = load("prepare_blind_eval")
verify_release = load("verify_release")
CRITICAL_RISKS = {"observational_causal_overclaim", "nonsignificant_as_equivalence",
                  "planned_as_completed", "universal_effect_claim",
                  "association_as_mediation", "significance_without_claim"}


class ExistingIndependentChallengeRegression(unittest.TestCase):
    def test_previous_33_external_challenges(self):
        cases = json.loads((ROOT / "evals/previous_independent_challenges.json").read_text(encoding="utf-8"))["cases"]
        self.assertEqual(len(cases), 33)
        for case in cases:
            with self.subTest(case=case["id"]):
                names = {x["type"] for x in audit.audit_text(case["text"])}
                if case["type"]:
                    self.assertIn(case["type"], names)
                else:
                    self.assertFalse(names & CRITICAL_RISKS, names)

    def test_new_targeted_14_positive_and_negative_challenges(self):
        cases = json.loads((ROOT / "evals/additional_regression_v12.json").read_text(encoding="utf-8"))["cases"]
        self.assertEqual(len(cases), 14)
        for case in cases:
            with self.subTest(case=case["id"]):
                names = {x["type"] for x in audit.audit_text(case["text"])}
                if case["type"]:
                    self.assertIn(case["type"], names)
                else:
                    self.assertFalse(names & CRITICAL_RISKS, names)

    def test_crossline_issue_has_correct_second_line_number(self):
        issues = audit.audit_text("本研究采用横断面设计。\n结果证明运动可以改善焦虑。")
        labels = [x for x in issues if x["type"] == "observational_causal_overclaim"]
        self.assertTrue(labels)
        self.assertEqual(labels[0]["line"], 2)

    def test_code_and_markdown_table_are_skipped(self):
        issues = audit.audit_text("| 横断面 | 本研究证明运动可以降低焦虑 |\n```python\n运动能够改善焦虑\n```")
        self.assertEqual(issues, [])


class NumericalFidelityRegression(unittest.TestCase):
    def test_previous_ten_numeric_misses_all_flagged(self):
        cases = json.loads((ROOT / "evals/numeric_regression_v12.json").read_text(encoding="utf-8"))["cases"]
        self.assertEqual(len(cases), 10)
        for c in cases:
            with self.subTest(case=c["id"]):
                flags = compare.compare_versions(c["before"], c["after"])
                self.assertIn("numbers_changed", {x["type"] for x in flags})

    def test_unicode_chinese_units_decimals_percent_scientific_notation(self):
        self.assertEqual(compare.numbers("平均步数8650步，焦虑评分12.4分，变化-2.1%，剂量30mg，p=2.5e-03"),
                         compare.numbers("平均步数8,650步，焦虑评分12.40分，变化−2.10％，剂量30 mg，p=0.0025"))

    def test_thousands_decimal_presentation_is_not_numeric_change(self):
        flags = compare.compare_versions("参与者共1,250人，P=.020。", "参与者共1250人，P=0.02。")
        self.assertNotIn("numbers_changed", {x["type"] for x in flags})

    def test_swapping_arms_with_same_numeric_multiset_is_flagged(self):
        before = "干预组评分为11.3分，对照组评分为13.7分。"
        after = "干预组评分为13.7分，对照组评分为11.3分。"
        flags = compare.compare_versions(before, after)
        self.assertNotIn("numbers_changed", {x["type"] for x in flags})
        self.assertIn("number_binding_changed", {x["type"] for x in flags})

    def test_reordering_clauses_without_change_of_ownership_no_binding_alarm(self):
        before = "干预组评分为11.3分，对照组评分为13.7分。"
        after = "对照组评分为13.7分，干预组评分为11.3分。"
        flags = compare.compare_versions(before, after)
        self.assertNotIn("number_binding_changed", {x["type"] for x in flags})
        self.assertNotIn("numbers_changed", {x["type"] for x in flags})

    def test_same_positive_negative_counts_but_reassigned_direction(self):
        before = "步数与焦虑评分呈负相关，久坐时长与焦虑评分呈正相关。"
        after = "步数与焦虑评分呈正相关，久坐时长与焦虑评分呈负相关。"
        flags = compare.compare_versions(before, after)
        self.assertIn("direction_binding_changed", {x["type"] for x in flags})

    def test_citation_numbers_not_treated_as_measurements(self):
        self.assertEqual(compare.numbers("已有证据[1,2]，DOI:10.1000/xyz123，样本100人。"), compare.numbers("样本100人。"))

    def test_no_change_stays_no_flag(self):
        self.assertEqual(compare.compare_versions("调查共12人。", "调查共12人。"), [])


class BlindPackSafetyTests(unittest.TestCase):
    def setUp(self):
        self.public, self.key = blind.prepare({"cases": [{"id": "case1", "variants": {
            "A": "普通修改。", "B": "加强提示。", "C": "第三个版本。"}}]}, 33)

    def test_private_directory_never_inside_public_directory(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            with self.assertRaises(ValueError):
                blind.write_packs(self.public, self.key, root / "public", root / "public" / "keys", 33)
            self.assertFalse((root / "public").exists())

    def test_pub_folder_contains_no_key_key_is_mode_0600(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            public_path, private_path = blind.write_packs(
                self.public, self.key, root / "public", root / "private", 33)
            self.assertEqual({f.name for f in (root / "public").iterdir()}, {"reviewer_pack.md"})
            self.assertTrue(private_path.exists())
            self.assertEqual(private_path.stat().st_mode & 0o777, 0o600)
            self.assertNotIn('"mapping"', public_path.read_text(encoding="utf-8"))
            self.assertEqual(set(json.loads(private_path.read_text(encoding="utf-8"))["key"][0]["mapping"].values()), {"A", "B", "C"})

    def test_run_twice_must_not_overwrite_blinded_review(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            blind.write_packs(self.public, self.key, root / "public", root / "private", 33)
            with self.assertRaises(FileExistsError):
                blind.write_packs(self.public, self.key, root / "public", root / "private", 33)

    def test_cli_custom_private_location(self):
        with tempfile.TemporaryDirectory() as d:
            d = Path(d)
            command = [sys.executable, str(ROOT / "scripts/prepare_blind_eval.py"),
                       str(ROOT / "evals/example_abc_input.json"), str(d / "public"),
                       "--key-dir", str(d / "private"), "--seed", "42"]
            result = subprocess.run(command, capture_output=True, text=True, check=True)
            self.assertIn("PRIVATE key", result.stdout)
            self.assertEqual(len(list((d / "public").iterdir())), 1)
            self.assertEqual(len(list((d / "private").iterdir())), 1)
            self.assertEqual(os.stat(d / "private").st_mode & 0o777, 0o700)


class ReleaseVerifierSecurityTests(unittest.TestCase):
    def test_reject_zip_path_traversal_before_extraction(self):
        with tempfile.TemporaryDirectory() as d:
            zpath = Path(d) / "bad.zip"
            with ZipFile(zpath, "w") as z:
                z.writestr("chinese-academic-readability/../../escape.txt", "unsafe")
            with self.assertRaisesRegex(ValueError, "Unsafe"):
                verify_release.verify(zpath)

    def test_reject_missing_file_manifest(self):
        with tempfile.TemporaryDirectory() as d:
            zpath = Path(d) / "missing.zip"
            with ZipFile(zpath, "w") as z:
                z.writestr("chinese-academic-readability/SKILL.md", "---\nname: x\n---")
            with self.assertRaisesRegex(ValueError, "manifest"):
                verify_release.verify(zpath)


if __name__ == "__main__":
    unittest.main()
