"""v1.9.2: remove figure meta-copy while retaining actual scientific/plot labels."""
import importlib.util
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import sys
import unittest
from zipfile import ZipFile

ROOT=Path(__file__).resolve().parents[1]
S=ROOT/'scripts/figure_text_economy_audit.py'
spec=importlib.util.spec_from_file_location('figure_text_economy_audit',S)
M=importlib.util.module_from_spec(spec)
spec.loader.exec_module(M)

class FigureTextEconomyTests(unittest.TestCase):
    def ppt(self, path, texts):
        ns='http://schemas.openxmlformats.org/presentationml/2006/main'
        an='http://schemas.openxmlformats.org/drawingml/2006/main'
        items=''.join(f'<p:sp><p:txBody><a:p><a:r><a:t>{s}</a:t></a:r></a:p></p:txBody></p:sp>' for s in texts)
        xml=f'<p:sld xmlns:p="{ns}" xmlns:a="{an}"><p:cSld><p:spTree>{items}</p:spTree></p:cSld></p:sld>'
        with ZipFile(path,'w') as z:z.writestr('ppt/slides/slide1.xml',xml)

    def test_flags_unnecessary_disclaimer(self):
        with TemporaryDirectory() as d:
            p=Path(d)/'p.pptx';self.ppt(p,['不代表试验结果'])
            self.assertEqual(M.audit_pptx(p)['meta_copy_candidates'][0]['category'],'non_result_disclaimer')

    def test_flags_unnecessary_core_difference_banner(self):
        with TemporaryDirectory() as d:
            p=Path(d)/'p.pptx';self.ppt(p,['核心区别：策略 A 与 S*'])
            self.assertEqual(M.audit_pptx(p)['candidate_count'],1)

    def test_flags_research_preface(self):
        with TemporaryDirectory() as d:
            p=Path(d)/'p.pptx';self.ppt(p,['研究切入点示意'])
            self.assertEqual(M.audit_pptx(p)['candidate_count'],1)

    def test_preserves_necessary_short_labels(self):
        with TemporaryDirectory() as d:
            p=Path(d)/'p.pptx';self.ppt(p,['策略 A','策略 S*','步/天','95% CI'])
            r=M.audit_pptx(p)
            self.assertEqual(r['candidate_count'],0)
            self.assertEqual(r['editable_text_items'],4)

    def test_does_not_ban_real_statistical_terms(self):
        with TemporaryDirectory() as d:
            p=Path(d)/'p.pptx';self.ppt(p,['平均步数（步/天）','样本量 n=60','95% CI','观察组'])
            self.assertEqual(M.audit_pptx(p)['candidate_count'],0)

    def test_review_only_even_if_flag(self):
        with TemporaryDirectory() as d:
            p=Path(d)/'p.pptx';self.ppt(p,['不代表试验结果'])
            self.assertEqual(M.audit_pptx(p)['status'],'REVIEW_ONLY')

    def test_does_not_modify_source(self):
        with TemporaryDirectory() as d:
            p=Path(d)/'p.pptx';self.ppt(p,['核心区别'])
            before=p.read_bytes();M.audit_pptx(p)
            self.assertEqual(p.read_bytes(),before)

    def test_invalid_extension_rejected(self):
        with TemporaryDirectory() as d:
            p=Path(d)/'bad.pdf';p.write_bytes(b'x')
            with self.assertRaises(ValueError):M.audit_pptx(p)

    def test_missing_slide_rejected(self):
        with TemporaryDirectory() as d:
            p=Path(d)/'x.pptx'
            with ZipFile(p,'w') as z:z.writestr('word/document.xml','a')
            with self.assertRaises(ValueError):M.audit_pptx(p)

    def test_cli_json_success(self):
        with TemporaryDirectory() as d:
            p=Path(d)/'p.pptx';q=Path(d)/'report.json';self.ppt(p,['策略 A'])
            subprocess.run([sys.executable,str(S),str(p),'--out-json',str(q)],check=True,capture_output=True)
            self.assertEqual(json.loads(q.read_text())['candidate_count'],0)

    def test_current_demo_no_unnecessary_meta_inside(self):
        demo=ROOT/'assets/figure_demo/figure_01.pptx'
        r=M.audit_pptx(demo)
        self.assertEqual(r['candidate_count'],0)
        self.assertLessEqual(r['total_visible_text_characters'],35)
        self.assertIn('REVIEW_ONLY',r['status'])

    def test_demo_maintains_editable_pptx_and_svg(self):
        src=ROOT/'scripts/figure_source_audit.py'
        spec=importlib.util.spec_from_file_location('figure_source_audit',src)
        mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
        fig=ROOT/'assets/figure_demo'
        r=mod.audit(fig/'figure_01.pptx',fig/'figure_01.svg')
        self.assertEqual(r['structure_status'],'PASS')
        self.assertEqual(r['pptx_structure']['picture_shapes'],0)
        self.assertEqual(r['svg_structure']['image_elements'],0)

    def test_provenance_did_not_drop_scientific_status(self):
        prov=(ROOT/'assets/figure_demo/PROVENANCE.md').read_text(encoding='utf8')
        self.assertIn('no observed',prov.lower())
        self.assertIn('figure_01_caption.md',prov)

    def test_caption_keeps_nonresults_and_possible_fallback(self):
        cap=(ROOT/'assets/figure_demo/figure_01_caption.md').read_text(encoding='utf8')
        self.assertIn('不包含实测结果',cap)
        self.assertIn('相同',cap)

    def test_scientific_contract_not_changed_to_observed_result(self):
        p=ROOT/'evals/figure_contract_schematic_example.json'
        data=json.loads(p.read_text())
        self.assertEqual(data['evidence_kind'],'schematic')
        self.assertEqual(data['study_phase'],'proposal')

    def test_skill_references_policy_and_script(self):
        text=(ROOT/'SKILL.md').read_text(encoding='utf-8')
        for s in ('Figure Text Economy','references/figure-text-economy.md','scripts/figure_text_economy_audit.py'):
            self.assertIn(s,text)

    def test_policy_stops_unnecessary_figures(self):
        text=(ROOT/'references/figure-text-economy.md').read_text(encoding='utf-8')
        self.assertIn('允许不绘图',text)

    def test_policy_protects_numeric_axes(self):
        text=(ROOT/'references/figure-text-economy.md').read_text(encoding='utf-8')
        self.assertIn('坐标轴',text)
        self.assertIn('单位',text)

if __name__=='__main__':unittest.main()
