"""End-to-end offline smoke tests of command-line tools."""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class CLISmokeTests(unittest.TestCase):
    def test_audit_cli_json(self):
        with tempfile.TemporaryDirectory() as d:
            draft = Path(d) / "draft.md"
            draft.write_text("横断面调查发现两者有关，因此运动可以改善焦虑。", encoding="utf-8")
            run = subprocess.run([sys.executable, str(ROOT / "scripts/audit_text.py"), str(draft), "--format", "json"],
                                 capture_output=True, text=True, check=True)
            result = json.loads(run.stdout)
            self.assertTrue(any(x["type"] == "observational_causal_overclaim" for x in result["issues"]))

    def test_version_comparison_cli(self):
        with tempfile.TemporaryDirectory() as d:
            before, after = Path(d) / "before.md", Path(d) / "after.md"
            before.write_text("β=-0.16，呈负相关。", encoding="utf-8")
            after.write_text("β=-0.16，呈正相关。", encoding="utf-8")
            run = subprocess.run([sys.executable, str(ROOT / "scripts/compare_versions.py"), str(before), str(after),
                                  "--format", "json"], capture_output=True, text=True, check=True)
            result = json.loads(run.stdout)
            self.assertTrue(any(x["type"] == "direction_or_significance_cue_changed" for x in result["flags"]))

    def test_blind_pack_separates_public_and_private(self):
        with tempfile.TemporaryDirectory() as d:
            output = Path(d) / "blind_output"
            run = subprocess.run([sys.executable, str(ROOT / "scripts/prepare_blind_eval.py"),
                                  str(ROOT / "evals/example_abc_input.json"), str(output), "--seed", "42"],
                                 capture_output=True, text=True, check=True)
            self.assertIn("PRIVATE key", run.stdout)
            self.assertTrue((output / "reviewer_pack.md").is_file())
            # The private mapping must NOT be inside the folder reviewers receive.
            self.assertEqual(sorted(p.name for p in output.iterdir()), ["reviewer_pack.md"])
            private_path = Path(next(line.split(": ", 1)[1] for line in run.stdout.splitlines() if line.startswith("PRIVATE key")))
            mapping = json.loads(private_path.read_text(encoding="utf-8"))
            self.assertEqual(set(mapping["key"][0]["mapping"].values()), {"A", "B", "C"})
            self.assertEqual(private_path.stat().st_mode & 0o777, 0o600)
            private_path.unlink(missing_ok=True)
            rerun = subprocess.run([sys.executable, str(ROOT / "scripts/prepare_blind_eval.py"),
                                    str(ROOT / "evals/example_abc_input.json"), str(output)],
                                   capture_output=True, text=True)
            self.assertNotEqual(rerun.returncode, 0)


if __name__ == "__main__":
    unittest.main()
