# artifact-qa 使用示例

下面的命令为操作练习，不是虚构科研结果；必须在实际文档上取得证据后才能宣称最终交付 PASS。

**准备**：已审定 DOCX、有负责该稿的核验人员；系统必须有 LibreOffice，或 Windows Word + pywin32。建议 Python 3.10+ 并安装 `python-docx`, `PyMuPDF`, `Pillow`, `numpy`, `lxml`。

```bash
# 第一次仅检查，不修改源 DOCX：
python scripts/submission_gate.py report.docx --out-dir report_qa --engine libreoffice
# 输出：PDF、pages/page-001.png ... page-N.png、三个审计 JSON、submission_report.md、visual_review_template.json
```

若 PDF 的文本与 DOCX 完全一致但页面中文字不可见，文字比对不能证明视觉安全；须对照 `pages/` 图像逐页审查。对数学公式、表格单元格、目录逐项打勾。

对照用户的 28 页课程研究稿，可加上特定锚点：

```bash
python scripts/submission_gate.py report.docx --out-dir report_qa \
  --engine libreoffice --anchors-json examples/real-report-anchors-v14.json
# 预期：如果相同缺字在此引擎复现，则整体 FAIL，不能报 PASS。
```

**门禁语义**：`PASS` = 所有规定证据齐全、无未裁决问题；`FAIL` = 发现有据可核的实质问题；`UNVERIFIED` = 无法核验、缺引擎/截图/审查者签核。`PASS` 不代表论文研究内容或统计方法已经同行评审。

对于保留源文件内容的排版修复，应额外执行文字语义回归：

```bash
python scripts/compare_versions.py original_text.md after_layout_text.md --format markdown
```

Word/Linux 不兼容时 `--engine word` 应返回 UNVERIFIED，不应静默改成 LO。将每个引擎分别导出的 PDF、渲染、版本、哈希作为可追溯的独立结果。
